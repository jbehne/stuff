function f_CyberarkLookup ($login)
{
    # Parms to pass to the API (Account Name and Server Name)
    $postparms = @{
        account=$login.LoginName
        address=$login.ServerName }

    # Call the URI with the parms specified
    $rawdata = Invoke-WebRequest -Uri https://pamtools.countrylan.com/CyberArkReports/checkDBManagedStatusAPI.php -Method POST -Body $postparms -UseDefaultCredentials -UseBasicParsing
    
    # Convert the JSON to an array
    $data = $rawdata.Content | ConvertFrom-Json

    # Check if the account is not managed, if yes then try again with a blank address
    if ($data.'Cyberark Status' -eq "Not Managed")
    {
        # Try the API Call again with a blank address to pick up unmanaged accounts
        $postparms = @{
            account=$login.LoginName
            address="" }

        # Call the URI with the parms specified
        $rawdata = Invoke-WebRequest -Uri https://pamtools.countrylan.com/CyberArkReports/checkDBManagedStatusAPI.php -Method POST -Body $postparms -UseDefaultCredentials -UseBasicParsing        
        
        # Convert the JSON to an array
        $data = $rawdata.Content | ConvertFrom-Json

        # Set the servername back into the address since we passed a blank
        $data[0].address = $login.ServerName

        # Check again, if it returns managed now then it is unmanaged, if it still returns not managed then it is not present
        if ($data.'Cyberark Status' -ne "Not Managed")
        {
            $data[0].'CyberArk Status' = "Unmanaged Account"
        }
    }

    # Write the results to the array
    return $data
}

workflow wf_CyberarkLookup ($logins)
{
    $data = @()
    foreach -parallel ($login in $logins)
    {
        $WORKFLOW:data += f_CyberarkLookup $login 
    }

    $WORKFLOW:data
}

try
{
    ########################## TSQL Cyberark Checks ##########################
    $query = "SELECT TRIM(ServerName) ServerName, TRIM(LoginName) LoginName
    FROM vw_All_Security_Logins
    WHERE isNTname = 0"

    $logins = Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query

    # Clear the table
    Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "TRUNCATE TABLE Security_CyberarkAccount"

    # Start loading
    $results = @()
    $results = wf_CyberarkLookup $logins

    # Write the results to the table
    $results | Select account, address, 'cyberark status', safe, 'safe owner', @{ Name = 'dbms';  Expression = {"SQL"}} |
        Write-SqlTableData -ServerInstance . -DatabaseName SQLMONITOR -SchemaName dbo -TableName Security_CyberarkAccount


    ########################## ORACLE OEM Cyberark Checks ##########################
    $query = "SELECT username LoginName, account_status, srvr_nm ServerName FROM OPENQUERY(OMRPROD, 
        'select distinct username, account_status, authentication_type, srvr_nm from CC_ORA.DBA_USERS where account_status <> ''EXPIRED & LOCKED'' and authentication_type <> ''NONE''')"

    $logins = Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query

    # Start loading
    $results = @()
    $results = wf_CyberarkLookup $logins

    # Write the results to the table
    $results | Select account, address, 'cyberark status', safe, 'safe owner', @{ Name = 'dbms';  Expression = {"ORACLE"}} |
        Write-SqlTableData -ServerInstance . -DatabaseName SQLMONITOR -SchemaName dbo -TableName Security_CyberarkAccount


    ########################## AZURE POSTGRES Cyberark Checks ##########################
    $query = "SELECT RoleName LoginName, ServerName + '.postgres.database.azure.com' ServerName
        FROM Security_Roles sr
        INNER JOIN Monitored_Databases md ON md.DatabaseID = sr.DatabaseID
        WHERE CanLogin = 1
        AND RoleName <> 'azure_superuser'"

    $logins = Invoke-Sqlcmd -ServerInstance V01DBSWIN057 -Database PGMONITOR -Query $query

    # Start loading
    $results = @()
    $results = wf_CyberarkLookup $logins

    # Write the results to the table
    $results | Select account, address, 'cyberark status', safe, 'safe owner', @{ Name = 'dbms';  Expression = {"POSTGRESQL"}} |
        Write-SqlTableData -ServerInstance . -DatabaseName SQLMONITOR -SchemaName dbo -TableName Security_CyberarkAccount

    # Set the load date
    Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "UPDATE Security_CyberarkAccount SET LoadDate = GETDATE()"
}

catch
{
    throw $_
}
