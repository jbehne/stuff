<#
    Script:     LoadSQLMonitor.ps1
    Parameters: <none>
    Usage:      Called from SQL Server Agent
    Purpose:    This script is used to collect monitoring information from 
                all SQL servers in the monitored servers table.  This script 
                is specific to the production repository <SQLMONITORPROD>.
#>

function f_collectcisco ($instance)
{
    try
    {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=SQLMONITORPROD;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()

        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 240

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Integrated Security=true")
        $sqlconn.Open()

		### Update repository server settings
		$query = "SELECT 'LastStarted' Name, CONVERT(varchar, sqlserver_start_time, 22) Value FROM sys.dm_os_sys_info;"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

		while ($sqlreader.Read())
		{
			switch ($sqlreader["Name"])
            {
                'LastStarted' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'LastStarted', '" + $sqlreader["Value"] + "'" }
            }

            Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query $updatequery
		}

        Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query "UPDATE Perf_MonitoredServers SET LastUpdated = GETDATE() WHERE InstanceID = $($instance.InstanceID)"

        $sqlreader.Close()

        ### Backup_BackupHistory
        $query = "SELECT $($instance.InstanceID) InstanceID, database_name DatabaseName, bs.name BackupName, user_name UserName, physical_device_name BackupLocation, 
	                backup_start_date BackupStartDate, backup_finish_date BackupEndDate,
	                CASE WHEN is_compressed = 0 THEN backup_size ELSE compressed_backup_size END BackupSize, 
	                is_compressed Compressed, is_copy_only CopyOnly, type BackupType
                FROM msdb..backupset bs
                LEFT OUTER JOIN msdb..backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
                LEFT OUTER JOIN msdb..backupmediaset bms ON bs.media_set_id = bms.media_set_id
                WHERE backup_start_date > GETDATE() - 7"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Backup_BackupHistory_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch 
    {
        $err = "LoadSQLMonitor.ps1 - " + $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }

}

function f_Collect ($instance) 
{
    try 
    {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=SQLMONITORPROD;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()

        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 240

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Database=SQLADMIN;Integrated Security=true")
        $sqlconn.Open()

		### Update repository server settings
		$query = "
                SELECT CAST(TimerName AS varchar) Name, CAST(TimeValue AS varchar) Value FROM Perf_Timers
                UNION ALL
				SELECT 'LastStarted', CONVERT(varchar, sqlserver_start_time, 22) FROM sys.dm_os_sys_info;"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

		while ($sqlreader.Read())
		{
			switch ($sqlreader["Name"])
            {
                'Collection' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'PollingInterval_Minutes', '" + $sqlreader["Value"] + "'" }
                'Retention' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'PurgeInterval_Days', '" + $sqlreader["Value"] + "'" }
                'LastStarted' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'LastStarted', '" + $sqlreader["Value"] + "'" }
            }

            Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query $updatequery
		}

        Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query "UPDATE Perf_MonitoredServers SET LastUpdated = GETDATE() WHERE InstanceID = $($instance.InstanceID)"

        $sqlreader.Close()

        ### Backup_BackupHistory
        $query = "SELECT $($instance.InstanceID) InstanceID, database_name DatabaseName, bs.name BackupName, user_name UserName, physical_device_name BackupLocation, 
	                backup_start_date BackupStartDate, backup_finish_date BackupEndDate,
	                CASE WHEN is_compressed = 0 THEN backup_size ELSE compressed_backup_size END BackupSize, 
	                is_compressed Compressed, is_copy_only CopyOnly, type BackupType
                FROM msdb..backupset bs
                LEFT OUTER JOIN msdb..backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
                LEFT OUTER JOIN msdb..backupmediaset bms ON bs.media_set_id = bms.media_set_id
                WHERE backup_start_date > GETDATE() - 7"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Backup_BackupHistory_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_CounterData
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, RTRIM(Class) Class, RTRIM(Counter) Counter, RTRIM(Instance) Instance, Value 
            FROM Perf_CounterData WHERE CollectionTime > '$($instance.LastCounters)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_CounterData_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_FileIO
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, DatabaseName, FileName, ReadLatency, WriteLatency, 
            Latency, AvgBytesPerRead, AvgBytesPerWrite, AvgBytesPerTransfer FROM Perf_FileIO WHERE CollectionTime > '$($instance.LastIO)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_FileIO"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_FileSpace
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, InstanceName, DBName, FileName, FileGroup, Type, 
            Size, Used FROM Perf_FileSpace WHERE CollectionTime > '$($instance.LastSpace)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_FileSpace"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        <#
        ### Perf_MemoryClerks
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, Type, Name, MemoryNodeID, PagesKB, 
            VirtualMemoryReservedKb, VirtualMemoryCommittedKb, AweAllocatedKb, SharedMemoryReservedKb, SharedMemoryCommittedKb 
            FROM Perf_MemoryClerks WHERE CollectionTime > '$($instance.LastClerks)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_MemoryClerks"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()
        #>

        ### Perf_MemoryGrants
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, SessionID, DOP, RequestTime, GrantTime, 
            RequestedMemoryKB, RequiredMemoryKB, UsedMemoryKB, MaxUsedMemoryKB, QueryCost, TimeoutSec, WaitTimeMS, IdealMemoryKB 
            FROM Perf_MemoryGrants WHERE CollectionTime > '$($instance.LastGrants)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_MemoryGrants"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_Sessions
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, LoginTime, SPID, Status, DBName, 
            HostName, ApplicationName, LoginName, CPUTime, Reads, Writes, Lastread, LastWrite, SQLText, open_transaction_count, 
            row_count, blocking_session_id, wait_type, wait_time, wait_resource
            FROM Perf_Sessions WHERE CollectionTime > '$($instance.LastSessions)'"

        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_Sessions"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_WaitStatistics
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, WaitType, Wait_S, Resource_S, 
            Signal_S, WaitCount, Percentage, AvgWait_S, AvgRes_S, AvgSig_S 
            FROM Perf_WaitStatistics WHERE CollectionTime > '$($instance.LastWaits)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_WaitStatistics"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        <#
        THIS HAS BEEN DISABLED DUE TO ISSUES FOUND AT THE INSTANCE LEVEL

        ### Perf_IndexUsageStatistics
        $query = "SELECT $($instance.InstanceID) InstanceID, LastStartUp, DatabaseName, TableName, IndexName, 
            IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, SystemLookups, UserUpdates, SystemUpdates 
            FROM Perf_IndexUsageStatistics"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_IndexUsageStatistics_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()
        #>


        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch 
    {
        $err = "LoadSQLMonitor.ps1 - " + $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }
}

workflow wf_CollectAll ($instances) 
{
    foreach -parallel -throttlelimit 4 ($instance in $instances) 
    {
        if ($instance.ServerName -like "*AWH*" -or $instance.ServerName -like "*RGR*" -or $instance.ServerName -like "*CMP*" -or $instance.ServerName -like "*IPT*")
        {
            f_collectcisco $instance
        }

        else
        {
            f_collect $instance
        }
    }
}

### Program Start


#Set repository
$repository = "SQLMONITORPROD"

# Set query to get servers
$query = "SELECT 
    ServerName, InstanceID,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_CounterData WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastCounters,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_FileSpace WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastSpace,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_MemoryGrants WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastGrants,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_Sessions WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastSessions,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_WaitStatistics WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastWaits,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_FileIO WHERE InstanceID = pms.InstanceID AND CollectionTime > GETDATE() - 1), '12/15/1941') LastIO
    FROM Perf_MonitoredServers pms
    WHERE IsActive = 1"

# Get servers
$instances = @(Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query $query -QueryTimeout 600 -ConnectionTimeout 600)

# Truncate index stats staging
#Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "TRUNCATE TABLE Perf_IndexUsageStatistics_Stage"

# Call the workflow with the list of servers
wf_CollectAll $instances


<#
# Merge Index Usage Statistics
$query = "	MERGE Perf_IndexUsageStatistics AS t
	USING (SELECT InstanceID, LastStartUp, DatabaseName, TableName, IndexName, 
		IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, 
		SystemLookups, UserUpdates, SystemUpdates FROM Perf_IndexUsageStatistics_Stage) AS s
	ON (s.LastStartUp = t.LastStartUp AND s.DatabaseName = t.DatabaseName AND 
		s.TableName = t.TableName AND COALESCE(s.IndexName,'') = COALESCE(t.IndexName,'') AND s.InstanceID = t.InstanceID)
	WHEN MATCHED THEN
		UPDATE SET t.UserSeeks = s.UserSeeks, t.SystemSeeks = s.SystemSeeks, t.UserScans = s.UserScans, 
		t.SystemScans = s.SystemScans, t.UserLookups = s.UserLookups, t.SystemLookups = s.SystemLookups, 
		t.UserUpdates = s.UserUpdates, t.SystemUpdates = s.SystemUpdates
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (InstanceID, LastStartUp, DatabaseName, TableName, IndexName, 
		IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, 
		SystemLookups, UserUpdates, SystemUpdates)
		VALUES (s.InstanceID, s.LastStartUp, s.DatabaseName, s.TableName, s.IndexName, 
		s.IndexType, s.UserSeeks, s.SystemSeeks, s.UserScans, s.SystemScans, s.UserLookups, 
		s.SystemLookups, s.UserUpdates, s.SystemUpdates);"
#>
#Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query $query -QueryTimeout 600
#Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "TRUNCATE TABLE Perf_IndexUsageStatistics_Stage"


