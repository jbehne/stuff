function Write-Log ($msg)
{
    $file = "E:\Log\CopyCiscoBackups.log"
    "$(Get-Date -Format "MM-dd-yyyy hh:mm:ss") - $msg" | Out-File $file -Append
}

$servers = @()
$servers += "v01awhwin040.icm.lan"
$servers += "v01cmpwin049.icm.lan"
$servers += "v01iptwin051.icm.lan"
$servers += "v01rgrwin041.icm.lan"
$servers += "v06awhwin040.icm.lan"
$servers += "v06rgrwin042.icm.lan"

"" | Out-File "E:\Log\CopyCiscoBackups.log"

foreach ($fqdnserver in $servers)
{
    $files = Get-ChildItem "\\$fqdnserver\D$\Data\Program Files\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQL\Backup\" -Recurse | Where Attributes -ne "Directory" | Select name, directory, fullname, creationtime
    $server = $fqdnserver -replace ".icm.lan", ""
    
    Write-Log "$server has $($files.Count) backup files"

    foreach ($file in $files)
    {
        try
        {
            $dir = $file.Directory
            if ((Test-Path "\\s01ddaesd001d\01_sqlprodcifs\$server\$($dir.name)\$($file.Name)") -eq $false)
            {
                Copy-Item $file.FullName "\\s01ddaesd001d\01_sqlprodcifs\$server\$($dir.name)\$($file.Name)" -ErrorAction Stop
                Write-Log "Copied $($file.Name) to data domain \\s01ddaesd001d\01_sqlprodcifs\$server\$($dir.name)\$($file.Name)"
            }

            if ($file.CreationTime -le $(Get-Date).AddDays(-2) -and (Test-Path "\\s01ddaesd001d\01_sqlprodcifs\$server\$($dir.name)\$($file.Name)") -eq $true)
            {
                Remove-Item $file.FullName -ErrorAction Stop
                Write-Log "Deleted $($file.FullName) from $server"
            }
        }

        catch
        {
            Write-Log $_
            throw $_
        }
    }    
}