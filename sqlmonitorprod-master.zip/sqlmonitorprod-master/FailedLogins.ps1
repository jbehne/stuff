#*************************************************************************************************/ 
# FailedLogins.ps1                                                                              */
#*************************************************************************************************/
#    This program generates failed login attempts across all audited sql servers excluding CTB   */
#    Servers.                                                                                    */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   10/8/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
try
{
    #Set Server Query
    $ServerQuery = "select * from openquery(servinfo,'SELECT DISTINCT SRVR_NM FROM CCDB2.MDB_DB_DATA WHERE AUDIT_FLG_INDR = ''Y'' AND DBMS_INSTANCE_NM = ''SQL'' AND DB_STAT = ''PROD''')"
    #Set Error Action
    $ErrorActionPreference = "SilentlyContinue"
    ##Set Servers
    $Servers = Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query $ServerQuery
    $Query = 'SELECT * FROM SYSDATABASES'
}
catch
{
    throw $_
}
#Loops through each server and run the failed login
Foreach($Server in $Servers){
    
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST01 -Password Robert 
}
