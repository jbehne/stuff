# Used to output log data
function OutputLog ($logpath, $logtxt)
{
    "$(Get-Date -Format "hh:mm:ss") - $logtxt" | Out-File $LogPath -Append
    "$(Get-Date -Format "hh:mm:ss") - $logtxt" | Out-Host
}

<#
# Set testing parms
    $SourceServer = "C1DBD035"
    $SourceDatabase = "OCGPC0P2"
    $DestinationServer = "C1DBD717"
    $DestinationDatabase = "PRODTMPPC"

# Set testing parms with PIT
    $SourceServer = "C1DBD500"
    $SourceDatabase = "Hack"
    $DestinationServer = "C1DBD500"
    $DestinationDatabase = "Hack"
    [DateTime]$PIT = "10/25/2020 10:00 AM"
#>

# Input parameters (If PIT has a value it is converted to a datetime)
$SourceServer = $args[0]
$SourceDatabase = $args[1]
$DestinationServer = $args[2]
$DestinationDatabase = $args[3]
$PIT = $args[4]
if([string]::IsNullOrEmpty($PIT) -eq $false)
{
    $PIT = [DateTime]$PIT
}

# Default log file to E: drive of server script runs from
$LogPath = "E:\Log\$($DestinationDatabase)_Restore_$(Get-Date -Format "yyyyMMdd")_$(Get-Date -Format "hhmmss").txt"

# Output parms to log
Outputlog $logpath "Source Server: $SourceServer"
Outputlog $logpath "Source Database: $SourceDatabase"
Outputlog $logpath "Destination Server: $DestinationServer"
Outputlog $logpath "Destination Database: $DestinationDatabase"
Outputlog $logpath "PIT: $PIT"

try
{
    # Determine if the source is in prod, test, or qa by checking paths - if not found the script will exit
    if (Test-Path "\\s01ddaesd001d\01_sqlprodcifs\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\s01ddaesd001d\01_sqlprodcifs"
    }

    elseif (Test-Path "\\s01ddaesd001d\01_sqltestcifs\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\s01ddaesd001d\01_sqltestcifs"
    }

    elseif (Test-Path "\\s01ddaesd001d\01_sqlqacifs\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\s01ddaesd001d\01_sqlqacifs"
    }

    elseif (Test-Path "\\m1-bak-10-dd\m1_sql_prod\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\m1-bak-10-dd\m1_sql_prod"
    }

    elseif (Test-Path "\\m1-bak-10-dd\m1_sql_test\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\m1-bak-10-dd\m1_sql_test"
    }

    elseif (Test-Path "\\m1-bak-10-dd\m1_sql_qa\$SourceServer\$SourceDatabase")
    {
        $EnvironmentPath = "\\m1-bak-10-dd\m1_sql_qa"
    }

    else
    {
        throw "Backup path not found for source database, terminating"
    }

    $DestinationExists = Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "SELECT name FROM sys.databases WHERE name = '$DestinationDatabase'"

    if ([string]::IsNullOrEmpty($DestinationExists))
    {
        OutputLog $LogPath "Destination database does not exist"    
    }

    else
    {
        # Collect the users from the existing database
        OutputLog $LogPath "Begin gathering access from existing database"
        $adduserquery = "
            DECLARE @add varchar(max) = '';
            SELECT @add += 'CREATE USER [' + name + '] FOR LOGIN [' + name + ']; ' FROM sys.sysusers WHERE islogin = 1 AND hasdbaccess = 1 AND name <> 'dbo'
            SELECT @add cmd"
        $adduserquery = (Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $adduserquery -ErrorAction Stop -QueryTimeout 0).cmd
        OutputLog $LogPath $adduserquery

        # Collect user role assignments from existing database
        $addrolequery = "
            DECLARE @add varchar(max) = '';
            SELECT @add += 'EXEC sp_AddRoleMember ''' + DBRole.NAME + ''', ''' + DBP.NAME + '''; ' 
            FROM sys.database_principals DBP
            INNER JOIN sys.database_role_members DBM ON DBM.member_principal_id = DBP.principal_id
            INNER JOIN sys.database_principals DBRole ON DBRole.principal_id = DBM.role_principal_id
            WHERE DBP.NAME <> 'dbo'
            SELECT @add cmd"
        $addrolequery = (Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $addrolequery -ErrorAction Stop -QueryTimeout 0 -MaxCharLength 1000000).cmd
        OutputLog $LogPath $addrolequery

        # Collect explicit user access from existing database
        $adduserexplicityquery = "
            DECLARE @cmd varchar(max) = '';
            SELECT	@cmd += CASE WHEN DBP.state <> 'W' THEN DBP.state_desc ELSE 'GRANT' END
		            + SPACE(1) + DBP.permission_name + SPACE(1) + 'ON ' + QUOTENAME(USER_NAME(OBJ.schema_id)) + '.' + QUOTENAME(OBJ.name) 
		            + CASE WHEN CL.column_id IS NULL THEN SPACE(0) ELSE '(' + QUOTENAME(CL.name) + ')' END
		            + SPACE(1) + 'TO' + SPACE(1) + QUOTENAME(USR.name) COLLATE database_default
		            + CASE WHEN DBP.state <> 'W' THEN SPACE(0) ELSE SPACE(1) + 'WITH GRANT OPTION' END + '; '
            FROM	sys.database_permissions AS DBP
		            INNER JOIN	sys.objects AS OBJ	ON DBP.major_id = OBJ.[object_id]
		            INNER JOIN	sys.database_principals AS USR	ON DBP.grantee_principal_id = USR.principal_id
		            LEFT JOIN	sys.columns AS CL	ON CL.column_id = DBP.minor_id AND CL.[object_id] = DBP.major_id
            WHERE   USR.name <> 'public'
            ORDER BY DBP.permission_name ASC, DBP.state_desc ASC

			SELECT @cmd += 
			state_desc COLLATE SQL_Latin1_General_CP1_CI_AS + ' ' + permission_name COLLATE SQL_Latin1_General_CP1_CI_AS + 
			' TO ' + name COLLATE SQL_Latin1_General_CP1_CI_AS + ';'
			FROM sys.database_permissions perm
			INNER JOIN sys.database_principals prin ON prin.principal_id = perm.grantee_principal_id
			WHERE class_desc = 'DATABASE'
			AND permission_name <> 'CONNECT'

            SELECT @cmd cmd"
        $adduserexplicityquery = (Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $adduserexplicityquery -ErrorAction Stop -QueryTimeout 0 -MaxCharLength 1000000).cmd
        OutputLog $LogPath $adduserexplicityquery
        OutputLog $LogPath "Completed gathering access from existing database"

        Outputlog $logpath "Starting SINGLE_USER and DROP on $DestinationServer $DestinationDatabase"
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "SET DEADLOCK_PRIORITY 10; ALTER DATABASE $($DestinationDatabase) SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE $($DestinationDatabase);" -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Completed SINGLE_USER and DROP on $DestinationServer $DestinationDatabase"        
<# Changing this to SINGLE_USER with the drop in one statement
        # Set existing database to restricted
        Outputlog $logpath "Starting RESTRICTED_USER on $DestinationServer $DestinationDatabase"
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "SET DEADLOCK_PRIORITY 10; ALTER DATABASE $($DestinationDatabase) SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE;" -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Completed RESTRICTED_USER on $DestinationServer $DestinationDatabase"

        # Drop existing database
        Outputlog $logpath "Starting DROP DATABASE on $DestinationServer $DestinationDatabase"
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "SET DEADLOCK_PRIORITY 10; DROP DATABASE $($DestinationDatabase);" -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Completed DROP DATABASE on $DestinationServer $DestinationDatabase"
#>        
    }

    # Get the destination server's default file locations - this COULD be an issue if the existing database is not in defaults
    $DataDrive = (Invoke-SqlCmd -ServerInstance $DestinationServer -Query "SELECT SERVERPROPERTY('InstanceDefaultDataPath') AS InstanceDefaultDataPath").InstanceDefaultDataPath
    $LogDrive = (Invoke-SqlCmd -ServerInstance $DestinationServer -Query "SELECT SERVERPROPERTY('InstanceDefaultLogPath') AS InstanceDefaultLogPath").InstanceDefaultLogPath

    # If a PIT parm is not passed in (null) then get the latest FULL backup
    if([string]::IsNullOrEmpty($PIT))
    {
        $FullBackupFile = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where Name -Like "*FULL*" | Sort LastWriteTime | Select -Last 1
    }

    # Else if PIT is not null then get the latest FULL BEFORE the PIT timestamp
    else
    {
        $FullBackupFile = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*FULL*" -and $_.LastWriteTime -lt $PIT} | Sort LastWriteTime | Select -Last 1
    }

    Outputlog $logpath "FULL BACKUP file for $SourceServer $SourceDatabase is $($FullBackupFile.FullName)"

    # Create dynamic restore command so that logical files can be moved
    $RestoreFullCmd = "RESTORE DATABASE [$($DestinationDatabase)] FROM  DISK = N'$($FullBackupFile.FullName)' WITH "
    
    # This command returns the filenames of the source database
    $dbfiles = Invoke-SqlCmd -ServerInstance $DestinationServer -Query "RESTORE FILELISTONLY FROM DISK = '$($FullBackupFile.FullName)'" -ErrorAction Stop

    # Loop through the dbfiles and create the MOVE commands for the restore query
    foreach ($dbfile in $dbfiles)
    {
        if ($dbfile.Type -eq "D")
        {
            $RestoreFullCmd += "MOVE N'$($dbfile.LogicalName)' TO N'$DataDrive$($dbfile.LogicalName)_$(Get-Date -Format "yyyyMMdd_hhmmss").mdf', "
        }

        elseif ($dbfile.Type -eq "L")
        {
            $RestoreFullCmd += "MOVE N'$($dbfile.LogicalName)' TO N'$LogDrive$($dbfile.LogicalName)_$(Get-Date -Format "yyyyMMdd_hhmmss").ldf', "
        }
    }

    # Once the restore command is complete, add a NORECOVERY (in case of DIFF/LOG to add)
    $RestoreFullCmd += "NORECOVERY"

    # Start the FULL restore
    Outputlog $logpath "Starting FULL restore on $DestinationServer from $($FullBackupFile.FullName)"
    Outputlog $logpath $RestoreFullCmd
    Invoke-Sqlcmd -ServerInstance $DestinationServer -Query $RestoreFullCmd -QueryTimeout 0 -ErrorAction Stop
    Outputlog $logpath "Completed FULL restore on $DestinationServer from $($FullBackupFile.FullName)"

    # If a PIT parm is not passed in (null) then get the latest DIFF backup that comes after the FULL
    if([string]::IsNullOrEmpty($PIT))
    {
        $DiffBackupFile = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*DIFF*" -and $_.LastWriteTime -gt $fullbackupfile.LastWriteTime} | Sort LastWriteTime | Select -Last 1
    }

    # Else if PIT is not null then get the latest latest DIFF backup that comes after the FULL AND BEFORE the PIT timestamp
    else
    {
        $DiffBackupFile = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*DIFF*" -and $_.LastWriteTime -gt $fullbackupfile.LastWriteTime -and $_.LastWriteTime -lt $PIT} | Sort LastWriteTime | Select -Last 1
    }

    # If a DIFF backup is found then restore it
    if ([string]::IsNullOrEmpty($DiffBackupFile) -eq $false)
    {
        # Begin DIFF restore with NORECOVERY still
        Outputlog $logpath "DIFF BACKUP file for $SourceServer $SourceDatabase is $($DiffBackupFile.FullName) "
        Outputlog $logpath "Starting DIFF restore on $DestinationServer from $($DiffBackupFile.FullName)"
        $RestoreDiffCmd = "RESTORE DATABASE [$($DestinationDatabase)] FROM DISK = '$($DiffBackupFile.FullName)' WITH NORECOVERY;"
        Outputlog $logpath $RestoreDiffCmd
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Query $RestoreDiffCmd -QueryTimeout 0 -ErrorAction Stop
        Outputlog $logpath "Completed DIFF restore on $DestinationServer from $($DiffBackupFile.FullName)"

        # If a PIT parm is not passed in (null) then get the latest LOG backup that comes after the DIFF
        if([string]::IsNullOrEmpty($PIT))
        {
            $LogFiles = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*LOG*" -and $_.LastWriteTime -gt $diffbackupfile.LastWriteTime} | Sort LastWriteTime
        }

        # Else if PIT is not null then get the latest latest LOG backup that comes after the DIFF AND BEFORE the PIT timestamp
        else
        {
            $LogFiles = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*LOG*" -and $_.LastWriteTime -gt $diffbackupfile.LastWriteTime -and $_.LastWriteTime -lt $PIT.AddHours(2)} | Sort LastWriteTime
        }

        Outputlog $logpath "LOG BACKUP count for $SourceServer $SourceDatabase is $($LogFiles.Count)"
    }

    # If a DIFF is not found then proceed to LOG files
    else
    {
        Outputlog $logpath "No DIFF BACKUP file found"
        
        # If a PIT parm is not passed in (null) then get the latest LOG backup that comes after the FULL
        if([string]::IsNullOrEmpty($PIT))
        {
            $LogFiles = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*LOG*" -and $_.LastWriteTime -gt $fullbackupfile.LastWriteTime} | Sort LastWriteTime
        }

        # Else if PIT is not null then get the latest latest LOG backup that comes after the FULL AND BEFORE the PIT timestamp
        else
        {
            $LogFiles = Get-ChildItem $EnvironmentPath\$SourceServer\$SourceDatabase | Where {$_.Name -Like "*LOG*" -and $_.LastWriteTime -gt $fullbackupfile.LastWriteTime -and $_.LastWriteTime -lt $PIT.AddHours(2)} | Sort LastWriteTime
        }

        Outputlog $logpath "LOG BACKUP count for $SourceServer $SourceDatabase is $($LogFiles.Count)"
    }

    # If a PIT parm is not passed in (null) then loop through all the LOG files and restore them with a simple foreach
    if([string]::IsNullOrEmpty($PIT))
    {
        foreach ($Log in $LogFiles)
        { 
            Outputlog $logpath "Starting LOG restore on $DestinationServer from $($Log.FullName)"
            $RestoreLogCmd = "RESTORE LOG [$($DestinationDatabase)] FROM DISK = '$($Log.FullName)' WITH NORECOVERY;"
            Outputlog $LogPath $RestoreLogCmd
            Invoke-Sqlcmd -ServerInstance $DestinationServer -Query $RestoreLogCmd -QueryTimeout 0 -ErrorAction Stop
            Outputlog $logpath "Completed LOG restore on $DestinationServer from $($Log.FullName)"
        }
    }

    # Else if PIT is not null then use a for loop with an indexer to identify the final LOG to apply the STOPAT
    else
    {
        for($x = 0; $x -le $LogFiles.Count - 1; $x++)
        {
            # If this is the final LOG then include the STOPAT keyword for the PIT
            if ($x -eq $LogFiles.Count - 1)
            {
                Outputlog $logpath "Starting LOG restore on $DestinationServer from $($LogFiles[$x].FullName) with STOPAT = $PIT"
                $RestoreLogCmd = "RESTORE LOG [$($DestinationDatabase)] FROM DISK = '$($LogFiles[$x].FullName)' WITH STOPAT = '$PIT', NORECOVERY;"
                Outputlog $LogPath $RestoreLogCmd
                Invoke-Sqlcmd -ServerInstance $DestinationServer -Query $RestoreLogCmd -QueryTimeout 0 -ErrorAction Stop
                Outputlog $logpath "Completed LOG restore on $DestinationServer from $($LogFiles[$x].FullName) WITH STOPAT = $PIT"                
            }

            # For all other LOG files just restore them normally
            else
            {
                Outputlog $logpath "Starting LOG restore on $DestinationServer from $($LogFiles[$x].FullName)"
                $RestoreLogCmd = "RESTORE LOG [$($DestinationDatabase)] FROM DISK = '$($LogFiles[$x].FullName)' WITH NORECOVERY;"
                Outputlog $LogPath $RestoreLogCmd
                Invoke-Sqlcmd -ServerInstance $DestinationServer -Query $RestoreLogCmd -QueryTimeout 0 -ErrorAction Stop
                Outputlog $logpath "Completed LOG restore on $DestinationServer from $($LogFiles[$x].FullName)"
            }
        }
    }

    # Once all of the files have been restored, run the recovery command to bring the database online
    Outputlog $logpath "Starting DATABASE RECOVERY on $DestinationServer "
    Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "RESTORE DATABASE [$($DestinationDatabase)] WITH RECOVERY" -QueryTimeout 0 -ErrorAction Stop
    Outputlog $logpath "Completed DATABASE RECOVERY on $DestinationServer "

    # Change the database owner
    Outputlog $logpath "Starting change the database owner on $DestinationServer $DestinationDatabase"
    Invoke-Sqlcmd -ServerInstance $DestinationServer -Query "ALTER AUTHORIZATION ON DATABASE::[$($DestinationDatabase)] TO [ccsaid]" -ErrorAction Stop
    Outputlog $logpath "Completed change the database owner on $DestinationServer $DestinationDatabase"

    Outputlog $logpath "Starting DROP/CREATE USERS on $DestinationServer $($DestinationDatabase)"

    # This query will create the alter commands and execute them all in one call to change any schema owners to ccsaid
    $dropschemaquery = "
        DECLARE @drop varchar(max) = '';
        SELECT @drop += 'ALTER AUTHORIZATION ON SCHEMA::' + s.name + ' TO dbo;'
        FROM sys.schemas s
        INNER JOIN sys.sysusers u ON s.principal_id = u.uid
        WHERE islogin = 1 AND hasdbaccess = 1 AND u.name <> 'dbo' 
        EXEC (@drop);"

    Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $dropschemaquery -ErrorAction Stop -QueryTimeout 0
    Outputlog $logpath "Changed schema owners on $DestinationServer $($DestinationDatabase)"

    # This query will create the drop users commands and execute them in one call
    $dropuserquery = "
        DECLARE @drop varchar(max) = '';
        SELECT @drop += 'DROP USER [' + name + ']; ' FROM sys.sysusers WHERE islogin = 1 AND hasdbaccess = 1 AND name <> 'dbo';
        EXEC (@drop);"

    Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $dropuserquery -ErrorAction Stop -QueryTimeout 0
    Outputlog $logpath "Dropped users on $DestinationServer $($DestinationDatabase)"

    # If there are scripted users from the destination database then re-create them here
    if ([string]::IsNullOrEmpty($adduserquery) -eq $false)
    {
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $adduserquery -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Added new users on $DestinationServer $($DestinationDatabase)"
    }
   
    # If there are scripted role assignments from the destination database then re-create them here
    if ([string]::IsNullOrEmpty($addrolequery) -eq $false)
    {
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $addrolequery -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Added user roles on $DestinationServer $($DestinationDatabase)"
    }

    # If there are scripted explicit permissions then re-create them here
    if ([string]::IsNullOrEmpty($adduserexplicityquery) -eq $false)
    {
        Invoke-Sqlcmd -ServerInstance $DestinationServer -Database "$($DestinationDatabase)" -Query $adduserexplicityquery -ErrorAction Stop -QueryTimeout 0
        Outputlog $logpath "Added user explicit access on $DestinationServer $($DestinationDatabase)"
    }

    # IT IS DONE
    Outputlog $logpath "Completed DROP/CREATE USERS on $DestinationServer "
    Outputlog $logpath "Refresh script has completed successfully."
}

catch
{
    # If anything went wrong output the full message to the log
    Outputlog $logpath "ERROR: $Error"

    # Using the throw command in case this is called from a job
    throw $_  
}
