<#
    Script: MR_CreateNewAccount.ps1
    Purpose:
        This script will create a local login on SQL, Postgres, or Oracle.  Two jobs will call this script, passing in
        an environment parameter.  One job will run as z_sqlidk for PROD and will handle all PROD SQL, PROD ORA, 
        TEST ORA, PROD PSQL, and TEST PSQL.  The other job will run as zt_sqlidk and will handle all TEST SQL.

    Steps:
        1. Query unprocessed accounts from MR provisioning table
        2. 1st loop for each account:
            QUERY SERVINFO FOR THE DOMAIN OF SERVER
        3. 2nd loop for each account:
            CHECK THAT LOOKUP WAS SUCCESSFUL, IF NOT SET THE PROCESSED COLUMN TO FAILURE CODE 10
            IF DOMAIN IS SQL PROD AND SCRIPT ENV IS PROD THEN CREATE LOGIN AND MARK PROCESSED = 1
            IF DOMAIN IS SQL TEST AND SCRIPT ENV IS TEST THEN CREATE LOGIN AND MARK PROCESSED = 1
            IF DOMAIN IS ORA PROD AND SCRIPT ENV IS PROD THEN CREATE LOGIN USING PROD CREDENTIAL AND MARK PROCESSED = 1
            IF DOMAIN IS ORA TEST AND SCRIPT ENV IS PROD THEN CREATE LOGIN USING TEST CREDENTIAL AND MARK PROCESSED = 1
            IF PSQL PROD AND SCRIPT ENV IS PROD THEN CREATE LOGIN USING PROD CREDENTIAL AND MARK PROCESSED = 1
            IF PSQL TEST AND SCRIPT ENV IS PROD THEN CREATE LOGIN USING TEST CREDENTIAL AND MARK PROCESSED = 1

                ON SUCCESS MARK THE PROCESSED COLUMN WITH A SUCCESS CODE 1
                ON FAILURE MARK THE PROCESSED COLUMN WITH A SUCCESS CODE 66

    Table: ADD_LOCAL_DBLOGIN
        ROW_ID        - Identity column/PK
        LOGINNAME     - Account name
        SERVERNAME    - Server name
        DATABASENAME  - Associated DB (for Oracle)
        DBMS          - Platform
        ACCOUNT_TYPE  - Oncall or Service (for Oracle)
        CREATE_TS     - Time of request
        SysStartTime  - System
        SysEndTime    - System
        PROCESSED     - Status of request (null/0 = not processed, 1 = complete, 66 = creation failure, 10 = lookup failure)
            
                
    Domains:
        Test:
            ALLIANCEDEV.LAN
            ALLIANCEQA.LAN
            CORP.ALLIANCE.TST
            COUNTRYLAN.NET
            FINANCIALDEV.LAN
            FINANCIALQA.LAN
        Prod:
            ICM.LAN
            FS.ALLIANCE.LAN
            COUNTRYLAN.COM
            CORP.ALLIANCE.LAN


#>


# Functions
function f_GetCyberarkPassword ($uri)
{
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $CCPCall = Invoke-WebRequest -Uri $uri -UseBasicParsing
    $password = ($CCPCall.Content | ConvertFrom-JSON).Content
    return $password
}


function f_WriteLog ($MRServer, $MRDatabase, $rowid, $msg)
{
    try
    {
        # Clear any bad characters
        $msg = $msg -replace "'", ""


        # Create the insert
        $Query = "INSERT MR_ERROR_LOG VALUES (GETDATE(), $rowid, '$msg')"


        # Create and open a connection to the server
        $SQL_CONN = New-Object System.Data.SqlClient.SqlConnection("Data Source=$MRServer;Database=$MRDatabase;Integrated Security=SSPI;")
        $SQL_CONN.Open()


        # Create the command and query to write to the log, then execute
        $SQLCMD = New-Object System.Data.SqlClient.SqlCommand($Query, $SQL_CONN)
        $SQLCMD.ExecuteNonQuery() | Out-Null    
        

        # Close the connection
        $SQL_CONN.Close()    
    }

    catch
    {
        # If logging the error has an error then just give up and fail the job
        throw $_
        return;
    }
}


# Load assembly for password generation
Add-Type -AssemblyName System.Web


# Arguments
#$SQLENV = "TEST"
$SQLENV = $args[0]


# Parms to use
$OracleProdAccount = "z_orauto"
$OracleTestAccount = "zt_orauto"

$PSQLProdAccount = "z_pgadministrator"
$PSQLTestAccount = "zt_pgadministrator"

$MRServer = "C1DBD069"
$MRDatabase = "MR_DBLOGIN_PROVISIONING"


# Get unprocessed accounts
try
{
    $Query = "SELECT ROW_ID, LOGINNAME, SERVERNAME, DATABASENAME, DBMS, ACCOUNT_TYPE  
                FROM ADD_LOCAL_DBLOGIN
                WHERE PROCESSED IS NULL
                OR PROCESSED = 0"

    $Accounts = @()
    $Accounts += Invoke-Sqlcmd -ServerInstance $MRServer -Database $MRDatabase -Query $Query
}

catch
{
    throw $_
}

# If there are accounts, get the SERVINFO credential and create a connection
if ($Accounts.Count -gt 0)
{
    try
    {
        # Get the password and create the SERVINFO connection
        $PW = f_GetCyberarkPassword -uri "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=Wapp_SQLServerAuthAccessApp&Safe=SQLDBAutomation_Svc&Username=z_sqlint&Reason=MR account creation&Address=zos-ssh.countrylan.com"
        $SERVINFO_Conn = New-Object System.Data.Odbc.OdbcConnection
        $SERVINFO_Conn.ConnectionString = "DSN=SERVINFO;uid=z_sqlint;pwd=$PW"
        $SERVINFO_Conn.Open()


        # Add a property for domain and environment to the account object
        $Accounts | Add-Member -NotePropertyName DOMAIN -NotePropertyValue $null
        $Accounts | Add-Member -NotePropertyName ENVIRONMENT -NotePropertyValue $null
    }

    catch
    {
        # Write error
        f_WriteLog -MRServer $MRServer -MRDatabase $MRDatabase -rowid "-1" -msg $_


        # SERVINFO is vital to the script to continue, an error here is fatal and will fail the job
        throw $_
        return;
    }
}


# Loop through all accounts to determine their domain from SERVINFO and assign a PROD or TEST value to their environment
for ($count = 0; $count -lt $Accounts.Count; $count++)
{
    try
    {
        # If this is postgres we do not need SERVINFO
        if ($Accounts[$count].DBMS -eq "POSTGRESQL")
        {
            # Domain is always the same for PSQL
            $Accounts[$count].DOMAIN = "postgres.database.azure.com"

            # Azure naming standards include the environment followed by a - symbol
            if ($Accounts[$count].SERVERNAME.Split("-")[0] -eq "prod")
            {
                # If the name starts with prod this is a prod server
                $Accounts[$count].ENVIRONMENT = "PROD"
                
                # This account's environment is set, we can continue to the next account
                continue;
            }

            else
            {
                # If the name did not start with prod then it is a test server
                $Accounts[$count].ENVIRONMENT = "TEST"
                
                # This account's environment is set, we can continue to the next account
                continue;
            }
        }

        # Query for SERVINFO DOMAIN_NM and assign to accounts object
        $Query = "SELECT DOMAIN_NM FROM CCDB2.MDB_SRVR_DATA WHERE SRVR_NM = '$($Accounts[$count].SERVERNAME)'"
        $cmd = New-object System.Data.Odbc.OdbcCommand($Query, $SERVINFO_Conn)
        $read = $cmd.ExecuteReader()
        $read.Read() | Out-Null
        $Accounts[$count].DOMAIN = $read["DOMAIN_NM"];


        # Check the domain name and set the environment to PROD/TEST
        switch ($Accounts[$count].DOMAIN)
        {
            "ALLIANCEDEV.LAN" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "ALLIANCEQA.LAN" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "CORP.ALLIANCE.TST" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "COUNTRYLAN.NET" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "FINANCIALDEV.LAN" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "FINANCIALQA.LAN" { $Accounts[$count].ENVIRONMENT = "TEST" }
            "ICM.LAN" { $Accounts[$count].ENVIRONMENT = "PROD" }
            "FS.ALLIANCE.LAN" { $Accounts[$count].ENVIRONMENT = "PROD" }
            "COUNTRYLAN.COM" { $Accounts[$count].ENVIRONMENT = "PROD" }
            "CORP.ALLIANCE.LAN" { $Accounts[$count].ENVIRONMENT = "PROD" }
        }
    }

    catch
    {
        # If there is an issue in this code block, log the error but continue execution
        f_WriteLog -MRServer $MRServer -MRDatabase $MRDatabase -rowid $Accounts[$count].ROW_ID -msg $_
        continue;
    }
}


# SERVINFO is done, close the connection
$SERVINFO_Conn.Close()


# Loop through all accounts and create the logins
foreach ($Account in $Accounts)
{
    try
    {
        # If the environment lookup did not work, skip this account and mark it as failed
        if ([string]::IsNullOrEmpty($Account.ENVIRONMENT))
        {
            $Query = "
                UPDATE ADD_LOCAL_DBLOGIN SET PROCESSED = 10 
                WHERE ROW_ID = $($Account.ROW_ID)"
        
            Invoke-Sqlcmd -ServerInstance $MRServer -Database $MRDatabase -Query $Query

            continue;
        }


        # If this is a SQL account and is for a different SQL domain than the environment context, skip this account
        if ($Account.ENVIRONMENT -ne $SQLENV -and $Account.DBMS -eq "SQL")
        {
            continue;
        }


        # If this is not a SQL account and is for the test domain SQL job, skip this account
        if ($SQLENV -eq "TEST" -and $Account.DBMS -ne "SQL")
        {
            continue;
        }


        # Generate a temporary password (this is not retained)
        $temppassword = [System.Web.Security.Membership]::GeneratePassword(16, 1)


        # If this is a SQL login, create the login
        if ($Account.DBMS -eq "SQL")
        {
            # Create and open a connection to the server
            $SQL_CONN = New-Object System.Data.SqlClient.SqlConnection("Data Source=$($Account.SERVERNAME).$($Account.DOMAIN);Integrated Security=SSPI;")
            $SQL_CONN.Open()


            # Create the command and query to create login, then execute
            $SQLCMD = New-Object System.Data.SqlClient.SqlCommand("CREATE LOGIN [$($Account.LOGINNAME)] WITH PASSWORD='$temppassword', CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF", $SQL_CONN)
            $SQLCMD.ExecuteNonQuery() | Out-Null


            # Close the connection
            $SQL_CONN.Close()
        }


        # If this is Postgres then create the Postgres account
        if ($Account.DBMS -eq "POSTGRESQL")
        {
            if ($Account.ENVIRONMENT -eq "PROD")
            {
                # Pull the prod account password
                $PSQLProdPW = f_GetCyberarkPassword "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=WAPP_PostgresAuthAccessApp&Safe=PostgresDBAutomation_Svc&Username=$PSQLProdAccount&Reason=Login creation tool&Address=$($Account.SERVERNAME)"
                
                # Create the connection string
                $PSQL_ConnectionString = "Driver={PostgreSQL UNICODE(x64)};Server=$($Account.SERVERNAME);Port=5432;Database=postgres;Uid=$PSQLProdAccount@$($Account.SERVERNAME);Pwd=$PSQLProdPW;sslmode=require"
                
                # Create the ODBC object
                $PSQL_CONN = New-Object System.Data.Odbc.OdbcConnection
                
                # Set the connection string and open the connection
                $PSQL_CONN.ConnectionString = $PSQL_ConnectionString
                $PSQL_CONN.Open()
            }

            else
            {
                # Pull the test account password
                $PSQLTestPW = f_GetCyberarkPassword "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=WAPP_PostgresAuthAccessApp&Safe=PostgresDBAutomation_Svc&Username=$PSQLTestAccount&Reason=Login creation tool&Address=$($Account.SERVERNAME)"
                
                # Create the connection string                
                $PSQL_ConnectionString = "Driver={PostgreSQL UNICODE(x64)};Server=$($Account.SERVERNAME);Port=5432;Database=postgres;Uid=$PSQLTestAccount@$($Account.SERVERNAME);Pwd=$PSQLTestPW;sslmode=require"
                
                # Create the ODBC object
                $PSQL_CONN = New-Object System.Data.Odbc.OdbcConnection
                
                # Set the connection string and open the connection
                $PSQL_CONN.ConnectionString = $PSQL_ConnectionString
                $PSQL_CONN.Open()
            }

            # Create the command object with CREATE ROLE command
            $PSQLCMD = $PSQL_CONN.CreateCommand()
            $PSQLCMD.CommandText = "CREATE ROLE $($Account.LOGINNAME.ToLower()) WITH LOGIN PASSWORD '$temppassword';"

            # Execute the command
            $PSQLCMD.ExecuteNonQuery()            

            # Close the connection
            $PSQL_CONN.Close()
        }


        # If this is Oracle then create the Oracle account account
        if ($Account.DBMS -eq "ORACLE")
        {
            if ($Account.ENVIRONMENT -eq "PROD")
            {
                # Pull the prod account password
                $OracleProdPW = f_GetCyberarkPassword "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=WAPP_OracleAuthAccessApp&Safe=OracleDBAutomation_Svc&Username=$OracleProdAccount&Reason=Login creation tool&Address=$($Account.SERVERNAME)"
                

                # Create the connection string
                $Oracle_ConnectionString = "Driver={Oracle in instantclient_19_10};DBQ=$($Account.SERVERNAME).$($Account.DOMAIN):1521/$($Account.DATABASENAME);Uid=$OracleProdAccount;Pwd=$OracleProdPW;"
                

                # Create the ODBC object
                $Oracle_CONN = New-Object System.Data.Odbc.OdbcConnection
                

                # Set the connection string and open the connection
                $Oracle_CONN.ConnectionString = $Oracle_ConnectionString
                $Oracle_CONN.Open()
            }

            else
            {
                # Pull the test account password
                $OracleTestPW = f_GetCyberarkPassword "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=WAPP_OracleAuthAccessApp&Safe=OracleDBAutomation_Svc&Username=$OracleTestAccount&Reason=Login creation tool&Address=$($Account.SERVERNAME)"
                

                # Create the connection string                
                $Oracle_ConnectionString = "Driver={Oracle in instantclient_19_10};DBQ=$($Account.SERVERNAME).$($Account.DOMAIN):1521/$($Account.DATABASENAME);Uid=$OracleTestAccount;Pwd=$OracleTestPW;"
                

                # Create the ODBC object
                $Oracle_CONN = New-Object System.Data.Odbc.OdbcConnection
                

                # Set the connection string and open the connection
                $Oracle_CONN.ConnectionString = $Oracle_ConnectionString
                $Oracle_CONN.Open()
            }


            # Create the Oracle command object
            $Oracle_Cmd = $Oracle_CONN.CreateCommand()


            # Add the create user statement and execute
            # If the account type is on-call then use the ONCALL_PROFILE
            if ($Account.ACCOUNT_TYPE -eq "On-call")
            {
                $query = "
                CREATE USER $($Account.LOGINNAME.ToUpper()) IDENTIFIED BY `"$temppassword`"
                PROFILE ONCALL_PROFILE
                DEFAULT TABLESPACE USERS
                QUOTA UNLIMITED ON USERS
                TEMPORARY TABLESPACE TEMP
                PASSWORD EXPIRE;"
            }

            # Else if the account type is service then use the APPLICATION_PROFILE
            elseif ($Account.ACCOUNT_TYPE -eq "Service")
            {
                $query = "
                CREATE USER $($Account.LOGINNAME.ToUpper()) IDENTIFIED BY `"$temppassword`"
                PROFILE APPLICATION_PROFILE
                DEFAULT TABLESPACE USERS
                QUOTA UNLIMITED ON USERS
                TEMPORARY TABLESPACE TEMP
                PASSWORD EXPIRE;"
            }

            $Oracle_Cmd.CommandText = $query
            $Oracle_Cmd.ExecuteNonQuery()


            # Grant connect
            $query = "
            GRANT CONNECT TO $($Account.LOGINNAME);"

            $Oracle_Cmd.CommandText = $query
            $Oracle_Cmd.ExecuteNonQuery()


            # Grant default connect role
            $query = "
            ALTER USER $($Account.LOGINNAME.ToUpper()) DEFAULT ROLE CONNECT;"

            $Oracle_Cmd.CommandText = $query
            $Oracle_Cmd.ExecuteNonQuery()


            # Close the connection
            $Oracle_CONN.Close()
        }


        # If the code makes it here it must have worked, update the PROCESSED field
        $Query = "
            UPDATE ADD_LOCAL_DBLOGIN SET PROCESSED = 1 
            WHERE ROW_ID = $($Account.ROW_ID)"
        
        Invoke-Sqlcmd -ServerInstance $MRServer -Database $MRDatabase -Query $Query
    }

    catch 
    {
        # If the account creation fails, just log it and move on
        f_WriteLog -MRServer $MRServer -MRDatabase $MRDatabase -rowid $Account.ROW_ID -msg $_

        # Set processed to -1 for creation failure
        $Query = "
            UPDATE ADD_LOCAL_DBLOGIN SET PROCESSED = 66 
            WHERE ROW_ID = $($Account.ROW_ID)"
        
        Invoke-Sqlcmd -ServerInstance $MRServer -Database $MRDatabase -Query $Query

        continue;
    }
}
