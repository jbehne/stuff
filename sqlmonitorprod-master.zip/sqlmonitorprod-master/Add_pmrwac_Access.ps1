$query = "DECLARE @db varchar(max), @cmd varchar(max), @account varchar(128);

SELECT @account = name FROM sys.syslogins WHERE name LIKE '%pmrwac'
IF @account IS NULL
	return;

DECLARE c CURSOR STATIC
FOR 
SELECT name FROM sys.databases;

OPEN c;

FETCH NEXT FROM c INTO @db;

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @cmd = 'USE [' + @db + ']
				IF NOT EXISTS (SELECT name FROM sys.sysusers WHERE name = ''' + @account + ''')
					CREATE USER [' + @account + ']';
					

	EXEC (@cmd);

	FETCH NEXT FROM c INTO @db;
END;


CLOSE c;
DEALLOCATE c;"

$servers = (Invoke-Sqlcmd -ServerInstance $args[0] -Database SQLMONITOR -Query "SELECT ServerName FROM Perf_MonitoredServers WHERE IsActive = 1").ServerName

foreach ($server in $servers)
{
    Invoke-Sqlcmd -ServerInstance $server -Query $query
}
