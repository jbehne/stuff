<#
    Name:    LoadSQLMonitor_Data.ps1
    Date:    10/02/19
    Author:  JB
    Purpose: This script loads details about instances and databases into the SQLMONITOR database.

#>

# This is the primary function, it takes an instance object and does all of the querying and updating
function f_Collect ($instance) {
    try {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=.;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Integrated Security=true")
        $sqlconn.Open()

        ### Update repository server settings
		$query = "
				DECLARE @tbl TABLE ([Index] VARCHAR(2000), [Name] VARCHAR(2000), [Internal_Value] VARCHAR(2000), [Character_Value] VARCHAR(2000));
				DECLARE @domain TABLE (Name varchar(128), Value varchar(128));

                INSERT @tbl EXEC xp_msver;
				INSERT @domain EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE', @key='SYSTEM\ControlSet001\Services\Tcpip\Parameters\',@value_name='Domain'
                
                SELECT Name, Internal_Value FROM @tbl WHERE Name IN ('ProcessorCount', 'PhysicalMemory')
                UNION ALL
                SELECT name, value_in_use FROM sys.configurations WHERE name like 'max server memory%'
                UNION ALL
                SELECT 'Version', SERVERPROPERTY('ProductVersion')
                UNION ALL
                SELECT 'Edition', SERVERPROPERTY('Edition')
                UNION ALL
                SELECT 'Collation', SERVERPROPERTY('Collation')
                UNION ALL
				SELECT Name, Value FROM @domain
				UNION ALL
				SELECT 'SQLServiceAccount', service_account FROM sys.dm_server_services WHERE servicename LIKE 'SQL SERVER (%'
				UNION ALL
				SELECT 'AgentServiceAccount', service_account FROM sys.dm_server_services WHERE servicename LIKE 'SQL SERVER Agent (%'
				UNION ALL
                SELECT 'OSVersion', 
				CASE windows_release
					WHEN 10.0 THEN 'Windows Server 2016'
					WHEN 6.3 THEN 'Windows Server 2012 R2'
					WHEN 6.2 THEN 'Windows Server 2012'
					WHEN 6.1 THEN 'Windows Server 2008 R2'
					WHEN 6.0 THEN 'Windows Server 2008' END
				FROM sys.dm_os_windows_info"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        while ($sqlreader.Read())
        {
            switch ($sqlreader["Name"])
            {
                'ProcessorCount' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'ProcCores', '" + $sqlreader["Internal_Value"] + "'" }
                'PhysicalMemory' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'ServerMemory', '" + $sqlreader["Internal_Value"] + "'" }
                'max server memory (MB)' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'MaxMemory', '" + $sqlreader["Internal_Value"] + "'" }
                'Version' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Version', '" + $sqlreader["Internal_Value"] + "'" }
                'Edition' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Edition', '" + $sqlreader["Internal_Value"] + "'" }
                'Collation' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Collation', '" + $sqlreader["Internal_Value"] + "'" }
                'OSVersion' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'OSVersion', '" + $sqlreader["Internal_Value"] + "'" }
                'Domain' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Domain', '" + $sqlreader["Internal_Value"] + "'" }
                'SQLServiceAccount' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'SQLServiceAccount', '" + $sqlreader["Internal_Value"] + "'" }
                'AgentServiceAccount' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'AgentServiceAccount', '" + $sqlreader["Internal_Value"] + "'" }
            }
            
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $updatequery
        }

        Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "UPDATE Perf_MonitoredServers_Data SET LastUpdated = GETDATE() WHERE InstanceID = $($instance.InstanceID)"
        $sqlreader.Close()

        ### Database Information
        $localdblist = @()
        if ($instance.ServerName -like "*AWH*" -or $instance.ServerName -like "*RGR*" -or $instance.ServerName -like "*CMP*" -or $instance.ServerName -like "*IPT*")
        {
            $query = "
                WITH logins AS (
    	            SELECT name account_name, sid account_sid FROM sys.syslogins)
    
                SELECT $($instance.InstanceID)InstanceID, d.name DatabaseName, l.account_name Owner, collation_name Collation, recovery_model_desc RecoveryModel, 
                                    CAST(compatibility_level AS varchar) CompatibilityLevel, page_verify_option_desc PageVerify, CAST(is_encrypted AS tinyint) Encrypted, 
                                    CAST(snapshot_isolation_state AS tinyint) AllowSnapshotIsolation, CAST(is_read_committed_snapshot_on AS tinyint) ReadCommittedSnapshot, 
                                    CAST(is_trustworthy_on AS tinyint) Trustworthy
                                    FROM sys.databases d
                                    LEFT OUTER JOIN logins l ON l.account_sid = d.owner_sid"            
        }
        
        else
        {
            $query = "
                DECLARE @xp_logininfo TABLE(account_name sysname, type char(8), privilege char(9), mapped_login_name sysname, permission_path sysname);
                INSERT INTO @xp_logininfo EXEC xp_logininfo N'ALLIANCE\DBA Sensitive Server Users','members';
                WITH logins AS (
    	            SELECT account_name, SUSER_SID(account_name) AS account_sid FROM @xp_logininfo
    	            UNION
    	            SELECT name, sid FROM sys.syslogins)
    
                SELECT $($instance.InstanceID)InstanceID, d.name DatabaseName, l.account_name Owner, collation_name Collation, recovery_model_desc RecoveryModel, 
                                    CAST(compatibility_level AS varchar) CompatibilityLevel, page_verify_option_desc PageVerify, CAST(is_encrypted AS tinyint) Encrypted, 
                                    CAST(snapshot_isolation_state AS tinyint) AllowSnapshotIsolation, CAST(is_read_committed_snapshot_on AS tinyint) ReadCommittedSnapshot, 
                                    CAST(is_trustworthy_on AS tinyint) Trustworthy
                                    FROM sys.databases d
                                    LEFT OUTER JOIN logins l ON l.account_sid = d.owner_sid"
        }
        
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        while ($sqlreader.Read())
        {
            $localdblist += $sqlreader["DatabaseName"]
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'Owner', '" + $($sqlreader["Owner"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'Collation', '" + $($sqlreader["Collation"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'RecoveryModel', '" + $($sqlreader["RecoveryModel"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'CompatibilityLevel', '" + $($sqlreader["CompatibilityLevel"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'PageVerify', '" + $($sqlreader["PageVerify"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'Encrypted', '" + $($sqlreader["Encrypted"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'AllowSnapShotIsolation', '" + $($sqlreader["AllowSnapShotIsolation"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'ReadCommittedSnapshot', '" + $($sqlreader["ReadCommittedSnapshot"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            $query = "EXEC usp_UpdateDatabase " + $instance.InstanceID + ", '" + $sqlreader["DatabaseName"] + "', 'Trustworthy', '" + $($sqlreader["Trustworthy"]) + "';"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "UPDATE Perf_MonitoredDatabases SET LastUpdated = GETDATE() WHERE InstanceID = $($instance.InstanceID) AND DatabaseName = '$($sqlreader["DatabaseName"])'"
        }

        $repodblist = (Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "SELECT DatabaseName FROM Perf_MonitoredDatabases WHERE InstanceID = $($instance.InstanceID)").DatabaseName
        $comparedb = Compare-Object -ReferenceObject $localdblist -DifferenceObject $repodblist
        foreach ($db in $comparedb)
        {
            $query = "DELETE Perf_MonitoredDatabases WHERE InstanceID = $($instance.InstanceID) AND DatabaseName = '" + $db.InputObject + "';
             INSERT Perf_MonitoredDatabases_History VALUES (GETDATE(), $($instance.InstanceID), '" + $db.InputObject + "', 'Remove Database', '', '');"
            Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query           
        }

        $sqlreader.Close()
        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch {
        $err = "LoadSQLMonitor_Data.ps1 - " + $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }
}

workflow wf_CollectAll ($instances) {
    foreach -parallel -throttlelimit 4 ($instance in $instances) {
        f_Collect $instance
    }
}

### Program Start

# Set query to get servers
$query = "SELECT ServerName, InstanceID FROM Perf_MonitoredServers WHERE IsActive = 1"

# Get servers
$instances = @(Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query -QueryTimeout 600 -ConnectionTimeout 600)

# Call the workflow with the list of servers
wf_CollectAll $instances


