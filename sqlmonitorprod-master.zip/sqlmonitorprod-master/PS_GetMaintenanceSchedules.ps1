﻿$Global:repository = $args[0]

function f_LoadSchedules ($server)
{
    try
    {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()
        
        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 120

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Database=msdb;Integrated Security=true")
        $sqlconn.Open()
        
        $query = "SELECT $($server.InstanceID), REPLACE(j.name, 'Maintenance - ', ''), j.enabled, ss.enabled,
                freq_type, freq_interval, freq_subday_type, freq_subday_interval, freq_relative_interval, freq_recurrence_factor,
                active_start_time, active_end_time
                FROM sysjobs j
                INNER JOIN sysjobschedules js ON j.job_id = js.job_id
                INNER JOIN sysschedules ss ON js.schedule_id = ss.schedule_id
                WHERE j.name LIKE 'Maintenance%'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Maintenance_Schedule_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()        
    
        $query = "IF EXISTS (SELECT name FROM SQLADMIN.sys.objects WHERE name = 'Backup_Options') SELECT $($server.InstanceID), * FROM SQLADMIN.dbo.Backup_Options"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Maintenance_BackupOptions"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()    
    }
    
    catch
    {
        "$($server.ServerName) experienced an error"
    }      
}

workflow wf_LoadSchedules ($servers)
{
    foreach -parallel -throttlelimit 4 ($server in $servers) 
    {
        f_LoadSchedules $server
    }
}

Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Maintenance_Schedule_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Maintenance_BackupOptions"
$servers = Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "SELECT InstanceID, ServerName FROM Perf_MonitoredServers WHERE IsActive = 1"
wf_LoadSchedules $servers
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "EXEC usp_Maintenance_MergeSchedules"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "EXEC usp_MergeJobDuration"
