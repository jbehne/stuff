function CheckConnection ($s)
{
    $ping = Test-Connection -ComputerName $s.ServerName -Count 2 -BufferSize 16 -ErrorAction 0 -Quiet
    $sqlconnection = 0
    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=.;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    try
    {
        $conn = New-Object System.Data.SqlClient.SqlConnection ("Data Source=$($s.ServerName);Integrated Security=SSPI;Connection Timeout=60")
        $conn.Open()

        $cmd = New-Object System.Data.SqlClient.SqlCommand ("SELECT $($s.InstanceID) InstanceID, name, state_desc FROM sys.databases", $conn)
        $sqlreader = $cmd.ExecuteReader()

        $bc.DestinationTableName = "Alert_DatabaseStatus_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        $conn.Close()
        $sqlconnection = 1
    }

    catch
    {
        Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($s.InstanceID), 'PS_Alert_ConnectionStatus - $_')"
        $sqlconnection = 0
    }

    $repositoryconnection.Close()

    if ($ping -eq $true)
    {
        $ping = 1
    }
    
    else
    {
        $ping = 0
    }

    Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "usp_Alert_UpdateConnectionStatus $($s.InstanceID), $ping, $sqlconnection"
    
    if ($sqlconnection -ne 0)
    {
        $query = "DECLARE @agent NVARCHAR(512);
        SELECT @agent = COALESCE(N'SQLAgent$' + CONVERT(SYSNAME, SERVERPROPERTY('InstanceName')), N'SQLServerAgent');
        EXEC master.dbo.xp_servicecontrol 'QueryState', @agent;"
        $agentstatus = (Invoke-Sqlcmd -ServerInstance $s.ServerName -Query $query).'Current Service State'

        if ($agentstatus -eq "Running.")
        {
            Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "usp_Alert_UpdateAgentStatus $($s.InstanceID), 1"
        }
        else
        {
            Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "usp_Alert_UpdateAgentStatus $($s.InstanceID), 0"
        }
    }
}

workflow wf_CheckConnections ($servers)
{
    foreach -parallel ($s in $servers)
    {
        CheckConnection $s
    }
}

$servers = Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "usp_Alert_GetConnectionStatusServers"
wf_CheckConnections $servers
Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "usp_Alert_UpdateDatabaseStatus"
