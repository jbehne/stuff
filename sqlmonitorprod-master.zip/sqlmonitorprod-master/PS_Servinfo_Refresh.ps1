#
# This script gets information from the SQLMONITOR database about all SQL Server databases
# and propegates that information to SERVINFO on DB2
#
# NOTE: The delete from servinfo is commented out for now - JCC
#
# 1/20/21 JCC  Added DB_STAT column to MDB_DB_DATA
#

#---------------- Common 

$Date = Get-Date -Format "yyyy-MM-dd"
$Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$conn = New-Object System.Data.Odbc.OdbcConnection
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$CCPCall = Invoke-WebRequest -Uri "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=Wapp_SQLServerAuthAccessApp&Safe=SQLDBAutomation_Svc&Username=z_sqlint&Reason=Batch Job&Address=zos-ssh.countrylan.com" -UseBasicParsing 
$CCPPass = ($CCPCall.Content | ConvertFrom-JSON).Content
$conn.ConnectionString = "DSN=SERVINFO;uid=z_SQLINT;pwd=" + $CCPPass
$MonitorServer = "C1DBD069"

#---------------- Server loop

TRY 
{

  $Servers=(Invoke-Sqlcmd -ServerInstance $MonitorServer -Database SQLMONITOR -Query "SELECT ams.ServerName as FQDSServer
        ,amsd.OSVersion + ' ' + ams.Edition as OS
        ,amsd.Domain as Domain_Nm
        ,ams.ProcCores as Processors_Avail
        ,ams.ServerMemory as RAM_MB
        ,convert(varchar,ams.LastStarted,20) as Lst_Reboot_TS
        ,ams.Version as Dbms_Ver
       from vw_allmonitoredservers ams join
       vw_allmonitoredservers_data amsd 
       on (ams.servername = amsd.servername)
       where (ams.isactive = 1 or ams.IsPushActive = 1) order by 1;" -ErrorAction Stop)

  foreach ($Server in $servers)  
  {
    $FQDSServer = $Server.FQDSServer 
    If ($FQDSServer.Length -GT 12)
    {
       $TheServer = $FQDSServer.substring(0,12)
    } 
    else
    {
       $TheServer = $FQDSServer
    }

    $OS = $Server.OS 
    $Domain_Nm = $Server.Domain_Nm
    $Processors_Avail = $Server.Processors_Avail
    $RAM_MB = $Server.RAM_MB
    $Lst_Reboot_TS = $Server.Lst_Reboot_TS
    $DBMS_Ver = $Server.DBMS_Ver

  #---------------- mdb_srvr_data (and mdb_srvr_exclude if inserted)

    $query = "SELECT SRVR_NM as ServerName FROM CCDB2.MDB_SRVR_DATA 
              WHERE SRVR_NM = '$TheServer';"

    $conn.Open()
    $cmd = New-object System.Data.Odbc.OdbcCommand($query,$conn)
    $ds = New-Object System.Data.DataSet 
    $adapter = New-Object System.Data.odbc.OdbcDataAdapter($cmd) 
    $adapter.Fill($ds) | Out-Null
    $everything = $ds.Tables[0]
    $conn.Close()

    $element = @()
    foreach($row in $everything.rows) {$element += $row.ServerName}

    IF ([string]::IsNullOrWhitespace($everything.rows)) {$element = ' '}

    IF ([string]::IsNullOrWhitespace($element))
    {
      $srvrquery = "insert into ccdb2.mdb_srvr_data (
      SRVR_NM, OS, DOMAIN_NM, PROCESSORS_AVAIL, RAM_MB, LST_REBOOT_TS, LST_VERIFIED_TS )
      VALUES 
      ('$TheServer','$OS','$Domain_Nm','$Processors_Avail','$RAM_MB','$Lst_Reboot_TS','$Time');"

      $conn.Open()
      $cmd = New-object System.Data.Odbc.OdbcCommand($srvrquery,$conn)
      $cmd.ExecuteNonQuery()
      $conn.Close()
     
      $srvrquery = "insert into ccdb2.mdb_srvr_exclude VALUES 
      ('$TheServer','SQL','Gathered in SQLMONITOR','Y','Y','Y','Y');"   
    }
    else 
    { 
      $srvrquery = "update ccdb2.mdb_srvr_data set 
      lst_verified_ts = '$Time'
     ,os = '$OS'
     ,domain_nm = '$Domain_Nm'
     ,processors_avail = '$Processors_Avail'
     ,ram_mb = '$RAM_MB'
     ,lst_reboot_ts = '$Lst_Reboot_TS'
      where srvr_nm='$TheServer' ;"
    }
 
    $conn.Open()
    $cmd = New-object System.Data.Odbc.OdbcCommand($srvrquery,$conn)
    $cmd.ExecuteNonQuery()
    $conn.Close() 

  #---------------- mdb_dbms_data
  
    $query = "SELECT SRVR_NM as ServerName FROM CCDB2.MDB_DBMS_DATA 
              WHERE SRVR_NM = '$TheServer' and DBMS_TYP = 'SQL SERVER' ;"

    $conn.Open()
    $cmd = New-object System.Data.Odbc.OdbcCommand($query,$conn)
    $ds = New-Object System.Data.DataSet 
    $adapter = New-Object System.Data.odbc.OdbcDataAdapter($cmd) 
    $adapter.Fill($ds) | Out-Null
    $everything = $ds.Tables[0]
    $conn.Close()

    $element = @()
    foreach($row in $everything.rows) { $element += $row.ServerName }

    IF ([string]::IsNullOrWhitespace($everything.rows)) {$element = ' '}

    IF ([string]::IsNullOrWhitespace($element))
    {
      $dbmsquery = "insert into ccdb2.mdb_dbms_data (
      SRVR_NM, DBMS, DBMS_TYP, DBMS_INSTANCE_NM, DBMS_VER, COUNT_LICENSE, FIL_CLNUP_GRP, LST_VERIFIED_TS, INSTALL_DT)
      VALUES ('$TheServer','SQL','SQL SERVER','SQL','$Dbms_Ver','Y','Z','$Time','$Date');"
    }
    else
    {
      $dbmsquery = "update ccdb2.mdb_dbms_data set 
      lst_verified_ts = '$Time'
     ,dbms = 'SQL'
     ,dbms_typ = 'SQL SERVER'
     ,dbms_ver = '$Dbms_Ver'
     ,dbms_instance_nm = 'SQL'
     ,count_license = 'Y'
     ,fil_clnup_grp = 'Z' 
      where srvr_nm='$TheServer' 
      and dbms_typ='SQL SERVER';"
    }
 
    $conn.Open()
    $cmd = New-object System.Data.Odbc.OdbcCommand($dbmsquery,$conn)
    $cmd.ExecuteNonQuery()
    $conn.Close() 

  #---------------- mdb_db_data 

    $SQLQuery = "Select upper(DatabaseName) as DB_NM from dbo.vw_ALLMonitoredDatabases where ServerName='$FQDSServer' order by DatabaseName;"
    $SQLStuff = Invoke-Sqlcmd -ServerInstance $MonitorServer -Database SQLMONITOR -Query $SQLquery | Select-Object -Expand db_nm -ErrorAction Stop

    IF ([string]::IsNullOrWhitespace($SQLStuff)) 
    {
      $dbquery= "
      delete from ccdb2.mdb_DB_DATA where srvr_nm = '$TheServer' ;
      delete from ccdb2.mdb_cfg_parm where srvr_nm = '$TheServer' ; 
      delete from ccdb2.mdb_obj_exclude where srvr_nm = '$TheServer';
                "
      $conn.Open()
      $cmd = New-object System.Data.Odbc.OdbcCommand($dbquery,$conn)
      $cmd.ExecuteNonQuery()
      $conn.Close()
    } 
     else 
    {
      $query = "SELECT DB_NM FROM CCDB2.MDB_DB_DATA 
                WHERE DBMS = 'SQL' AND SRVR_NM = '$TheServer'
                ORDER BY DB_NM;"

      $conn.Open()
      $cmd = New-object System.Data.Odbc.OdbcCommand($query,$conn)
      $ds = New-Object System.Data.DataSet 
      $adapter = New-Object System.Data.odbc.OdbcDataAdapter($cmd) 
      $adapter.Fill($ds) | Out-Null
      $everything = $ds.Tables[0]
      $conn.Close()
      $element = @()
      foreach($row in $everything.rows)
      {
        $element += $row.DB_NM
      }
   
      $list = Compare-Object $element $SQLStuff -IncludeEqual
      foreach($l in $list)
      {
        $dbquery = ''
        if ($l.SideIndicator -eq '<=') 
        { 
          $dbase = $l.InputObject
          $dbquery= "
          delete from ccdb2.mdb_DB_DATA where srvr_nm = '$TheServer' and DB_NM = '$dbase';
          delete from ccdb2.mdb_cfg_parm where srvr_nm = '$TheServer' and OBJECT = '$dbase'; 
          delete from ccdb2.mdb_obj_exclude where srvr_nm = '$TheServer' and DB_NM = '$dbase';
                   "
        } 
        elseif ($l.SideIndicator -eq '=>')
        { 
          #new code starts here 1/20/21
          if ($TheServer.Substring(0,1) -eq 'V')
            {
             if (
               $TheServer.Substring(9,1) -eq '0' -Or
               $TheServer.Substring(9,1) -eq '1' -Or
               $TheServer.Substring(9,1) -eq '2' -Or
               $TheServer.Substring(9,1) -eq '3'
                )
                 { $DB_STAT = 'PROD' }
             elseif ( 
               $TheServer.Substring(9,1) -eq '5' -Or
               $TheServer.Substring(9,1) -eq '6')
                 { $DB_STAT = 'TEST' }
             elseif ( 
               $TheServer.Substring(9,1) -eq '7') 
                 { $DB_STAT = 'QA' }
             else { $DB_STAT = '????' }
            }
          else {
             if ($TheServer.Substring(5,1) -eq '0' -Or
               $TheServer.Substring(5,1) -eq '1' -Or
               $TheServer.Substring(5,1) -eq '2' -Or
               $TheServer.Substring(5,1) -eq '3'
               )
                 { $DB_STAT = 'PROD' }
          elseif ( 
             $TheServer.Substring(5,1) -eq '5' -Or
             $TheServer.Substring(5,1) -eq '6')
                 { $DB_STAT = 'TEST' }
          elseif ( 
             $TheServer.Substring(5,1) -eq '7') 
                 { $DB_STAT = 'QA' }
          else { $DB_STAT = '????' }
            }
          #new code ends here 1/20/21

          $dbase = $l.InputObject
          if (
               $dbase -eq 'MASTER' -Or
               $dbase -eq 'MODEL' -Or
               $dbase -eq 'MSDB' -Or
               $dbase -eq 'TEMPDB' -Or
               $dbase -eq 'SQLADMIN' -Or
               $dbase -eq 'REPORTSERVER' -Or
               $dbase -eq 'REPORTSERVERTEMPDB' 
             ) 
          {
            $dbquery= 
            "insert into ccdb2.mdb_db_data (SRVR_NM, DB_NM, DBMS, DBMS_INSTANCE_NM, DB_STAT, APP_NM, BACKUP_GRP, DB_COMMENTS, CATALOG_GRP, RUNSTAT_GRP, LST_VERIFIED_TS) 
             VALUES ('$TheServer','$dbase','SQL','SQL', '$DB_STAT', 'SQL SERVER','Z','ZZZ 01/01/2020 No longer using backup groups','Z','Z','$Time');"
          }
          else
          {
            $dbquery= 
            "insert into ccdb2.mdb_db_data (SRVR_NM, DB_NM, DBMS, DBMS_INSTANCE_NM, DB_STAT, APP_NM, BACKUP_GRP, DB_COMMENTS, CATALOG_GRP, RUNSTAT_GRP, LST_VERIFIED_TS) 
            VALUES ('$TheServer','$dbase','SQL','SQL', '$DB_STAT', 'UNKNOWN','Z','ZZZ 01/01/2020 No longer using backup groups','Z','Z','$Time');"
          }        
        }  
        elseif ($l.SideIndicator -eq '==') 
        {   
           $dbase = $l.InputObject
           $dbquery= "update ccdb2.mdb_db_data set LST_VERIFIED_TS = '$Time'
           where srvr_nm = '$TheServer' and db_nm= '$dbase' ; "
        }

        $conn.Open()
        $cmd = New-object System.Data.Odbc.OdbcCommand($dbquery,$conn)
        $cmd.ExecuteNonQuery()
        $conn.Close()
	  }	   
    }
  }          

  #---------------- delete servers in servinfo that aren't in SQLMONITOR

  <# --- the scary delete from servinfo code is commented out
  
  $query = "SELECT SRVR_NM as ServerName FROM CCDB2.MDB_DBMS_DATA 
            WHERE DBMS_TYP = 'SQL SERVER' and LST_VERIFIED_TS < '$Time' ;"

  $conn.Open()
  $cmd = New-object System.Data.Odbc.OdbcCommand($query,$conn)
  $ds = New-Object System.Data.DataSet 
  $adapter = New-Object System.Data.odbc.OdbcDataAdapter($cmd) 
  $adapter.Fill($ds) | Out-Null
  $everything = $ds.Tables[0]
  $conn.Close()

  $element = @()
  foreach($row in $everything.rows) {$element += $row.ServerName}

  IF ([string]::IsNullOrWhitespace($everything.rows)) 
    {
      #-- do nothing no servers to delete
    }
    else
    {
      foreach ($DeleteServer in $element)
       { 
          $DelQuery = "
          DELETE from ccdb2.mdb_reorgchk_index where srvr_nm = '$DeleteServer';
          DELETE from ccdb2.mdb_reorgchk_table where srvr_nm = '$DeleteServer';
          DELETE from CCDB2.MDB_OBJ_EXCLUDE where srvr_nm = '$DeleteServer';
          DELETE FROM CCDB2.MDB_DBMS_DATA WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CFG_PARM WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_ODBC_PARM WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_DCS_CATALOG_INFO WHERE SRVR_NM = '$DeleteServer' ;
          DELETE FROM CCDB2.MDB_NODE_CATALOG_INFO WHERE SRVR_NM = '$DeleteServer' ;
          DELETE FROM CCDB2.MDB_DB_CATALOG_INFO WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_DB_DATA WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_SRVR_SECURITY WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_SRVR_SOFTWARE WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_SRVR_DRIVE WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_SRVR_DATA WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_USERNAME WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_TS_DATA WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CONTAINER_DATA WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_SRVR_EXCLUDE WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_BUFFERPOOLS WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_DBAUTH WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_INDEXCOLUSE WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_INDEXES WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_SERVERS WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_TABAUTH WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_TABLES WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_TABLESPACES WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_TABOPTIONS WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_SERVERS WHERE SRVR_NM = '$DeleteServer';
          DELETE FROM CCDB2.MDB_CAT_STMG_DBSIZE_INFO WHERE SRVR_NM = '$DeleteServer';
                      "
          $conn.Open()
          $cmd = New-object System.Data.Odbc.OdbcCommand($DelQuery,$conn)
          $cmd.ExecuteNonQuery()
          $conn.Close()
       }
    }
  #>  
}

CATCH {
        $Error | out-host
        THROW $_
      }
