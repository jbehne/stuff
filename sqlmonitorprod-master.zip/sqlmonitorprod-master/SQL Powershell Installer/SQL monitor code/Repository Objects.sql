--REPOSITORY TABLES/OBJECTS CREATION
--CREATE DATABASE [SQLMONITOR];
--GO


USE [SQLMONITOR]
GO

CREATE TABLE Perf_MonitoredServers_History (
	ChangeDT smalldatetime, 
	InstanceID int, 
	Property varchar(128), 
	OldValue varchar(128), 
	NewValue varchar(128));
GO
CREATE CLUSTERED INDEX CIX_Perf_MonitoredServers_History ON Perf_MonitoredServers_History (ChangeDT) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_FileIO](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [datetime] NULL,
	[DatabaseName] [varchar](512),
	[FileName] [varchar](512),
	[ReadLatency] [float],
	[WriteLatency] [float],
	[Latency] [float],
	[AvgBytesPerRead] [bigint],
	[AvgBytesPerWrite] [bigint],
	[AvgBytesPerTransfer] [bigint]
);
GO

CREATE CLUSTERED INDEX [CIX_Perf_FileIO] ON [dbo].[Perf_FileIO] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO
CREATE INDEX [IX_Perf_FileIO] ON [dbo].[Perf_FileIO] (InstanceID) WITH (DATA_COMPRESSION = PAGE);
GO
/*
CREATE TABLE [dbo].[Perf_MemoryClerks](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [datetime] NULL,
	[Type] [nvarchar](512) NULL,
	[Name] [nvarchar](512) NULL,
	[MemoryNodeID] [int] NULL,
	[PagesKB] [bigint] NULL,
	[VirtualMemoryReservedKb] [bigint] NULL,
	[VirtualMemoryCommittedKb] [bigint] NULL,
	[AweAllocatedKb] [bigint] NULL,
	[SharedMemoryReservedKb] [bigint] NULL,
	[SharedMemoryCommittedKb] [bigint] NULL);
GO	 

CREATE CLUSTERED INDEX [CIX_Perf_MemoryClerks] ON [dbo].[Perf_MemoryClerks] (CollectionTime) WITH (DATA_COMPRESSION=PAGE);
GO
CREATE INDEX [IX_Perf_MemoryClerks] ON [dbo].[Perf_MemoryClerks] (InstanceID) WITH (DATA_COMPRESSION=PAGE);
GO
*/
CREATE TABLE [dbo].[Perf_MemoryGrants](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [datetime] NULL,
	[SessionID] [int] NULL,
	[DOP] [int] NULL,
	[RequestTime] [datetime] NULL,
	[GrantTime] [datetime] NULL,
	[RequestedMemoryKB] [bigint] NULL,
	[RequiredMemoryKB] [bigint] NULL,
	[UsedMemoryKB] [bigint] NULL,
	[MaxUsedMemoryKB] [bigint] NULL,
	[QueryCost] [float] NULL,
	[TimeoutSec] [bigint] NULL,
	[WaitTimeMS] [float] NULL,
	[IdealMemoryKB] [bigint] NULL)
GO

CREATE CLUSTERED INDEX [CIX_Perf_MemoryGrants] ON [dbo].[Perf_MemoryGrants] (CollectionTime) WITH (DATA_COMPRESSION=PAGE);
GO
CREATE INDEX [IX_Perf_MemoryGrants] ON [dbo].[Perf_MemoryGrants] (InstanceID) WITH (DATA_COMPRESSION=PAGE);
GO


CREATE TABLE Perf_Counters (CounterID int IDENTITY, Class varchar(512), Counter varchar(512));
GO
ALTER TABLE Perf_Counters ADD CONSTRAINT PK_Perf_Counters PRIMARY KEY (CounterID) WITH (DATA_COMPRESSION=PAGE);
GO

INSERT Perf_Counters VALUES ('Access Methods', 'Full Scans/sec'),
	('Access Methods', 'Index Searches/sec'), ('Access Methods', 'Page compression attempts/sec'),
	('Access Methods', 'Page Splits/sec'), ('Access Methods', 'Pages compressed/sec'),
	('Access Methods', 'Table Lock Escalations/sec'), ('Access Methods', 'Workfiles Created/sec'),
	('Access Methods', 'Worktables Created/sec'), ('Buffer Manager', 'Database pages'),
	('Buffer Manager', 'Free list stalls/sec'), ('Buffer Manager', 'Lazy writes/sec'),
	('Buffer Manager', 'Page life expectancy'), ('Buffer Manager', 'Page reads/sec'),
	('Buffer Manager', 'Page writes/sec'), ('Buffer Manager', 'Target pages'),
	('Cursor Manager by Type', 'Active cursors'), ('Cursor Manager by Type', 'Cached Cursor Counts'),
	('Cursor Manager by Type', 'Cursor memory usage'), ('Databases', 'Active Transactions'),
	('Databases', 'Backup/Restore Throughput/sec'), ('Databases', 'DBCC Logical Scan Bytes/sec'),
	('Databases', 'Log Flush Waits/sec'), ('Databases', 'Log Growths'),
	('Databases', 'Log Shrinks'), ('Databases', 'Log Truncations'),
	('Databases', 'Transactions/sec'), ('General Statistics', 'Active Temp Tables'),
	('General Statistics', 'Connection Reset/sec'), ('General Statistics', 'Logins/sec'),
	('General Statistics', 'Logouts/sec'), ('General Statistics', 'Processes blocked'),
	('General Statistics', 'User Connections'), ('Latches', 'Average Latch Wait Time (ms)'),
	('Latches', 'Latch Waits/sec'), ('Latches', 'Total Latch Wait Time (ms)'),
	('Locks', 'Average Wait Time (ms)'), ('Locks', 'Lock Requests/sec'),
	('Locks', 'Lock Timeouts (timeout > 0)/sec'), ('Locks', 'Lock Timeouts/sec'),
	('Locks', 'Lock Wait Time (ms)'), ('Locks', 'Lock Waits/sec'),
	('Locks', 'Number of Deadlocks/sec'), ('Memory Manager', 'Connection Memory (KB)'),
	('Memory Manager', 'Database Cache Memory (KB)'), ('Memory Manager', 'External benefit of memory'),
	('Memory Manager', 'Free Memory (KB)'), ('Memory Manager', 'Granted Workspace Memory (KB)'),
	('Memory Manager', 'Lock Blocks'), ('Memory Manager', 'Lock Blocks Allocated'),
	('Memory Manager', 'Lock Memory (KB)'), ('Memory Manager', 'Lock Owner Blocks'),
	('Memory Manager', 'Lock Owner Blocks Allocated'), ('Memory Manager', 'Log Pool Memory (KB)'),
	('Memory Manager', 'Maximum Workspace Memory (KB)'), ('Memory Manager', 'Memory Grants Outstanding'),
	('Memory Manager', 'Memory Grants Pending'), ('Memory Manager', 'Optimizer Memory (KB)'),
	('Memory Manager', 'Reserved Server Memory (KB)'), ('Memory Manager', 'SQL Cache Memory (KB)'),
	('Memory Manager', 'Stolen Server Memory (KB)'), ('Memory Manager', 'Target Server Memory (KB)'),
	('Memory Manager', 'Total Server Memory (KB)'), ('Plan Cache', 'Cache Hit Ratio'),
	('Plan Cache', 'Cache Object Counts'), ('Plan Cache', 'Cache Objects in use'),
	('Plan Cache', 'Cache Pages'), ('SQL Errors', 'Errors/sec'),
	('SQL Statistics', 'Batch Requests/sec'), ('SQL Statistics', 'SQL Compilations/sec'),
	('SQL Statistics', 'SQL Re-Compilations/sec'), ('Wait Statistics', 'Lock waits'),
	('Wait Statistics', 'Log buffer waits'), ('Wait Statistics', 'Log write waits'),
	('Wait Statistics', 'Memory grant queue waits'), ('Wait Statistics', 'Network IO waits'),
	('Wait Statistics', 'Non-Page latch waits'), ('Wait Statistics', 'Page IO latch waits'),
	('Wait Statistics', 'Page latch waits'), ('Wait Statistics', 'Thread-safe memory objects waits'),
	('Wait Statistics', 'Transaction ownership waits'), ('Wait Statistics', 'Wait for the worker'),
	('Wait Statistics', 'Workspace synchronization waits'),
	('Processor', '% Processor Time'),	('LogicalDisk', 'Disk Reads/sec'),	('LogicalDisk', 'Disk Writes/sec'),
	('LogicalDisk', 'Avg. Disk sec/Read'),	('LogicalDisk', 'Avg. Disk sec/Write'),	('LogicalDisk', '% Free Space'),
	('LogicalDisk', 'Free Megabytes'),	('Memory', 'Pages/sec'),	('Memory', 'Available MBytes'),
	('Memory', 'Pages Input/sec'),	('Paging File', '% Usage'),	('Paging File', '% Usage Peak'),
	('Process', '% Processor Time')
GO

CREATE TABLE Perf_CounterData (
	InstanceID int, 
	CollectionTime smalldatetime, 
	CounterID int, 
	Instance varchar(512), 
	Value float);
GO
CREATE CLUSTERED INDEX CIX_Perf_CounterData ON Perf_CounterData (CollectionTime) WITH (DATA_COMPRESSION=PAGE);
GO
CREATE INDEX [IX_Perf_CounterData] ON [dbo].[Perf_CounterData] (InstanceID) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_CounterData_Stage](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [smalldatetime] NULL,
	[Class] [varchar](512) NULL,
	[Counter] [varchar](512) NULL,
	[Instance] [varchar](512) NULL,
	[Value] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_CounterData_Stage] ON [dbo].[Perf_CounterData_Stage] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_FileSpace](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [smalldatetime] NULL,
	[InstanceName] [varchar](512) NULL,
	[DBName] [varchar](512) NULL,
	[FileName] [varchar](512) NULL,
	[FileGroup] [varchar](512) NULL,
	[Type] [varchar](128) NULL,
	[Size] [int] NULL,
	[Used] [int] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_FileSpace] ON [dbo].[Perf_FileSpace] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO
CREATE INDEX [IX_Perf_FileSpace] ON [dbo].[Perf_FileSpace] (InstanceID) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics](
	[InstanceID] [int] NOT NULL,
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);
GO

CREATE TABLE [dbo].[Perf_IndexUsageStatistics_Stage](
	[InstanceID] [int] NOT NULL,
	[LastStartUp] [datetime] NULL,
	[DatabaseName] [nvarchar](512) NULL,
	[TableName] [nvarchar](512) NULL,
	[IndexName] [nvarchar](512) NULL,
	[IndexType] [nvarchar](128) NULL,
	[UserSeeks] [bigint] NULL,
	[SystemSeeks] [bigint] NULL,
	[UserScans] [bigint] NULL,
	[SystemScans] [bigint] NULL,
	[UserLookups] [bigint] NULL,
	[SystemLookups] [bigint] NULL,
	[UserUpdates] [bigint] NULL,
	[SystemUpdates] [bigint] NULL);
GO

CREATE CLUSTERED INDEX  [CIX_Perf_IndexUsageStatistics] ON [dbo].[Perf_IndexUsageStatistics] (InstanceID, LastStartUp) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_Sessions](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [smalldatetime] NULL,
	[LoginTime] [datetime] NULL,
	[SPID] [int] NULL,
	[Status] [varchar](24) NULL,
	[DBName] [varchar](128) NULL,
	[HostName] [varchar](128) NULL,
	[ApplicationName] [varchar](128) NULL,
	[LoginName] [varchar](128) NULL,
	[CPUTime] [bigint] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[Lastread] [smalldatetime] NULL,
	[LastWrite] [smalldatetime] NULL,
	[SQLText] [varchar](1024) NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_Sessions] ON [dbo].[Perf_Sessions] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO
CREATE INDEX [IX_Perf_Sessions] ON [dbo].[Perf_Sessions] (InstanceID) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE [dbo].[Perf_WaitStatistics](
	[InstanceID] [int] NOT NULL,
	[CollectionTime] [datetime] NULL,
	[WaitType] [varchar](256) NULL,
	[Wait_S] [float] NULL,
	[Resource_S] [float] NULL,
	[Signal_S] [float] NULL,
	[WaitCount] [bigint] NULL,
	[Percentage] [float] NULL,
	[AvgWait_S] [float] NULL,
	[AvgRes_S] [float] NULL,
	[AvgSig_S] [float] NULL);
GO

CREATE CLUSTERED INDEX [CIX_Perf_WaitStatistics] ON [dbo].[Perf_WaitStatistics] (CollectionTime) WITH (DATA_COMPRESSION = PAGE);
GO
CREATE INDEX [IX_Perf_WaitStatistics] ON [dbo].[Perf_WaitStatistics] (InstanceID) WITH (DATA_COMPRESSION = PAGE);
GO

CREATE TABLE Perf_MonitoredServers (
	InstanceID int IDENTITY, 
	ServerName varchar(128), 
	Version varchar(24), 
	ProcCores smallint, 
	ServerMemory int, 
	MaxMemory int,
	PollingInterval_Minutes smallint, 
	PurgeInterval_Days smallint, 
	IsActive bit,
	LastUpdate smalldatetime);
GO

ALTER TABLE Perf_MonitoredServers ADD CONSTRAINT PK_PerfMonitoredServers PRIMARY KEY (InstanceID) WITH (DATA_COMPRESSION=PAGE);
GO
ALTER TABLE Perf_MonitoredServers ADD CONSTRAINT UK_PerfMonitoredServers UNIQUE (ServerName) WITH (DATA_COMPRESSION=PAGE);
GO

CREATE TABLE Perf_ErrorLog (ErrorDate datetime, InstanceID int, ErrorMessage varchar(MAX));
GO
CREATE CLUSTERED INDEX CIX_Perf_ErrorLog ON Perf_ErrorLog (ErrorDate) WITH (DATA_COMPRESSION=PAGE);
GO


CREATE PROC usp_PurgeData 
AS
BEGIN
	DECLARE @dt datetime
	SELECT @dt = DATEADD(mm, -15, GETDATE())

	WHILE (SELECT COUNT(*) FROM Perf_MemoryGrants WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_MemoryGrants WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_MemoryClerks WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_MemoryClerks WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_FileIO WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_FileIO WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_CounterData WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_CounterData WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_FileSpace WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_FileSpace WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_IndexUsageStatistics WHERE LastStartUp < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_IndexUsageStatistics WHERE LastStartUp < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_Sessions WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_Sessions WHERE CollectionTime < @dt;
	END;

	WHILE (SELECT COUNT(*) FROM Perf_WaitStatistics WHERE CollectionTime < @dt) > 1
	BEGIN
		DELETE TOP (10000) FROM Perf_WaitStatistics WHERE CollectionTime < @dt;
	END;
END;
GO

CREATE PROC [dbo].[usp_UpdateServer] (@instanceid int, @column varchar(128), @value varchar(128))
AS
BEGIN
	DECLARE @originalvalue varchar(128);
	DECLARE @sql nvarchar(max) = 'SELECT @val = COALESCE(' + @column + ', '''') FROM Perf_MonitoredServers WHERE InstanceID = ' + CAST(@instanceid as varchar);
	
	EXEC sp_executesql @sql, N'@val varchar(128) OUTPUT', @val = @originalvalue OUTPUT;

	IF @originalvalue <> @value
	BEGIN
		SET @sql = 'UPDATE Perf_MonitoredServers SET ' + @column + ' = ''' + @value + ''' WHERE InstanceID = ' + CAST(@instanceid as varchar);
		EXEC sp_executesql @sql;

		SET @sql = 'INSERT Perf_MonitoredServers_History SELECT GETDATE(), ' + CAST(@instanceid as varchar) + ', ''' + @column + ''', ''' + @originalvalue + ''', ''' + @value + '''';
		EXEC sp_executesql @sql;
	END;
END;
GO

USE [msdb]
GO


/****** Object:  Job [Perf_Collect_All]    Script Date: 7/26/2018 1:33:25 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 7/26/2018 1:33:26 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Perf_Collect_All', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'CCsaid', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PS Collect]    Script Date: 7/26/2018 1:33:26 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PS Collect', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe "E:\Powershell\LoadSQLMonitor.ps1"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [TSQL - Merge Counter Data]    Script Date: 7/26/2018 1:33:26 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'TSQL - Merge Counter Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT Perf_CounterData
SELECT InstanceID, CollectionTime, CounterID, Instance, Value
FROM Perf_CounterData_Stage cd
INNER JOIN Perf_Counters c ON c.Class = RTRIM(cd.Class) AND c.Counter = RTRIM(cd.Counter);
GO

TRUNCATE TABLE Perf_CounterData_Stage;', 
		@database_name=N'SQLMONITOR', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'10 minutes', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=10, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20180627, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'e3dc9c60-becb-424b-9dbf-ca002c85fdeb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


