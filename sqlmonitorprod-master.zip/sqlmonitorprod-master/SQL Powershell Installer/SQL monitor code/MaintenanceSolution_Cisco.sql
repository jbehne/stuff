﻿/*
	Backup Jobs and Code

*/

USE master;
GO

-- Cleanup old objects
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'MaintenanceWindow')
	DROP TABLE MaintenanceWindow;
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Backup_Options')
	DROP TABLE Backup_Options;
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Backup_DefaultLocation')
	DROP TABLE Backup_DefaultLocation;
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_AddNewDatabasesToBackup')
	DROP PROC usp_AddNewDatabasesToBackup;
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_BackupDatabases')
	DROP PROC usp_BackupDatabases;

-- Start and end time of maintenance window
CREATE TABLE MaintenanceWindow (StartTime smalldatetime, EndTime smalldatetime);
GO

-- Backup default location for new databases
CREATE TABLE Backup_DefaultLocation (BackupLocation varchar(2048));
GO

-- Auto set the default location to Aurora
DECLARE @Domain varchar(100), @key varchar(100), @Path varchar(512);
SET @key = 'SYSTEM\ControlSet001\Services\Tcpip\Parameters\';
EXEC master..xp_regread @rootkey='HKEY_LOCAL_MACHINE', @key=@key,@value_name='Domain',@value=@Domain OUTPUT;
INSERT Backup_DefaultLocation
SELECT '\\s01ddaesd001d.corp.alliance.lan\' + 
	CASE @Domain 
		WHEN 'corp.alliance.lan' THEN '01_sqlprodcifs' 
		WHEN 'alliancedev.lan' THEN '01_sqltestcifs'  
		WHEN 'allianceqa.lan' THEN '01_sqlqacifs' 
		ELSE '01_sqltestcifs' END 
		+ '\' + @@SERVERNAME;

-- Backup options
CREATE TABLE Backup_Options (DatabaseName varchar(1024), BackupLocation varchar(2048), FullBackupFiles smallint, 
	DiffBackupFiles smallint, LogBackupFiles smallint, Compressed char(1));
GO

-- This proc is run to make sure all databases have options set
CREATE PROC [dbo].[usp_AddNewDatabasesToBackup] 
AS 
	-- VERSION 1.8
	SET NOCOUNT ON;

	-- Create variables and table variables
	DECLARE @Path varchar(2048), @version float, @subdir varchar(512), @cmd varchar(max);;
	DECLARE @DefaultDirectories TABLE (directory varchar(2048));
	DECLARE @AAGDirectories TABLE (directory varchar(2048));
	
	-- Set the path to the default location
	SELECT @Path = BackupLocation FROM Backup_DefaultLocation;

	-- Load the existing subdirectories for the default location
	INSERT INTO @DefaultDirectories
	EXEC master.dbo.xp_subdirs @Path;

	-- Get SQL vrsn for AAG check
	SET @version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10))

	-- Remove options for databases that no longer exist
	DELETE Backup_Options 
	WHERE DatabaseName NOT IN (SELECT name FROM sys.databases);

	-- Add new databases that do no exist
	INSERT Backup_Options (DatabaseName)
	SELECT name FROM sys.databases WHERE name <> 'tempdb' AND state = 0
	EXCEPT 
	SELECT DatabaseName FROM Backup_Options;

	-- Set default options
	UPDATE Backup_Options SET BackupLocation = @Path, FullBackupFiles = 1, DiffBackupFiles = 1, 
		LogBackupFiles = 1, Compressed = 'N' WHERE BackupLocation IS NULL;

	-- Create a cursor to loop through standalone databases that do not have a subdirectory
	DECLARE c_dirs CURSOR FOR
		SELECT DatabaseName FROM Backup_Options WHERE BackupLocation = @Path
		EXCEPT
		SELECT directory FROM @DefaultDirectories;

	OPEN c_dirs;

	FETCH NEXT FROM c_dirs INTO @subdir;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @cmd = 'EXEC master.sys.xp_create_subdir ''' + @Path + '\' + @subdir + '''';
		EXEC (@cmd);
		
		FETCH NEXT FROM c_dirs INTO @subdir;
	END;

	CLOSE c_dirs;
	DEALLOCATE c_dirs;

	-- If 2012+, set AAG database path to Listener name where database is clustered
	IF @version >= 11
	BEGIN
		IF EXISTS (SELECT dns_name FROM sys.availability_group_listeners)
		BEGIN
			SELECT @Path = REPLACE(@Path, @@SERVERNAME, dns_name) FROM sys.availability_group_listeners;
		
			UPDATE Backup_Options SET BackupLocation = @Path
			WHERE DatabaseName IN (SELECT database_name FROM sys.availability_databases_cluster);

			-- Load the existing subdirectories for the AAG listener location
			INSERT INTO @AAGDirectories
			EXEC master.dbo.xp_subdirs @Path;

			-- Cursor loop through database directories that do not exist
			DECLARE c_dirs CURSOR FOR
				SELECT DatabaseName FROM Backup_Options WHERE BackupLocation = @Path
				EXCEPT
				SELECT directory FROM @AAGDirectories;

			OPEN c_dirs;

			FETCH NEXT FROM c_dirs INTO @subdir;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @cmd = 'EXEC master.sys.xp_create_subdir ''' + @Path + '\' + @subdir + '''';
				EXEC (@cmd);
		
				FETCH NEXT FROM c_dirs INTO @subdir;
			END;

			CLOSE c_dirs;
			DEALLOCATE c_dirs;
		END
	END
GO

-- This proc executes the backup type specified using the options table
CREATE PROC [dbo].[usp_BackupDatabases] (@type varchar(12) = 'FULL')
AS
	-- VERSION 1.6
	DECLARE @db varchar(1024), @compress char(1) = 'N', @fullfiles smallint = 1, @dt nvarchar(24),
		@difffiles smallint = 1, @logfiles smallint = 1, @path varchar(2048), @cmd nvarchar(max),
		@version float, @primary tinyint = null, @errorcount smallint = 0, @runtype varchar(12);
	
	-- Create the timestamp for the filename
	SELECT @dt = '_' + CAST(DATEPART(YEAR, GETDATE()) AS nvarchar) + 
		RIGHT('00' + CONVERT(NVARCHAR(2), DATEPART(MONTH, GETDATE())), 2) +
		RIGHT('00' + CONVERT(NVARCHAR(2), DATEPART(DAY, GETDATE())), 2) + '_' +
		RIGHT('00' + CONVERT(NVARCHAR(2), DATEPART(HOUR, GETDATE())), 2) +
		RIGHT('00' + CONVERT(NVARCHAR(2), DATEPART(MINUTE, GETDATE())), 2) +
		RIGHT('00' + CONVERT(NVARCHAR(2), DATEPART(SECOND, GETDATE())), 2) + '_';

	-- If this is 2012+ check to see if this is an AAG
	-- If not an AAG, @primary is null, if yes @primary is 1 for primary and 0 for replica
	SET @version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10));
	IF @version >= 11
	BEGIN
		SELECT @primary = CASE WHEN @@servername = primary_replica THEN 1 ELSE 0 END
		FROM sys.dm_hadr_availability_group_states
	END;

	-- If this is a FULL or DIFF we want all databases backed up, if LOG we only want full recovery databases
	IF (@type = 'FULL')
		DECLARE c_backup CURSOR FOR
			SELECT DatabaseName, BackupLocation, FullBackupFiles, DiffBackupFiles, LogBackupFiles, Compressed 
			FROM Backup_Options
			WHERE BackupLocation <> '' AND BackupLocation IS NOT NULL;
	ELSE IF (@type = 'DIFF')
		DECLARE c_backup CURSOR FOR
			SELECT DatabaseName, BackupLocation, FullBackupFiles, DiffBackupFiles, LogBackupFiles, Compressed 
			FROM Backup_Options
			WHERE DatabaseName NOT IN ('model', 'ReportServerTempDB')
			AND BackupLocation <> '' AND BackupLocation IS NOT NULL;
	ELSE
		DECLARE c_backup CURSOR FOR
			SELECT DatabaseName, BackupLocation, FullBackupFiles, DiffBackupFiles, LogBackupFiles, Compressed 
			FROM Backup_Options bo
			INNER JOIN sys.databases d ON d.name = bo.DatabaseName
			WHERE recovery_model = 1
			AND DatabaseName NOT IN ('master', 'model', 'msdb', 'ReportServerTempDB')
			AND BackupLocation <> '' AND BackupLocation IS NOT NULL;
	
	-- Open the cursor and run each backup sequentially using the options
	OPEN c_backup;
	FETCH NEXT FROM c_backup INTO @db, @path, @fullfiles, @difffiles, @logfiles, @compress;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Set the type to a local var so that it can be changed ad hoc
		SET @runtype = @type;

		-- If a DIFF is being run this will change the type to a full for master/msdb to ensure daily backups
		IF @type = 'DIFF' AND (@db = 'master' OR @db = 'msdb')
		BEGIN
			SET @runtype = 'FULL';
		END;

		-- If no full backup exists yet change the type to a full
		IF (@type = 'DIFF' OR @type = 'LOG') AND @primary IS NULL
		BEGIN
			IF NOT EXISTS (SELECT TOP 1 physical_device_name   
				FROM msdb.dbo.backupset a 
				INNER JOIN msdb.dbo.backupmediafamily b      
				ON a.media_set_id = b.media_set_id      
				WHERE database_name = @db
				AND type = 'D'
				AND is_copy_only = 0)
			BEGIN
				SET @runtype = 'FULL';
			END;
		END;
				
		-- This IF/ELSE block will process the command for FULL/DIFF/LOG
		IF @runtype = 'FULL'
		BEGIN
			IF @primary = 0
			BEGIN
				IF EXISTS (SELECT database_name FROM sys.availability_databases_cluster WHERE database_name = @db)
				BEGIN
					FETCH NEXT FROM c_backup INTO @db, @path, @fullfiles, @difffiles, @logfiles, @compress;
					continue;
				END;
			END;

			SET @cmd = 'BACKUP DATABASE [' + @db + '] TO ';
			IF @fullfiles > 1
			BEGIN
				WHILE @fullfiles >= 1
				BEGIN
					SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '_' + 
						CAST(@fullfiles AS nvarchar) + '.bak'', ';
					SET @fullfiles = @fullfiles - 1;
				END;

				SET @cmd = LEFT(@cmd, LEN(@cmd) - 2) + '''';
			END;

			ELSE
			BEGIN
				SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '.bak''';
			END;
		END;

		ELSE IF @runtype = 'DIFF'
		BEGIN
			IF @primary = 0
			BEGIN
				IF EXISTS (SELECT database_name FROM sys.availability_databases_cluster WHERE database_name = @db)
				BEGIN
					FETCH NEXT FROM c_backup INTO @db, @path, @fullfiles, @difffiles, @logfiles, @compress;
					continue;
				END;
			END;

			SET @cmd = 'BACKUP DATABASE [' + @db + '] TO ';
			IF @difffiles > 1
			BEGIN
				WHILE @difffiles >= 1
				BEGIN
					SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '_' + 
						CAST(@difffiles AS nvarchar) + '.bak'', ';
					SET @difffiles = @difffiles - 1;
				END;

				SET @cmd = LEFT(@cmd, LEN(@cmd) - 2) + ''' WITH DIFFERENTIAL';
			END;

			ELSE
			BEGIN
				SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '.bak'' WITH DIFFERENTIAL';
			END;
		END;

		ELSE IF @runtype = 'LOG'
		BEGIN
			IF @primary = 1
			BEGIN
				IF EXISTS (SELECT database_name FROM sys.availability_databases_cluster WHERE database_name = @db)
				BEGIN
					FETCH NEXT FROM c_backup INTO @db, @path, @fullfiles, @difffiles, @logfiles, @compress;
					continue;
				END;
			END;

			SET @cmd = 'BACKUP LOG [' + @db + '] TO ';
			IF @logfiles > 1
			BEGIN
				WHILE @logfiles >= 1
				BEGIN
					SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '_' + 
						CAST(@logfiles AS nvarchar) + '.trn'', ';
					SET @logfiles = @logfiles - 1;
				END;

				SET @cmd = LEFT(@cmd, LEN(@cmd) - 2) + '''';
			END;

			ELSE
			BEGIN
				SET @cmd = @cmd + 'DISK = ''' + @path + '\' + @db + '\' + @db + @dt + @runtype + '.trn''';
			END;
		END;

		-- If compression is on and it is a diff, append compression command
		IF @compress = 'Y' AND @runtype = 'DIFF'
		BEGIN
			SET @cmd = @cmd + ', COMPRESSION';
		END;

		-- Otherwise if compression is on, append the full WITH COMPRESSION command
		ELSE IF @compress = 'Y'
		BEGIN
			SET @cmd = @cmd + ' WITH COMPRESSION';
		END;

		-- Output for status
		PRINT 'Backing up ' + @db + ' ';

		-- Execute the backup
		--PRINT @cmd -- Used for Testing
		EXEC (@cmd);

		-- Load the next row
		FETCH NEXT FROM c_backup INTO @db, @path, @fullfiles, @difffiles, @logfiles, @compress;
	END;

	-- Clean up
	CLOSE c_backup;
	DEALLOCATE c_backup;
GO


/* Indexing and Integrity objects */
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_IntegrityCheck')
	DROP PROC usp_IntegrityCheck;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Maintenance_IndexHistory')
	DROP TABLE Maintenance_IndexHistory;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Index_History')
	DROP PROC usp_Index_History;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Index_RebuildHeaps')
	DROP PROC usp_Index_RebuildHeaps;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Index_ManageClusteredIndexes')
	DROP PROC usp_Index_ManageClusteredIndexes;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Index_ManageNonClusteredIndexes')
	DROP PROC usp_Index_ManageNonClusteredIndexes;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Statistics_Update')
	DROP PROC usp_Statistics_Update;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'usp_Index_AllDatabases')
	DROP PROC usp_Index_AllDatabases;
GO
IF EXISTS (SELECT name FROM sys.objects WHERE name = 'Maintenance_Exclude')
	DROP TABLE Maintenance_Exclude;
GO

-- Tracking table for what has been updated
CREATE TABLE dbo.Maintenance_IndexHistory(
	StartTime datetime ,
	EndTime datetime ,
	Command varchar(max)) 
GO

CREATE CLUSTERED INDEX CIX_Maintenance_IndexHistory ON Maintenance_IndexHistory (StartTime);
GO

CREATE TABLE dbo.Maintenance_Exclude(DatabaseName varchar(512),	IndexingOn bit,	IntegrityOn bit);
GO

CREATE PROC [dbo].[usp_Index_ManageClusteredIndexes] (@database varchar(512), @printonly bit = 0)
AS
/*
	This proc rebuilds (>30%) or reorganizes (<30%) the indexes of the given database.
*/
	-- VERSION 1.7
	SET NOCOUNT ON;

	-- Heap of variables needed
	DECLARE @tbl varchar(512), @ix varchar(512), @pt int, @frag decimal(12, 8), 
		@pg int, @online varchar(4), @partition varchar(4), @cmd nvarchar(max), @dbid int,
		@tableid int, @indexid int, @schema varchar(512), @pagelocks bit, @starttime datetime;

	-- Table variable will hold the list of all indexes
	DECLARE @list TABLE (DatabaseName varchar(1024), SchemaName varchar(512), TableName varchar(1024),
		IndexName varchar(1024), PartitionNumber int, Fragmentation float, Pages bigint, OnlineEnabled bit,
		TableID int, IndexID int, TypeDesc varchar(128), AllowPageLocks bit);

	-- Get the id of the passed database
	SELECT @dbid = DB_ID(@database);
	
	-- Build the select statement for the passed in database
	SET @cmd = 'SELECT 
	DB_NAME(ps.database_id) [DatabaseName], sc.name [SchemaName],  o.name [TableName], si.name [IndexName], 
	partition_number [PartitionNumber], ps.avg_fragmentation_in_percent [Fragmentation], page_count [Pages],
	CASE WHEN EXISTS(
		SELECT DISTINCT table_name
		FROM [' + @database + '].INFORMATION_SCHEMA.COLUMNS
		WHERE data_type IN (''text'', ''ntext'', ''image'', ''xml'', ''geography'')
		AND table_name COLLATE SQL_Latin1_General_CP1_CI_AS = o.name COLLATE SQL_Latin1_General_CP1_CI_AS
		OR
		data_type IN (''varchar'', ''nvarchar'', ''varbinary'')
		AND character_maximum_length = -1
		AND table_name COLLATE SQL_Latin1_General_CP1_CI_AS = o.name COLLATE SQL_Latin1_General_CP1_CI_AS) THEN ''0'' 
		ELSE 
			CASE WHEN si.type_desc LIKE ''%COLUMNSTORE%'' THEN ''0'' ELSE ''1'' END END OnlineEnabled,
	si.object_id, si.index_id, index_type_desc, allow_page_locks
	FROM sys.dm_db_index_physical_stats (' + CAST(@dbid as varchar) + ', NULL, NULL, NULL, NULL) ps
	INNER JOIN [' + @database + '].sys.indexes si ON ps.object_id = si.object_id AND ps.index_id = si.index_id
	INNER JOIN [' + @database + '].sys.objects o ON o.object_id = ps.object_id
	INNER JOIN [' + @database + '].sys.schemas sc ON sc.schema_id = o.schema_id
	WHERE ps.database_id = ' + CAST(@dbid as varchar)

	-- Execute the dynamic command and insert to table variable
	INSERT @list EXEC(@cmd);

	-- Create cursor to loop through each index that meets the criteria (CLUSTERED & >5% frag)
	-- The query also determines if the index can be rebuid online or by partition
	DECLARE indexmaintenance CURSOR STATIC FORWARD_ONLY READ_ONLY
	FOR
	SELECT SchemaName, TableName, IndexName, PartitionNumber, Fragmentation, Pages,
	CASE WHEN (SELECT @@VERSION) LIKE '%Enterprise%'
	THEN
		CASE WHEN OnlineEnabled = 0
		THEN 'NO' ELSE 'YES' END
	ELSE 'NO' END AS [OnlineEnabled],
	CASE WHEN (SELECT MAX(PartitionNumber) 
		FROM @list
		WHERE IndexName = t.IndexName) > 1
		THEN 'YES' ELSE 'NO' END AS [Partition],
	TableID, IndexID, AllowPageLocks
	FROM @list t
	WHERE IndexName IS NOT NULL
	AND TypeDesc = 'CLUSTERED INDEX'
	AND Fragmentation >= 5

	-- Open the cursor and fetch the first record into the variables
	OPEN indexmaintenance
	FETCH NEXT FROM indexmaintenance
	INTO @schema, @tbl, @ix, @pt, @frag, @pg, @online, @partition, @tableid, @indexid, @pagelocks
 
	-- Continue while records exist
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		-- If it is under 30% reorg the index
		IF @frag < 30 AND @pagelocks = 1
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REORGANIZE'
		-- If the index is more than 1GB or marked as not supporting online do a rebuild
		ELSE IF @pg > 131072 OR @online = 'NO'
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REBUILD'
		-- If it makes it to this point the index is available to rebuild as an online operation
		ELSE
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REBUILD WITH (ONLINE=ON)'
   
		-- If printonly 1 was passed it will just print the command
		IF @printonly = 1
			PRINT @cmd      
		ELSE
		BEGIN
			-- Write start time to history
			SET @starttime = GETDATE();
	 		INSERT master.dbo.Maintenance_IndexHistory (StartTime, Command)
			SELECT @starttime, @cmd;

			-- Execute the command
			EXEC(@cmd)

			-- Update complete time
			UPDATE master.dbo.Maintenance_IndexHistory
			SET EndTime = GETDATE()
			WHERE StartTime = @starttime
			AND Command = @cmd;
		END

		--Get the next row
		FETCH NEXT FROM indexmaintenance
		INTO @schema, @tbl, @ix, @pt, @frag, @pg, @online, @partition, @tableid, @indexid, @pagelocks
	END
 
	-- Clean up
	CLOSE indexmaintenance
	DEALLOCATE indexmaintenance
GO


CREATE PROC [dbo].[usp_Index_ManageNonClusteredIndexes] (@database varchar(512), @printonly bit = 0)
AS
/*
	This proc rebuilds (>30%) or reorganizes (<30%) the indexes of the given database.
*/
	-- VERSION 1.7
	SET NOCOUNT ON;

	-- Heap of variables needed
	DECLARE @tbl varchar(512), @ix varchar(512), @pt int, @frag decimal(12, 8), 
		@pg int, @online varchar(4), @partition varchar(4), @cmd nvarchar(max), @dbid int,
		@tableid int, @indexid int, @schema varchar(512), @pagelocks bit, @starttime datetime;

	-- Table variable will hold the list of all indexes
	DECLARE @list TABLE (DatabaseName varchar(1024), SchemaName varchar(512), TableName varchar(1024),
		IndexName varchar(1024), PartitionNumber int, Fragmentation float, Pages bigint, OnlineEnabled bit,
		TableID int, IndexID int, TypeDesc varchar(128), AllowPageLocks bit);

	-- Get the id of the passed database
	SELECT @dbid = DB_ID(@database);
	
	-- Build the select statement for the passed in database
	SET @cmd = 'SELECT 
	DB_NAME(ps.database_id) [DatabaseName], sc.name [SchemaName],  o.name [TableName], si.name [IndexName], 
	partition_number [PartitionNumber], ps.avg_fragmentation_in_percent [Fragmentation], page_count [Pages],
	CASE WHEN EXISTS(
		SELECT DISTINCT table_name
		FROM [' + @database + '].INFORMATION_SCHEMA.COLUMNS
		WHERE data_type IN (''text'', ''ntext'', ''image'', ''xml'', ''geography'')
		AND table_name COLLATE SQL_Latin1_General_CP1_CI_AS = o.name COLLATE SQL_Latin1_General_CP1_CI_AS
		OR
		data_type IN (''varchar'', ''nvarchar'', ''varbinary'')
		AND character_maximum_length = -1
		AND table_name COLLATE SQL_Latin1_General_CP1_CI_AS = o.name COLLATE SQL_Latin1_General_CP1_CI_AS) THEN ''0'' 
		ELSE 
			CASE WHEN si.type_desc LIKE ''%COLUMNSTORE%'' THEN ''0'' ELSE ''1'' END END OnlineEnabled,
	si.object_id, si.index_id, index_type_desc, allow_page_locks
	FROM sys.dm_db_index_physical_stats (' + CAST(@dbid as varchar) + ', NULL, NULL, NULL, NULL) ps
	INNER JOIN [' + @database + '].sys.indexes si ON ps.object_id = si.object_id AND ps.index_id = si.index_id
	INNER JOIN [' + @database + '].sys.objects o ON o.object_id = ps.object_id
	INNER JOIN [' + @database + '].sys.schemas sc ON sc.schema_id = o.schema_id
	WHERE ps.database_id = ' + CAST(@dbid as varchar)

	-- Execute the dynamic command and insert to table variable
	INSERT @list EXEC(@cmd);

	-- Create cursor to loop through each index that meets the criteria (CLUSTERED & >5% frag)
	-- The query also determines if the index can be rebuid online or by partition
	DECLARE indexmaintenance CURSOR STATIC FORWARD_ONLY READ_ONLY
	FOR
	SELECT SchemaName, TableName, IndexName, PartitionNumber, Fragmentation, Pages,
	CASE WHEN (SELECT @@VERSION) LIKE '%Enterprise%'
	THEN
		CASE WHEN OnlineEnabled = 0
		THEN 'NO' ELSE 'YES' END
	ELSE 'NO' END AS [OnlineEnabled],
	CASE WHEN (SELECT MAX(PartitionNumber) 
		FROM @list
		WHERE IndexName = t.IndexName) > 1
		THEN 'YES' ELSE 'NO' END AS [Partition],
	TableID, IndexID, AllowPageLocks
	FROM @list t
	WHERE IndexName IS NOT NULL
	AND TypeDesc <> 'CLUSTERED INDEX'
	AND Fragmentation >= 5

	-- Open the cursor and fetch the first record into the variables
	OPEN indexmaintenance
	FETCH NEXT FROM indexmaintenance
	INTO @schema, @tbl, @ix, @pt, @frag, @pg, @online, @partition, @tableid, @indexid, @pagelocks
 
	-- Continue while records exist
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		-- If it is under 30% reorg the index
		IF @frag < 30 AND @pagelocks = 1
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REORGANIZE'
		-- If the index is more than 1GB or marked as not supporting online do a rebuild
		ELSE IF @pg > 131072 OR @online = 'NO'
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REBUILD'
		-- If it makes it to this point the index is available to rebuild as an online operation
		ELSE
			SET @cmd = 'ALTER INDEX [' + @ix + '] ON [' + @database + '].[' + @schema + '].[' + @tbl + '] REBUILD WITH (ONLINE=ON)'
   
		-- If printonly 1 was passed it will just print the command
		IF @printonly = 1
			PRINT @cmd      
		ELSE
		BEGIN
			-- Write start time to history
			SET @starttime = GETDATE();
	 		INSERT master.dbo.Maintenance_IndexHistory (StartTime, Command)
			SELECT @starttime, @cmd;

			-- Execute the command
			EXEC(@cmd)

			-- Update complete time
			UPDATE master.dbo.Maintenance_IndexHistory
			SET EndTime = GETDATE()
			WHERE StartTime = @starttime
			AND Command = @cmd;
		END

		--Get the next row
		FETCH NEXT FROM indexmaintenance
		INTO @schema, @tbl, @ix, @pt, @frag, @pg, @online, @partition, @tableid, @indexid, @pagelocks
	END
 
	-- Clean up
	CLOSE indexmaintenance
	DEALLOCATE indexmaintenance
GO

CREATE PROC [dbo].[usp_Index_RebuildHeaps] (@database varchar(512), @printonly bit = 0)
AS 
/*
	This proc rebuilds all heap tables that are more than 5% fragmented
*/
	-- Version 1.3
	SET NOCOUNT ON;

	-- Table will hold the table name from the cursor, cmd will hold the rebuild command
	DECLARE @table varchar(max), @schema varchar(max), @cmd varchar(max);
	DECLARE @starttime datetime, @dbid int, @histcmd varchar(max);

	-- Get the id of the passed database
	SELECT @dbid = DB_ID(@database);

	-- Create a cursor to loop through all heap names > 5% fragmented 
	SET @cmd = '
	DECLARE RebuildHeaps CURSOR STATIC FORWARD_ONLY READ_ONLY 
	FOR
	SELECT o.name TableName, s.name SchemaName
	FROM [' + @database + '].sys.dm_db_index_physical_stats (' + CAST(@dbid AS varchar) + ', null, null, null, null) ips
	INNER JOIN [' + @database + '].sys.objects o ON o.object_id = ips.object_id
	INNER JOIN [' + @database + '].sys.schemas s ON s.schema_id = o.schema_id
	WHERE index_type_desc = ''HEAP''
	AND avg_fragmentation_in_percent > 5;';

	EXEC (@cmd);

	-- Open and fetch the first record 
	OPEN RebuildHeaps;
	FETCH NEXT FROM RebuildHeaps INTO @table, @schema;
 
	-- While there are records, loop through each one
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Create the rebuild command
		SELECT @cmd = 'ALTER TABLE [' + @database + '].[' + @schema + '].[' + @table + '] REBUILD';        
 
		-- Print/Execute command if 1 was passed in
		IF (@printonly = 1)
		BEGIN
			PRINT @cmd;
		END;
		ELSE
		BEGIN
			-- Write start time to history
			SET @starttime = GETDATE();
	 		INSERT master.dbo.Maintenance_IndexHistory (StartTime, Command)
			SELECT @starttime, @cmd;

			-- Execute the command
			EXEC(@cmd)

			-- Update complete time
			UPDATE master.dbo.Maintenance_IndexHistory
			SET EndTime = GETDATE()
			WHERE StartTime = @starttime
			AND Command = @cmd;
			
			EXEC(@histcmd);
		END;
		-- Fetch the next record
		FETCH NEXT FROM RebuildHeaps INTO @table, @schema;
	END
 
	-- Close and deallocate cursor
	CLOSE RebuildHeaps;
	DEALLOCATE RebuildHeaps;
GO

CREATE PROC [dbo].[usp_Statistics_Update] (@printonly bit = 0)
AS
/*
	Rebuild statistics with fullscan if more than 5% of the records have changed.
	This proc does not take a database as an input, instead it will automatically
	run against all databases by itself.
*/
	-- Version 1.3
	SET NOCOUNT ON;

	-- Table variable for databases
	DECLARE @dblist TABLE (id smallint IDENTITY, name varchar(512));
	-- Table variable for list of stats
	DECLARE @list TABLE (DatabaseName varchar(512), SchemaName varchar(512), TableName varchar(512), TableID int);
	-- Variables for the cursor
	DECLARE @database varchar(512), @schema varchar(512), @table varchar(512), @tableid int, 
		@count smallint, @db varchar(512), @cmd varchar(max), @version int, @starttime datetime;

	-- If this is 2012+ check to see if this is an AAG
	-- If not an AAG, @primary is null, if yes @primary is 1 for primary and 0 for replica
	SET @version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10));
	IF @version >= 11
	BEGIN
		INSERT @dblist
		SELECT name 
		FROM sys.databases 
		WHERE name <> 'tempdb'
		AND is_read_only = 0
		AND compatibility_level > 80
		EXCEPT
		SELECT DatabaseName FROM Maintenance_Exclude WHERE IndexingOn = 0
		EXCEPT
		SELECT database_name FROM sys.availability_databases_cluster;
	END;

	ELSE
	BEGIN
		INSERT @dblist
		SELECT name 
		FROM sys.databases 
		WHERE name <> 'tempdb'
		AND is_read_only = 0
		AND compatibility_level > 80
		EXCEPT
		SELECT DatabaseName FROM Maintenance_Exclude WHERE IndexingOn = 0;
	END;

	SELECT @count = MAX(id) FROM @dblist;

	WHILE @count > 0
	BEGIN
		SELECT @db = name FROM @dblist WHERE id = @count
		PRINT @db
		SET @cmd = 'USE [' + @db + ']; 
			SELECT DISTINCT ''' + @db + ''' DBName, sc.name, o.name, o.object_id
			FROM sys.stats s
			INNER JOIN sys.objects o ON o.object_id = s.object_id
			INNER JOIN sys.schemas sc ON o.schema_id = sc.schema_id
			CROSS APPLY sys.dm_db_stats_properties (s.object_id, stats_id)
			WHERE o.is_ms_shipped = 0
			AND modification_counter / rows > .05'

		INSERT @list
		EXEC (@cmd);

		SET @count = @count - 1
	END;

	-- Create the cursor from the table variable
	DECLARE statsmaintenance CURSOR STATIC FORWARD_ONLY READ_ONLY
	FOR
	SELECT * FROM @list;

	-- Open the cursor and get the first record
	OPEN statsmaintenance
	FETCH NEXT FROM statsmaintenance
	INTO @database, @schema, @table, @tableid;
 
	-- Loop while there are records
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @cmd = 'UPDATE STATISTICS [' + @database + '].[' + @schema + '].[' + @table + '] WITH FULLSCAN'; 

		-- If printonly is specified just print
		IF @printonly = 1
			PRINT @cmd
		ELSE
		BEGIN
			-- Write start time to history
			SET @starttime = GETDATE();
	 		INSERT master.dbo.Maintenance_IndexHistory (StartTime, Command)
			SELECT @starttime, @cmd;

			-- Execute the command
			EXEC(@cmd)

			-- Update complete time
			UPDATE master.dbo.Maintenance_IndexHistory
			SET EndTime = GETDATE()
			WHERE StartTime = @starttime
			AND Command = @cmd;
		END

		-- Get the next record
		FETCH NEXT FROM statsmaintenance
		INTO @database, @schema, @table, @tableid;
	END

	-- Clean up the cursor
	CLOSE statsmaintenance;
	DEALLOCATE statsmaintenance;
  GO


CREATE PROC usp_Index_AllDatabases (@printonly bit = 0)
AS
	-- Version 1.3
	SET NOCOUNT ON;

	-- Create a variable and cursor to loop through each database (not tempdb)
	DECLARE @db varchar(512), @version float, @primary tinyint = null;

	-- If this is 2012+ check to see if this is an AAG
	-- If not an AAG, @primary is null, if yes @primary is 1 for primary and 0 for replica
	SET @version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10));
	IF @version >= 11
	BEGIN
		SELECT @primary = CASE WHEN @@servername = primary_replica THEN 1 ELSE 0 END
		FROM sys.dm_hadr_availability_group_states
	END;

	DECLARE alldb CURSOR STATIC FORWARD_ONLY READ_ONLY
	FOR
	SELECT name FROM sys.databases WHERE name <> 'tempdb' AND is_read_only = 0 
	EXCEPT 
	SELECT DatabaseName FROM Maintenance_Exclude WHERE IndexingOn = 0 ORDER BY name;

	OPEN alldb
	FETCH NEXT FROM alldb INTO @db;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		/*
			Rebuilding a HEAP or a CLUSTERED INDEX automatically forces a rebuild
			of all other indexes on the table.

			The idea here is to rebuild all HEAPS, then all CLUSTERED INDEXES,
			after that do another check to see what indexes are left that meet
			the criteria for maintenance.

			If the database is a secondary it cannot run mainteance and will skip.
		*/
		IF @primary = 0
		BEGIN
			IF EXISTS (SELECT database_name FROM sys.availability_databases_cluster WHERE database_name = @db)
			BEGIN
				FETCH NEXT FROM alldb INTO @db;
				continue;
			END;
		END;

		PRINT @db

		EXEC usp_Index_RebuildHeaps @db, @printonly;
		EXEC usp_Index_ManageClusteredIndexes @db, @printonly;
		EXEC usp_Index_ManageNonClusteredIndexes @db, @printonly;

		FETCH NEXT FROM alldb INTO @db;
	END;

	CLOSE alldb;
	DEALLOCATE alldb;

	-- Finally run the stats proc to update any outdated stats
	EXEC usp_Statistics_Update @printonly ;
GO

CREATE PROC usp_IntegrityCheck
AS
	-- VERSION 1.1
	DECLARE @db varchar(512), @version float, @primary tinyint = null;

	-- If this is 2012+ check to see if this is an AAG
	-- If not an AAG, @primary is null, if yes @primary is 1 for primary and 0 for replica
	SET @version = CAST(LEFT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)),CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - 1) + '.' + REPLACE(RIGHT(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)), LEN(CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max))) - CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(max)))),'.','') AS numeric(18,10));
	IF @version >= 11
	BEGIN
		SELECT @primary = CASE WHEN @@servername = primary_replica THEN 1 ELSE 0 END
		FROM sys.dm_hadr_availability_group_states
	END;

	DECLARE alldb CURSOR STATIC FORWARD_ONLY READ_ONLY
	FOR
	SELECT name FROM sys.databases WHERE name <> 'tempdb' AND is_read_only = 0
	EXCEPT 
	SELECT DatabaseName FROM Maintenance_Exclude WHERE IntegrityOn = 0
	ORDER BY name;

	OPEN alldb
	FETCH NEXT FROM alldb INTO @db;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @primary = 1
		BEGIN
			IF EXISTS (SELECT database_name FROM sys.availability_databases_cluster WHERE database_name = @db)
			BEGIN
				FETCH NEXT FROM alldb INTO @db;
				continue;
			END;
		END;

		DBCC CHECKDB (@db) WITH NO_INFOMSGS;

		FETCH NEXT FROM alldb INTO @db;
	END;

	CLOSE alldb;
	DEALLOCATE alldb;

GO





/* JOBS */

-- Backup Job
USE [msdb]
GO

IF EXISTS (SELECT name FROM sysjobs WHERE name = 'Maintenance - Backup FULL')
	EXEC sp_delete_job @job_name = N'Maintenance - Backup FULL';

EXEC msdb.dbo.sp_add_job @job_name=N'Maintenance - Backup FULL', 
		@description=N'Database Backups', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa';

EXEC msdb.dbo.sp_add_jobserver @job_name=N'Maintenance - Backup FULL', @server_name = N'(local)';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup FULL', @step_name=N'New Databases', 
		@command=N'[dbo].[usp_AddNewDatabasesToBackup]', 
		@database_name=N'master',
		@on_success_action=3;

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup FULL', @step_name=N'Backup', 
		@command=N'usp_BackupDatabases ''FULL''', 
		@database_name=N'master';
GO

IF EXISTS (SELECT name FROM sysjobs WHERE name = 'Maintenance - Backup DIFF')
	EXEC sp_delete_job @job_name = N'Maintenance - Backup DIFF';

EXEC msdb.dbo.sp_add_job @job_name=N'Maintenance - Backup DIFF', 
		@description=N'Database Backups', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa';

EXEC msdb.dbo.sp_add_jobserver @job_name=N'Maintenance - Backup DIFF', @server_name = N'(local)';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup DIFF', @step_name=N'New Databases', 
		@command=N'[dbo].[usp_AddNewDatabasesToBackup]', 
		@database_name=N'master',
		@on_success_action=3;

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup DIFF', @step_name=N'Backup', 
		@command=N'usp_BackupDatabases ''DIFF''', 
		@database_name=N'master';
GO

IF EXISTS (SELECT name FROM sysjobs WHERE name = 'Maintenance - Backup LOG')
	EXEC sp_delete_job @job_name = N'Maintenance - Backup LOG';

EXEC msdb.dbo.sp_add_job @job_name=N'Maintenance - Backup LOG', 
		@description=N'Database Backups', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa';

EXEC msdb.dbo.sp_add_jobserver @job_name=N'Maintenance - Backup LOG', @server_name = N'(local)';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup LOG', @step_name=N'New Databases', 
		@command=N'[dbo].[usp_AddNewDatabasesToBackup]', 
		@database_name=N'master',
		@on_success_action=3;

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Backup LOG', @step_name=N'Backup', 
		@command=N'usp_BackupDatabases ''LOG''', 
		@database_name=N'master';




-- Jobs to run integrity, indexing and cleanup history
IF EXISTS (SELECT name FROM sysjobs WHERE name = 'Maintenance - Integrity')
	EXEC msdb.dbo.sp_delete_job @job_name=N'Maintenance - Integrity';

EXEC msdb.dbo.sp_add_job @job_name=N'Maintenance - Integrity', 
		@owner_login_name=N'sa';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Integrity', @step_name=N'Run Integrity', 
		@step_id=1, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@subsystem=N'TSQL', 
		@command=N'usp_IntegrityCheck', 
		@database_name=N'master';

EXEC msdb.dbo.sp_add_jobserver @job_name=N'Maintenance - Integrity', @server_name = N'(local)';
GO


IF EXISTS (SELECT name FROM sysjobs WHERE name = 'Maintenance - Indexing')
	EXEC msdb.dbo.sp_delete_job @job_name=N'Maintenance - Indexing';

EXEC msdb.dbo.sp_add_job @job_name=N'Maintenance - Indexing', 
		@owner_login_name=N'sa';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Indexing', @step_name=N'Run indexing', 
		@step_id=1, 
		@on_success_action=3, 
		@on_fail_action=2, 
		@subsystem=N'TSQL', 
		@command=N'usp_Index_AllDatabases', 
		@database_name=N'master';

EXEC msdb.dbo.sp_add_jobstep @job_name=N'Maintenance - Indexing', @step_name=N'Cleanup history', 
		@step_id=2, 
		@on_success_action=1, 
		@on_fail_action=2, 
		@subsystem=N'TSQL', 
		@command=N'DELETE Maintenance_IndexHistory WHERE StartTime < GETDATE() - 14', 
		@database_name=N'master';

EXEC msdb.dbo.sp_add_jobserver @job_name=N'Maintenance - Indexing', @server_name = N'(local)';

