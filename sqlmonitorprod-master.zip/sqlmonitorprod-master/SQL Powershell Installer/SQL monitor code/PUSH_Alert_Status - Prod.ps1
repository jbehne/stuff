$id = (Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "SELECT InstanceID FROM Perf_MonitoredServers WHERE ServerName = '$($env:ComputerName)'").InstanceID

if ($id -ne $null)
{
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "usp_Alert_UpdateConnectionStatus $id, 1, 1"
    Invoke-SqlCmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "usp_Alert_UpdateAgentStatus $id, 1"
}

