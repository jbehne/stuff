﻿function f_Collect ($instance) {
    try {
        $repositoryserver = "C1DBD536"
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$repositoryserver;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()
        
        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 120

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Database=SQLADMIN;Integrated Security=true")
        $sqlconn.Open()

		### Update repository server settings
		$query = "DECLARE @tbl TABLE ([Index] VARCHAR(2000), [Name] VARCHAR(2000), [Internal_Value] VARCHAR(2000), [Character_Value] VARCHAR(2000)) ;
				INSERT @tbl
				EXEC xp_msver;

				SELECT Name, Internal_Value
				FROM @tbl WHERE Name IN ('ProcessorCount', 'PhysicalMemory')
				UNION ALL
				SELECT name, value_in_use
				FROM sys.configurations
				WHERE name like 'max server memory%'
                UNION ALL
                SELECT * FROM Perf_Timers
                UNION ALL
				SELECT 'Version', SERVERPROPERTY('ProductVersion')
                UNION ALL
				SELECT 'Edition', SERVERPROPERTY('Edition')
                UNION ALL
				SELECT 'Collation', SERVERPROPERTY('Collation')
                UNION ALL
				SELECT 'LastStarted', sqlserver_start_time FROM sys.dm_os_sys_info;"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

		while ($sqlreader.Read())
		{
			switch ($sqlreader["Name"])
            {
                'Edition' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Edition', '" + $sqlreader["Internal_Value"] + "'" }
                'Collation' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Collation', '" + $sqlreader["Internal_Value"] + "'" }
                'ProcessorCount' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'ProcCores', '" + $sqlreader["Internal_Value"] + "'" }
                'PhysicalMemory' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'ServerMemory', '" + $sqlreader["Internal_Value"] + "'" }
                'max server memory (MB)' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'MaxMemory', '" + $sqlreader["Internal_Value"] + "'" }
                'Collection' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'PollingInterval_Minutes', '" + $sqlreader["Internal_Value"] + "'" }
                'Retention' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'PurgeInterval_Days', '" + $sqlreader["Internal_Value"] + "'" }
                'Version' { $updatequery = "EXEC usp_UpdateServer_Data " + $instance.InstanceID  + ", 'Version', '" + $sqlreader["Internal_Value"] + "'" }
                'LastStarted' { $updatequery = "EXEC usp_UpdateServer " + $instance.InstanceID  + ", 'LastStarted', '" + $sqlreader["Internal_Value"] + "'" }
            }

            Invoke-Sqlcmd -ServerInstance $repositoryserver -Database SQLMONITOR -Query $updatequery
		}

        Invoke-Sqlcmd -ServerInstance $repositoryserver -Database SQLMONITOR -Query "UPDATE Perf_MonitoredServers SET LastUpdated = GETDATE() WHERE InstanceID = $($instance.InstanceID)"

        $sqlreader.Close()

        ### Backup_BackupHistory
        $query = "SELECT $($instance.InstanceID) InstanceID, database_name DatabaseName, bs.name BackupName, user_name UserName, physical_device_name BackupLocation, 
	                backup_start_date BackupStartDate, backup_finish_date BackupEndDate,
	                CASE WHEN is_compressed = 0 THEN backup_size ELSE compressed_backup_size END BackupSize, 
	                is_compressed Compressed, is_copy_only CopyOnly, type BackupType
                FROM msdb..backupset bs
                LEFT OUTER JOIN msdb..backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
                LEFT OUTER JOIN msdb..backupmediaset bms ON bs.media_set_id = bms.media_set_id
                WHERE backup_start_date > GETDATE() - 7"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Backup_BackupHistory_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        ### Perf_CounterData
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, RTRIM(Class) Class, RTRIM(Counter) Counter, RTRIM(Instance) Instance, Value 
            FROM Perf_CounterData WHERE CollectionTime > '$($instance.LastCounters)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_CounterData_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_FileIO
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, DatabaseName, FileName, ReadLatency, WriteLatency, 
            Latency, AvgBytesPerRead, AvgBytesPerWrite, AvgBytesPerTransfer FROM Perf_FileIO WHERE CollectionTime > '$($instance.LastIO)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_FileIO"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_FileSpace
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, InstanceName, DBName, FileName, FileGroup, Type, 
            Size, Used FROM Perf_FileSpace WHERE CollectionTime > '$($instance.LastSpace)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_FileSpace"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        <#
        ### Perf_MemoryClerks
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, Type, Name, MemoryNodeID, PagesKB, 
            VirtualMemoryReservedKb, VirtualMemoryCommittedKb, AweAllocatedKb, SharedMemoryReservedKb, SharedMemoryCommittedKb 
            FROM Perf_MemoryClerks WHERE CollectionTime > '$($instance.LastClerks)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_MemoryClerks"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()
        #>

        ### Perf_MemoryGrants
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, SessionID, DOP, RequestTime, GrantTime, 
            RequestedMemoryKB, RequiredMemoryKB, UsedMemoryKB, MaxUsedMemoryKB, QueryCost, TimeoutSec, WaitTimeMS, IdealMemoryKB 
            FROM Perf_MemoryGrants WHERE CollectionTime > '$($instance.LastGrants)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_MemoryGrants"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_Sessions
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, LoginTime, SPID, Status, DBName, 
            HostName, ApplicationName, LoginName, CPUTime, Reads, Writes, Lastread, LastWrite, SQLText 
            FROM Perf_Sessions WHERE CollectionTime > '$($instance.LastSessions)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_Sessions"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()


        ### Perf_WaitStatistics
        $query = "SELECT $($instance.InstanceID) InstanceID, CollectionTime, WaitType, Wait_S, Resource_S, 
            Signal_S, WaitCount, Percentage, AvgWait_S, AvgRes_S, AvgSig_S 
            FROM Perf_WaitStatistics WHERE CollectionTime > '$($instance.LastWaits)'"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_WaitStatistics"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        <#
        THIS HAS BEEN DISABLED DUE TO ISSUES FOUND AT THE INSTANCE LEVEL

        ### Perf_IndexUsageStatistics
        $query = "SELECT $($instance.InstanceID) InstanceID, LastStartUp, DatabaseName, TableName, IndexName, 
            IndexType, UserSeeks, SystemSeeks, UserScans, SystemScans, UserLookups, SystemLookups, UserUpdates, SystemUpdates 
            FROM Perf_IndexUsageStatistics"
        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Perf_IndexUsageStatistics_Stage"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()
        #>


        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch {
        $err = $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance $repositoryserver -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }
}

### Program Start




#Set repository
$repository = "C1DBD536"

# Set query to get servers
$query = "SELECT 
    ServerName, InstanceID,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_CounterData WHERE InstanceID = pms.InstanceID), '12/15/1941') LastCounters,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_FileSpace WHERE InstanceID = pms.InstanceID), '12/15/1941') LastSpace,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_MemoryGrants WHERE InstanceID = pms.InstanceID), '12/15/1941') LastGrants,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_Sessions WHERE InstanceID = pms.InstanceID), '12/15/1941') LastSessions,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_WaitStatistics WHERE InstanceID = pms.InstanceID), '12/15/1941') LastWaits,
    COALESCE((SELECT MAX(CollectionTime) FROM Perf_FileIO WHERE InstanceID = pms.InstanceID), '12/15/1941') LastIO
    FROM Perf_MonitoredServers pms
    WHERE ServerName = '$($env:ComputerName)'"
    
# Get servers
$instance = @(Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query $query -QueryTimeout 600 -ConnectionTimeout 600)

f_Collect $instance