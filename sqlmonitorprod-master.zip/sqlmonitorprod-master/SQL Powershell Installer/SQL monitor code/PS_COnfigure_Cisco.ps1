﻿$server = "V01AWHWIN040"

Copy-Item '\\C1DBD069.corp.alliance.lan\E$\Powershell\SQL Powershell Installer\SQL monitor code\PS_Perf_CollectCounters.ps1' D:\MSSQL
Invoke-Sqlcmd -ServerInstance $server -Query "EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 16"
Invoke-Sqlcmd -ServerInstance $server -Query "EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=10000, @jobhistory_max_rows_per_job=1000"
Invoke-Sqlcmd -ServerInstance $server -InputFile '\\C1DBD069\E$\Powershell\SQL Powershell Installer\SQL monitor code\MaintenanceSolution_Cisco.sql'
Invoke-Sqlcmd -ServerInstance $server -InputFile '\\C1DBD069\E$\Powershell\SQL Powershell Installer\SQL monitor code\Instance Objects_Cisco.sql'