﻿$Global:repository = "C1DBD069"
 
function GetLogins ($server)
{
    $query = "
        SELECT $($server.InstanceID), name, createdate, updatedate, dbname, denylogin, hasaccess,
	        isntname, isntgroup, isntuser
        FROM sys.syslogins"

    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Integrated Security=true")
    $sqlconn.Open()
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_Logins_Stage"
    $bc.WriteToServer($result) 
}

function GetServerRoles ($server)
{
    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Integrated Security=true")
    $sqlconn.Open()

    $query = "DECLARE @sa TABLE (ServerRole varchar(512), MemberName varchar(512), MemberSID varchar(128));
                INSERT @sa
                EXEC sp_helpsrvrolemember;
            SELECT $($server.InstanceID) InstanceID, ServerRole, MemberName FROM @sa ORDER BY MemberName;"
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_ServerRoles_Stage"
    $bc.WriteToServer($result)  
}

function GetServerPermissions ($server)
{
    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Integrated Security=true")
    $sqlconn.Open()

    $query = "SELECT DISTINCT $($server.InstanceID) InstanceID, Name, class_desc Class, permission_name Permission, state_desc Type
            FROM sys.server_permissions perm
            INNER JOIN sys.server_principals prin ON perm.grantee_principal_id = prin.principal_id
            ORDER BY name;"
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_ServerPermissions_Stage"
    $bc.WriteToServer($result)  
}

function GetDatabaseRoleAccess ($server, $dbname)
{
    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Database=$dbname;Integrated Security=true")
    $sqlconn.Open()

    $query = "SELECT $($server.InstanceID) InstanceID, '$dbname' DatabaseName, s.name Role, sc.name + '.' + so.name Object, type_desc ObjectType,
                CASE action WHEN 26 THEN 'REFERENCES'
                                WHEN 178 THEN 'CREATE FUNCTION'
                                WHEN 193 THEN 'SELECT'
                                WHEN 195 THEN 'INSERT'
                                WHEN 196 THEN 'DELETE'
                                WHEN 197 THEN 'UPDATE'
                                WHEN 198 THEN 'CREATE TABLE'
                                WHEN 203 THEN 'CREATE DATABASE'
                                WHEN 207 THEN 'CREATE VIEW'
                                WHEN 222 THEN 'CREATE PROCEDURE'
                                WHEN 224 THEN 'EXECUTE'
                                WHEN 228 THEN 'BACKUP DATABASE'
                                WHEN 233 THEN 'CREATE DEFAULT'
                                WHEN 235 THEN 'BACKUP LOG'
                                WHEN 236 THEN 'CREATE RULE'
                END AS Action,
                CASE protecttype 
                        WHEN 204 THEN 'GRANT_W_GRANT '
                        WHEN 205 THEN 'GRANT '
                        ELSE 'DENY'
                END AS AccessType
        FROM sys.sysprotects sp 
        INNER JOIN sys.objects so ON so.object_id = sp.id 
        INNER JOIN sys.sysusers s ON sp.uid = s.uid 
        INNER JOIN sys.schemas sc ON sc.schema_id = so.schema_id
        WHERE (issqlrole = 1 OR isapprole = 1) AND is_ms_shipped = 0

        UNION ALL

        SELECT $($server.InstanceID) InstanceID, '$dbname' DatabaseName, name Role, '_DB_GLOBAL' Object, 'GLOBAL' ObjectType, permission_name Action, state_desc AccessType
        FROM sys.database_permissions perm
        INNER JOIN sys.database_principals prin ON prin.principal_id = perm.grantee_principal_id
        WHERE class_desc = 'DATABASE'
        AND type_desc = 'DATABASE_ROLE'
        ORDER BY s.name"
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_DatabaseRolePermissions_Stage"
    $bc.WriteToServer($result)  
}

function GetDatabaseRoleMembers ($server, $dbname)
{
    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Database=$dbname;Integrated Security=true")
    $sqlconn.Open()

    $query = "SELECT $($server.InstanceID) InstanceID, '$dbname' DatabaseName, su.name AS Role, sysusers_1.name AS UserName
                FROM dbo.sysusers su
                INNER JOIN dbo.sysmembers sm ON su.uid = sm.groupuid 
                INNER JOIN dbo.sysusers sysusers_1 ON sm.memberuid = sysusers_1.uid
                WHERE sysusers_1.name <> 'dbo'
                ORDER BY Role, UserName"
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_DatabaseRoleMembers_Stage"
    $bc.WriteToServer($result)  
}

function GetDatabaseExplicitGrants ($server, $dbname)
{
    $result = New-Object System.Data.DataTable
    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Database=$dbname;Integrated Security=true")
    $sqlconn.Open()

    $query = "SELECT $($server.InstanceID) InstanceID, '$dbname' DatabaseName, s.name Role, sc.name + '.' + so.name Object, type_desc ObjectType,
                CASE action WHEN 26 THEN 'REFERENCES'
                                WHEN 178 THEN 'CREATE FUNCTION'
                                WHEN 193 THEN 'SELECT'
                                WHEN 195 THEN 'INSERT'
                                WHEN 196 THEN 'DELETE'
                                WHEN 197 THEN 'UPDATE'
                                WHEN 198 THEN 'CREATE TABLE'
                                WHEN 203 THEN 'CREATE DATABASE'
                                WHEN 207 THEN 'CREATE VIEW'
                                WHEN 222 THEN 'CREATE PROCEDURE'
                                WHEN 224 THEN 'EXECUTE'
                                WHEN 228 THEN 'BACKUP DATABASE'
                                WHEN 233 THEN 'CREATE DEFAULT'
                                WHEN 235 THEN 'BACKUP LOG'
                                WHEN 236 THEN 'CREATE RULE'
                END AS Action,
                CASE protecttype 
                        WHEN 204 THEN 'GRANT_W_GRANT '
                        WHEN 205 THEN 'GRANT '
                        ELSE 'DENY'
                END AS AccessType
        FROM sys.sysprotects sp 
        INNER JOIN sys.objects so ON so.object_id = sp.id 
        INNER JOIN sys.sysusers s ON sp.uid = s.uid 
        INNER JOIN sys.schemas sc ON sc.schema_id = so.schema_id
        WHERE issqlrole = 0 AND isapprole = 0 AND is_ms_shipped = 0

        UNION ALL

        SELECT $($server.InstanceID) InstanceID, '$dbname' DatabaseName, name Role, '_DB_GLOBAL' Object, 'GLOBAL' ObjectType, permission_name Action, state_desc AccessType
        FROM sys.database_permissions perm
        INNER JOIN sys.database_principals prin ON prin.principal_id = perm.grantee_principal_id
        WHERE class_desc = 'DATABASE'
        AND type_desc <> 'DATABASE_ROLE'
        AND permission_name <> 'CONNECT'
        ORDER BY s.name"
    
    $sqlad = New-Object System.Data.SqlClient.SqlDataAdapter($query, $sqlconn)
    $sqlad.Fill($result) | Out-Null
    $sqlconn.Dispose()

    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $bc.DestinationTableName = "Security_DatabaseUserPermissions_Stage"
    $bc.WriteToServer($result)  
}
    


Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseRoleMembers_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseRolePermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseUserPermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_ServerPermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_ServerRoles_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_Logins_Stage"


$server = Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "SELECT InstanceID, ServerName FROM Perf_MonitoredServers WHERE ServerName = '$($env:COMPUTERNAME)'"
GetLogins $server
GetServerRoles $server
GetServerPermissions $server
        
$databases = Invoke-Sqlcmd -ServerInstance $($server.ServerName) -Query "SELECT Name FROM sysdatabases"
foreach ($database in $databases)
{
    GetDatabaseRoleAccess $server $database.Name
    GetDatabaseRoleMembers $server $database.Name
    GetDatabaseExplicitGrants $server $database.Name
}

Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "usp_Security_Merge"

Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseRoleMembers_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseRolePermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_DatabaseUserPermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_ServerPermissions_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_ServerRoles_Stage"
Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Security_Logins_Stage"