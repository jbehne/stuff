﻿Import-Module sqlps

$MonitoredServers = (Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "SELECT ServerName FROM vw_AllMonitoredServers WHERE LastUpdated > GETDATE() - 1 AND ServerName <> 'C1DBD069'").ServerName
$CMSServers = (Get-ChildItem -Path "SQLSERVER:\SQLRegistration\Central Management Server Group\C1DBD069" -Recurse | Where ServerName -ne $null | Select ServerName).ServerName

#New-Item -Path "SQLSERVER:\SQLRegistration\Central Management Server Group\C1DBD069\Production" -Name "C1DBD999" -Value "Server=C1DBD999;Integrated security=true" -ItemType Registration

$MissingInCMS = $MonitoredServers | Where {$CMSServers -notcontains $_}

foreach ($m in $MissingInCMS) 
{
    $Query = "SELECT Environment, 
	    CASE SUBSTRING(Version, 0, 3) 
		    WHEN 10 THEN '2008R2'
		    WHEN 11 THEN '2012'
		    WHEN 12 THEN '2014'
		    WHEN 13 THEN '2016'
		    WHEN 14 THEN '2017'
	    END Version 
    FROM vw_AllMonitoredServers WHERE ServerName = '$m'"

    $Server = Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query $Query
    New-Item -Path "SQLSERVER:\SQLRegistration\Central Management Server Group\C1DBD069\Test\$($Server.Version)" -Name $m -Value "Server=$m;Integrated security=true" -ItemType Registration

}