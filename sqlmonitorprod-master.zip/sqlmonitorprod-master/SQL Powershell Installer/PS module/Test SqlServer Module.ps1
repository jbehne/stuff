﻿function Write-Log ($file, $type, $message)
{
    "$type - $(Get-Date -Format hh:mm:ss) : $message" | Out-File $file -Append
}

$log = "E:\AAG_Configuration_$(Get-Date -Format MMddyyyy-hhmmss)`.txt"


#  CHECK FOR SQLSERVER MODULE AND LOAD IF NEEDED  
if ((Test-Path "C:\Program Files\WindowsPowerShell\Modules\SqlServer") -eq $false)
{
    Write-Log $log "INF" "SqlServer Powershell module not found."
    Copy-Item "\\C1UTL209\E`$\SQLServer\PS module\SqlServer" "C:\Program Files\WindowsPowerShell\Modules" -Recurse -Force
    Write-Log $log "INF" "Copied SqlServer Powershell module files."
}

$SQLModuleImported = Get-Module SqlServer
if ($SQLModuleImported -eq $null)
{
    Write-Log $log "INF" "SqlServer Powershell module not loaded."
    Import-Module -Name SqlServer
    Write-Log $log "INF" "Imported SqlServer Powershell module."
}