﻿$queue = Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query "SELECT * FROM Backup_Request WHERE Size IS NULL;"
foreach ($q in $queue)
{
    $query = "BACKUP DATABASE [$($q.DatabaseName)] TO DISK = '$($q.FileName)' WITH COMPRESSION, COPY_ONLY, NAME='$($q.Backup_Request_ID)'"
    $conn = New-Object System.Data.SqlClient.SQLConnection("Data Source=$($q.ServerName);Integrated Security=SSPI;Database=master;Connection Timeout=0")
    $conn.Open()
    $cmd = New-Object System.Data.SqlClient.SqlCommand($query, $conn)
    $cmd.CommandTimeout = 0
    $cmd.ExecuteNonQuery() 
    
    $size = (Invoke-Sqlcmd -ServerInstance $($q.ServerName) -Database msdb -Query "SELECT compressed_backup_size/1024 size FROM msdb..backupset WHERE name = '$($q.Backup_Request_ID)'").size

    $query = "UPDATE br
                SET Size = $($size)
                FROM Backup_Request br
                WHERE br.Backup_Request_ID = '$($q.Backup_Request_ID)'"

    Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query $query
    Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query "EXEC usp_EmailNotification '$($q.Backup_Request_ID)'"
        
}