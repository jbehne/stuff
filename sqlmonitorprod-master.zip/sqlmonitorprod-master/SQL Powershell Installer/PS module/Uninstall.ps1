﻿

&"C:\Program Files\Microsoft SQL Server\120\Setup Bootstrap\SQLServer2014\Setup.exe" /Action=Uninstall /FEATURES=SQL,AS,RS,IS,Tools /INSTANCENAME=MSSQLSERVER


&"C:\Program Files\Microsoft SQL Server\130\Setup Bootstrap\SQLServer2016\Setup.exe" /Action=Uninstall /FEATURES=SQL,AS,RS,IS,Tools /INSTANCENAME=MSSQLSERVER

&"C:\Program Files\Microsoft SQL Server\140\Setup Bootstrap\SQL2017\Setup.exe" /Action=Uninstall /FEATURES=SQL,AS,RS,IS,Tools /INSTANCENAME=MSSQLSERVER


Start-Process 'U:\SSMS 2017\SSMS-Setup-ENU.exe' -ArgumentList "/uninstall /norestart /passive" -Wait
#Start-Process 'U:\SSDT 2017\SSDT-Setup-ENU.exe' -ArgumentList "/uninstall /norestart /passive" -Wait

<#
Remove-Item 'C:\Program Files\Microsoft SQL Server\' -Recurse -Force
Remove-Item 'C:\Program Files (x86)\Microsoft SQL Server\' -Recurse -Force
Remove-Item 'E:\Data' -Recurse
Remove-Item 'L:\Data' -Recurse
Remove-Item 'M:\Data' -Recurse


Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server" | Remove-Item -Recurse
Get-ChildItem "HKLM:\SOFTWARE\Microsoft\MSSQLServer" | Remove-Item -Recurse
$path = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" | Get-ItemProperty | Where DisplayName -like '*sql*' | Select PSPath
foreach ($p in $path)
{
    $p = $p.PSPath.Replace('Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE', 'HKLM:')
    Remove-Item $p -Recurse
}
Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services" | Where name -like '*sql*' | Remove-Item -Recurse


#>