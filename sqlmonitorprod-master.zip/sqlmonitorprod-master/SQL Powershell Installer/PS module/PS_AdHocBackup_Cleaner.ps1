﻿$files = Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query "SELECT Backup_Request_ID, FileName FROM Backup_Request WHERE DATEADD(dd, RetentionDays, RequestDate) < GETDATE();"
foreach ($f in $files)
{
    Remove-Item $($f.FileName)

    $query = "INSERT Backup_Request_History 
                SELECT Backup_Request_ID, ServerName, DatabaseName, FileName, 
	                RequestDate, Requestor, RequestorEmail, RetentionDays, GETDATE() 
                FROM Backup_Request
                WHERE Backup_Request_ID = '$($f.Backup_Request_ID)'"
    Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query $query
    Invoke-Sqlcmd -ServerInstance C1DBD536 -Database ADHOC_BACKUP -Query "DELETE Backup_Request WHERE Backup_Request_ID = '$($f.Backup_Request_ID)'"
}