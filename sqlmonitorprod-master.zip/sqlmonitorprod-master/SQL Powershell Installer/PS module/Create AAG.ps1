function Write-Log ($file, $type, $message)
{
    "$type - $(Get-Date -Format hh:mm:ss) : $message" | Out-File $file -Append
    "$type - $(Get-Date -Format hh:mm:ss) : $message" | Out-Host
}

#  LOG FILE
$log = "E:\AAG_Configuration_$(Get-Date -Format MMddyyyy-hhmmss)`.txt"

#  GET CLUSTER
Write-Log $log "INF" "Cluster name is $((Get-Cluster).Name)."

#  CHECK FOR CLUSTER NODES  
$NodeCount = 0
$NodeCount = (Get-ClusterNode).Count
Write-Log $log "INF" "Cluster nodes found: $NodeCount"

if ($NodeCount -lt 2)
{
    "Could not locate 2 or more cluster nodes."
    Write-Log $log "ERR" "No cluster nodes found."
    return;
}

#  CHECK FOR SQLSERVER MODULE AND LOAD IF NEEDED  
if ((Test-Path "C:\Program Files\WindowsPowerShell\Modules\SqlServer") -eq $false)
{
    Write-Log $log "INF" "SqlServer Powershell module not found."
    Copy-Item "\\c1utl209\e`$\SQLServer\PRODUCTS\PSMODULE\SqlServer" "C:\Program Files\WindowsPowerShell\Modules" -Recurse -Force
    Write-Log $log "INF" "Copied SqlServer Powershell module files."
}

$SQLModuleImported = Get-Module SqlServer
if ($SQLModuleImported -eq $null)
{
    Write-Log $log "INF" "SqlServer Powershell module not loaded."
    Import-Module -Name SqlServer
    Write-Log $log "INF" "Imported SqlServer Powershell module."
}

#  GET NODE NAMES  
$Nodes = (Get-ClusterNode).Name.ToUpper()
foreach ($Node in $Nodes)
{
    Write-Log $log "INF" "Found Node: $Node"
}

#  GET AAG NAME FROM CLUSTER
$AAGName = $((Get-Cluster).Name -replace "CLT","AAG").ToUpper()
Write-Log $log "INF" "Availability Group Name will be $AAGName."

#  GET LISTENER NAME FROM CLUSTER
$ListenerName = $((Get-Cluster).Name -replace "CLT","LST").ToUpper()
Write-Log $log "INF" "Availability Group Listener Name will be $ListenerName."

#  GET LISTENER IP ADDRESS
$ListenerIP = ([System.Net.Dns]::GetHostAddresses("$ListenerName")).IPAddressToString
if ($ListenerIP -eq $null)
{
    Write-Log $log "INF" "Availability Group Listener $ListenerName could not be resolved, terminating."
    return
}

Write-Log $log "INF" "Availability Group Listener IP is $ListenerIP."

#  ENABLE HADR ON EACH NODE  
foreach ($Node in $Nodes)
{
    $HADREnabled = (Get-Item "SQLSERVER:\SQL\$Node\Default" | Select IsHADREnabled).IsHADREnabled
    Write-Log $log "INF" "Checked if HADR enabled on $Node : $HADREnabled`."
    if ($HADREnabled -eq $false)
    {
        Write-Log $log "INF" "Enabling HADR on $Node`."
        Enable-SqlAlwaysOn -Path "SQLSERVER:\SQL\$Node\Default" -Force
        Write-Log $log "INF" "Enabled HADR on $Node`, restarting SQL service."
        Get-Service -ComputerName $Node | Where Name -eq "MSSQLSERVER" | Restart-Service -Force | Out-Null
        Write-Log $log "INF" "SQL service has restarted on $Node`."
        Get-Service -ComputerName $Node | Where Name -eq "SQLSERVERAGENT" | Start-Service | Out-Null
        Write-Log $log "INF" "SQL Agent service has started on $Node`."
    }

    New-SqlHADREndpoint -Path "SQLSERVER:\SQL\$Node\Default" -Name "HADR_Endpoint" -Port 5022 -EncryptionAlgorithm Aes -Encryption Required | Out-Null
    Write-Log $log "INF" "Created HADR endpoint on $Node`."
    Set-SqlHADREndpoint -Path "SQLSERVER:\SQL\$Node\Default\Endpoints\HADR_Endpoint" -State Started | Out-Null
    Write-Log $log "INF" "Started HADR endpoint on $Node`."
}

$PrimaryDomain = (Get-WmiObject Win32_ComputerSystem -ComputerName $Nodes[0]).Domain
Write-Log $log "INF" "$($Nodes[0]) domain is $PrimaryDomain."
$SecondaryDomain = (Get-WmiObject Win32_ComputerSystem -ComputerName $Nodes[1]).Domain
Write-Log $log "INF" "$($Nodes[1]) domain is $SecondaryDomain."

#Create the primary replica as a template object
$primaryReplica = New-SqlAvailabilityReplica -Name $Nodes[0] -EndpointUrl "TCP://$($Nodes[0])`.$PrimaryDomain`:5022" `
    -AvailabilityMode "SynchronousCommit" -FailoverMode 'Automatic' -AsTemplate -Version 13  `
    -ReadonlyRoutingConnectionUrl "TCP://$($Nodes[0])`.$PrimaryDomain`:1433" -ConnectionModeInSecondaryRole AllowAllConnections `
    -ReadOnlyRoutingList "$($Nodes[1])", "$($Nodes[0])"

#Create the secondary replica as a template object
$secondaryReplica = New-SqlAvailabilityReplica -Name $Nodes[1] -EndpointUrl "TCP://$($Nodes[1])`.$SecondaryDomain`:5022" `
    -AvailabilityMode "SynchronousCommit" -FailoverMode 'Automatic' -AsTemplate -Version 13 `
    -ReadonlyRoutingConnectionUrl "TCP://$($Nodes[1])`.$SecondaryDomain`:1433" -ConnectionModeInSecondaryRole AllowAllConnections `
    -ReadOnlyRoutingList "$($Nodes[0])", "$($Nodes[1])"

#Create the Availability Group
New-SqlAvailabilityGroup -InputObject $Nodes[0] -Name $AAGName -AvailabilityReplica ($primaryReplica, $secondaryReplica) | Out-Null
Write-Log $log "INF" "Availability Group $AAGName has been created."
   
#Join replicas to the Availability Group
Join-SqlAvailabilityGroup -Path "SQLSERVER:\SQL\$($Nodes[1])\Default" -Name $AAGName | Out-Null
Write-Log $log "INF" "Replicas have been joined to $AAGName."

#Create the Availability Group listener name
New-SqlAvailabilityGroupListener -Name $ListenerName -staticIP "$ListenerIP/255.255.254.0" -Port 1433 -Path "SQLSERVER:\SQL\$($Nodes[0])\DEFAULT\AvailabilityGroups\$AAGName" | Out-Null
Write-Log $log "INF" "Availability Group Listener $ListenerName has been created with an IP Address of $ListenerIP."

#Create the file for SCCM patching to perform a failover prior to patching.
"" | Out-File "\\$($Nodes[0])\E$\AAG.txt"
"" | Out-File "\\$($Nodes[1])\E$\AAG.txt"

Write-Log $log "INF" "Availability Group file \\$($Nodes[0])\E$\AAG.txt has been created for SCCM patching."
Write-Log $log "INF" "Availability Group file \\$($Nodes[1])\E$\AAG.txt has been created for SCCM patching."

Write-Log $log "INF" "***********************************************************************************"
Write-Log $log "INF" "Availability Group Configuration has completed, database can now be joined."
Write-Log $log "INF" "***********************************************************************************"


#  Add TestDB to availability group
Invoke-Sqlcmd -ServerInstance $Nodes[0] -Query "CREATE DATABASE TestDB"
Write-Log $log "INF" "Created TestDB on $($Nodes[0])`."
Invoke-Sqlcmd -ServerInstance $Nodes[0] -Query "BACKUP DATABASE TestDB TO DISK = 'L:\Data\TestDB.bak' WITH COMPRESSION"
Write-Log $log "INF" "Created local backup of TestDB on $($Nodes[0])`."
Invoke-Sqlcmd -ServerInstance $Nodes[1] -Query "RESTORE DATABASE TestDB FROM DISK = '\\$($Nodes[0])\L$\Data\TestDB.bak' WITH NORECOVERY"
Write-Log $log "INF" "Restored backup of TestDB on $($Nodes[1])`."
Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$($Nodes[0])\DEFAULT\AvailabilityGroups\$AAGName" -Database TestDB
Write-Log $log "INF" "Added TestDB to replica on $($Nodes[0])`."
Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$($Nodes[1])\DEFAULT\AvailabilityGroups\$AAGName" -Database TestDB
Write-Log $log "INF" "Added TestDB to replica on $($Nodes[1])`."

