﻿$ad = Get-Module ActiveDirectory
if ($ad -eq $null)
{
    Add-WindowsFeature RSAT-AD-PowerShell
    Import-Module ActiveDirectory
}

Get-ADGroupMember "ITS DBAS"