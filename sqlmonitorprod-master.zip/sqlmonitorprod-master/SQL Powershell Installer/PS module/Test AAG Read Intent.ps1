﻿##replace variables as needed##
$Server = 'ABPLSTQA01'   
$Database = 'TestDB'

#$Server = 'V01LSTWIN502'   
#$Database = 'XBSHSBD3'

$Connection = New-Object System.Data.SQLClient.SQLConnection
$Connection.ConnectionString = "Server=$($Server);Database=$($Database);Integrated Security=True"
$Connection.Open()
$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$Command.CommandText = 'Select @@SERVERNAME Server, ''Standard'' Type'
$Reader = $Command.ExecuteReader()
$Datatable = New-Object System.Data.DataTable
$Datatable.Load($Reader)
$Datatable
$Connection.Close()
$Connection = New-Object System.Data.SQLClient.SQLConnection
$Connection.ConnectionString = "Server=$($Server);Database=$($database);Integrated Security=True;ApplicationIntent=ReadOnly"
$Connection.Open()
$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$Command.CommandText = 'Select @@SERVERNAME Server, ''ReadIntent'' Type'
$Reader = $Command.ExecuteReader()
$Datatable = New-Object System.Data.DataTable
$Datatable.Load($Reader)
$Datatable
$Connection.Close()  