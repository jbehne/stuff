function WriteLog ($msg)
{
    "INF: $(Get-Date -Format "hh:mm:ss") -      $msg" | Out-File $log -Append
    Invoke-Sqlcmd -ServerInstance . -Database SQLADMIN -Query "INSERT Certificate_Log VALUES (GETDATE(), '$msg')"
}

try
{
    $Global:log = "E:\CertificateLog.txt"
    "INF: $(Get-Date -Format "hh:mm:ss") - Starting certificate check"  | Out-File $log

    # Get the certificate (filter by expiration date and then look for the correct issuer)
    $cert = Get-ChildItem 'Cert:\LocalMachine\My' | Where-Object{ $_.Extensions | 
        Where-Object{ ($_.Oid.FriendlyName -eq 'Certificate Template Information') -and ($_.Format(0) -match "cfWinServerAutoEnroll") }} 

    # If there is more than 1 cert (or no cert) stop and evaluate to set the $cert variable to the correct certificate
    if ($cert.Count -ne 1)
    {
        WriteLog "Certificate count does not equal 1, manual intervention required.  Exit." 
        throw "Certificate count does not equal 1, manual intervention required.  Exit." 
    }

    # Check expiration of the current cert, if it expires in < 1 month renew and get the new cert
    WriteLog "Certificate expires on $($cert.NotAfter)"

    # Get the date and add 1 month
    $date = Get-Date
    $date = $date.AddMonths(1)

    # If the certificate expires within the month it needs to be renewed
    if ($cert.NotAfter -le $date)
    {
        WriteLog "Certificate will expire before the next patch cycle, renewing."

        # This is the command to renew
        &certreq -q -enroll -machine -cert "$(($cert.SerialNumber -split "([a-z0-9]{2})"  | ?{ $_.length -ne 0 }) -join " ")" Renew ReuseKeys
        
        # Get the updated cert
        $cert = Get-ChildItem 'Cert:\LocalMachine\My' | Where-Object{ $_.Extensions | 
            Where-Object{ ($_.Oid.FriendlyName -eq 'Certificate Template Information') -and ($_.Format(0) -match "cfWinServerAutoEnroll") }} 

        WriteLog "Certificate has been renewed with thumbprint $($cert.Thumbprint)"
        WriteLog "New certificate expires on $($cert.NotAfter)"
    }

    # Output the registry path
    $path = (Get-Item "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib").Name
    WriteLog "Registry path is $path"

    # Check if certificate is assigned
    $certcheck = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib" -Name "Certificate").Certificate
    if ($certcheck -ne $cert.Thumbprint)
    {
        WriteLog "Assigning certificate with thumbprint $($cert.Thumbprint) with expiration of $($cert.NotAfter)"
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib" -Name "Certificate" -Type String -Value $cert.Thumbprint -ErrorAction Stop
    }

    else
    {
        WriteLog "Certificate $certcheck is still valid, no changes made."
    }

    WriteLog "Current certificate thumbprint = $($cert.Thumbprint)"
}

catch
{
    WriteLog "Error occurred - $_"
    throw $_
}

