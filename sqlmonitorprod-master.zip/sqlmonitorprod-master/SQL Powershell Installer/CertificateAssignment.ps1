function WriteLog ($msg)
{
    "INF: $(Get-Date -Format "hh:mm:ss") -      $msg" | Out-File $log -Append
}


try
{
    $Global:log = $args[0]

    # Get the certificate (filter by expiration date and then look for the correct issuer)
    $cert = Get-ChildItem -Path cert:\LocalMachine\My -ErrorAction Stop | Where NotAfter -ge $(Get-Date)
    $cert = $cert | Where Issuer -Like "*CCServices*"

    # If there is more than 1 cert (or no cert) stop and evaluate to set the $cert variable to the correct certificate
    if ($cert.Count -ne 1)
    {
        WriteLog "Certificate count does not equal 1, manual intervention required.  Exit." 
        return
    }

    # Output the registry path
    $path = (Get-Item "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib").Name
    WriteLog "Registry path is $path"

    # Check to make sure no cert is already assigned
    $certcheck = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib" -Name "Certificate").Certificate
    if ($certcheck -ne "")
    {
        WriteLog "Certificate $certcheck is already assigned.  Exit."
        return
    }
    
    # Assign the thumbprint to SQL Server
    WriteLog "Assigning certificate with thumbprint $($cert.Thumbprint)"
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQLServer\SuperSocketNetLib" -Name "Certificate" -Type String -Value $cert.Thumbprint -ErrorAction Stop

    # Get the SQL Server service account
    $serviceaccount = (Get-WmiObject Win32_Service | Where Name -EQ "MSSQLSERVER" | SELECT startname -ErrorAction Stop).startname 
    WriteLog "Service account is $serviceaccount"

    # Get Location of the machine keys
    $keyPath = $env:ProgramData + "\Microsoft\Crypto\RSA\MachineKeys\"; 

    #Grant read access to machine key directory for SQL account
    $permissionType = 'Read'

    # Get the current ACL
    $acl = (Get-Item $keyPath).GetAccessControl('Access') 

    # Create a new ACL rule
    $buildAcl = New-Object System.Security.AccessControl.FileSystemAccessRule($serviceAccount,$permissionType,"Allow") -ErrorAction Stop

    # Add the new ACL rule into the existing ACL
    $acl.SetAccessRule($buildAcl) 

    # Apply the ACL update
    Set-Acl $keyPath $acl -ErrorAction Stop
    WriteLog "Added $serviceaccount read access to $keypath"

    # Double check ACL for access
    $acl = (Get-Item $keyPath).GetAccessControl('Access') 
    $access = $acl | Select AccessToString
    foreach ($a in $access.AccessToString.Split("`r`n"))
    {
        WriteLog "Access: $a"
    }
}

catch
{
    WriteLog $Error
}


<#
 Restart-Service MSSQLSERVER -force

 notepad.exe "C:\Users\Public\Documents\SQLCertificate.txt"

 $query = "DECLARE @errorlog TABLE (LogDate smalldatetime, ProcessInfo varchar(512), Text varchar(max));
    INSERT @errorlog
    EXEC sys.xp_readerrorlog 0;
    SELECT * FROM @errorlog WHERE Text LIKE '%certificate%'"
 Invoke-SqlCmd -ServerInstance . -Query $query
#>