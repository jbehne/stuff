<# SQL Permissions.ps1                                                            
###############################################################################
 This program does the following:                                              
   1) Finds all folders for each of the 4 scenarios below.
   2) Passes the folders to functions which remove all security (except Admins)
      and then adds back the appropriate access.                                         
###############################################################################
 INPUT PARMS:                                                                  
    None                                                                       
###############################################################################
 PROGRAM HISTORY                                                               
                                                                               
 NAME         DATE      DESCRIPTION                                            
 Jeremy    26JUN18      New program.                                           
################################################################################>

<#
1.  C:\Program files*\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQL\Bin*
    C:\Program files*\Microsoft SQL Server\*\Tools\Bin* 
    C:\Program files*\Microsoft SQL Server\*\COM
    a.	FULL Control
        i.	Builtin/Administrators
        ii.	CREATOR OWNER
        iii.	NT AUTHORITY\SYSTEM
        iv.	NT SERVICE\TrustedInstaller
    b.	Read and Execute
        i.	ServerName\SQLServerDTSUser$ServerName
        ii.	ServerName\SQLServerMSSQLUser$ServerName$MSSQLSERVER
        iii.	ServerName\SQLServerReportServerUser$ServerName$MSRS*.MSSQLSERVER
        iv.	NT SERVICE\MSSQLFDLauncher
2.	C:\Program Files*\Microsoft SQL Server
    a.	Read, Write, Special
        i.	ServerName\SQLServerReportServerUser$ServerName$MSRS*.MSSQLSERVER
    b.	FULL Control
        i.	Builtin\Administrators
        ii.	NT AUTHORITY\SYSTEM
3.	E: (and greater)\Data\MSSQL* 
    a.	Full Control
        i.	Builtin/Administrators
        ii.	CREATOR OWNER
        iii.	NT AUTHORITY\SYSTEM
        iv.	NT SERVICE\TrustedInstaller
        v.	NT Service\MSSQLFDLauncher
        vi.	ServerName\SQLServerMSSQLUser$ServerName$MSSQLSERVER
4.  C:\Program Files*\Microsoft SQL Server\***\Shared
    a.	FULL Control
        i.	Builtin/Administrators
        ii.	CREATOR OWNER
        iii.	NT AUTHORITY\SYSTEM
        iv.	NT SERVICE\TrustedInstaller
    b.	Read and Execute
        i.	Builtin/Users
#>

function f_ClearPermissions($path)
{
    try
    {
        # Get the current ACL
        $acl = Get-Acl $path

        # Disable inheritance while keeping inherited objects
        $acl.SetAccessRuleProtection($true,$true)

        # Apply the rule back to the folder/file
        Set-Acl -Path $path -AclObject $acl

        # Clear all access from the ACL object, except Administrators so we don't lose access!
        foreach ($a in $acl.Access)
        {
            if ($a.IdentityReference -like "APPLICATION PACKAGE AUTHORITY*" -or $a.IdentityReference -ne 'BUILTIN\Administrators')
            {
                #Output dropped accounts
                "INF: $(Get-Date -Format hh:mm:ss) -      REMOVED: " + $a.IdentityReference | Out-File $log -Append
                #It doesn't like the APPLICATION PACKAGE AUTHORITY\ in the name
                $account = $a.IdentityReference.ToString().Replace("APPLICATION PACKAGE AUTHORITY\", "")
                # Using icacls because SET-ACL just doesn't work for removing all accounts
                &icacls $path /remove:g $account | Out-Null
            }
        }
    }

    catch
    {
        "ERR: $(Get-Date -Format hh:mm:ss) -       $path (" + $_.exception.message + ")" | Out-File $log -Append
    }
}

function f_AddACL($path, $user, $permission)
{
    try
    {
        # User, Access, Inheritance, Propagation, {Allow/Deny}
        $acl = Get-Acl $path
        $acl.SetAccessRuleProtection($true,$true)
        $ar = New-Object System.Security.AccessControl.FileSystemAccessRule($user, $permission, 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($ar)

        # Apply the ACL to the folder/file
        Set-Acl -Path $path -AclObject $acl

        #Output added accounts
        "INF: $(Get-Date -Format hh:mm:ss) -      ADDED: " + $user | Out-File $log -Append
    }

    catch
    {
        "ERR: $(Get-Date -Format hh:mm:ss) -      $path (" + $_.exception.message + ")" | Out-File $log -Append
    }
}

function f_SetPermissions_1($path) 
{
    # Clear permissions and disable inheritance
    f_ClearPermissions $path

    # Create new access rules as defined above.      
    f_AddACL $path "NT AUTHORITY\SYSTEM" "FullControl"
    f_AddACL $path "CREATOR OWNER" "FullControl"
    f_AddACL $path "NT SERVICE\TrustedInstaller" "FullControl"
    f_AddACL $path "NT SERVICE\MSSQLFDLauncher" "ReadAndExecute"
    f_AddACL $path "NT SERVICE\ReportServer" "ReadAndExecute"
    f_AddACL $path "NT SERVICE\MSSQLSERVER" 'ReadAndExecute'

    # Output 
    "INF: $(Get-Date -Format hh:mm:ss) -      Completed Permission Set #1 on $path" | Out-File $log -Append
}

function f_SetPermissions_2($path)
{
    # Clear permissions and disable inheritance
    f_ClearPermissions $path

    # Create new access rules as defined above.
    f_AddACL $path "NT AUTHORITY\SYSTEM" "FullControl"
    f_AddACL $path "NT SERVICE\ReportServer" "ReadAndExecute"

    # Output 
    "INF: $(Get-Date -Format hh:mm:ss) -      Completed Permission Set #2 on $path" | Out-File $log -Append
}

function f_SetPermissions_3($path)
{
    # Clear permissions and disable inheritance
    f_ClearPermissions $path

    # Create new access rules as defined above.
    f_AddACL $path "NT AUTHORITY\SYSTEM" 'FullControl'
    f_AddACL $path "CREATOR OWNER" 'FullControl'
    f_AddACL $path "NT SERVICE\TrustedInstaller" 'FullControl'
    f_AddACL $path "NT SERVICE\MSSQLSERVER" 'FullControl'
    f_AddACL $path "NT SERVICE\MSSQLFDLauncher" 'FullControl'

    # Output 
    "INF: $(Get-Date -Format hh:mm:ss) -      Completed Permission Set #3 on $path" | Out-File $log -Append
}

function f_SetPermissions_4($path)
{
    # Clear permissions and disable inheritance
    f_ClearPermissions $path

    # Create new access rules as defined above.
    f_AddACL $path "BUILTIN\Users" "ReadAndExecute"

    f_AddACL $path "NT AUTHORITY\SYSTEM" 'FullControl'
    f_AddACL $path "CREATOR OWNER" 'FullControl'
    f_AddACL $path "NT SERVICE\TrustedInstaller" 'FullControl'
    f_AddACL $path "NT SERVICE\MSSQLFDLauncher" 'FullControl'
    f_AddACL $path "NT SERVICE\MSSQLSERVER" 'FullControl'
        

    # Output 
    "INF: $(Get-Date -Format hh:mm:ss) -      Completed Permission Set #4 on $path" | Out-File $log -Append
}

$Global:log = $args[0]

# The actual start of the script!
($paths_1 = @())
$paths_1 += @(Get-ChildItem "C:\Program files*\Microsoft SQL Server\MSSQL*.MSSQLSERVER\MSSQL\Bin*").FullName 
$paths_1 += @(Get-ChildItem "C:\Program files*\Microsoft SQL Server\*\Tools\Bin*").FullName 
$paths_1 += @(Get-ChildItem "C:\Program files*\Microsoft SQL Server\*\COM").FullName 

($paths_2 = @())
$paths_2 += @(Get-ChildItem "C:\Program Files*\Microsoft SQL Server").FullName 

($paths_3 = @())
$devices = (Get-WmiObject Win32_LogicalDisk | Where {($_.ProviderName -NotLike '\\*' -and $_.DeviceID -ne "C:" -and $_.DeviceID -ne "D:")}  | Select DeviceID).DeviceID 
foreach ($device in $devices)
{
    if (Test-Path "$device\Data\MSSQL*")
    {
        $paths_3 += @(Get-Childitem "$device\Data\MSSQL*").FullName 
    }
}

($paths_4 = @())
Foreach ($path in (Get-ChildItem "C:\Program Files*\Microsoft SQL Server" -Recurse))
{
    if ($path.FullName -like '*Shared*' -and $path -is [System.IO.DirectoryInfo])
    {
        $paths_4 += $path.Fullname
    }
}

"INF: $(Get-Date -Format hh:mm:ss) -      *****************************************************************************" | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      Files and Folders in Security Set 1: " + $paths_1.Count | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      Files and Folders in Security Set 2: " + $paths_2.Count | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      Files and Folders in Security Set 3: " + $paths_3.Count | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      Files and Folders in Security Set 4: " + $paths_4.Count | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      *****************************************************************************" | Out-File $log -Append

"INF: $(Get-Date -Format hh:mm:ss) -      #############################################################################" | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      Starting ACL processing..." | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      #############################################################################" | Out-File $log -Append

foreach ($path in $paths_1)
{
    "INF: $(Get-Date -Format hh:mm:ss) -      Starting Permission Set #1 on $path" | Out-File $log -Append
    f_SetPermissions_1 $path
}

foreach ($path in $paths_2)
{
    "INF: $(Get-Date -Format hh:mm:ss) -      Starting Permission Set #2 on $path" | Out-File $log -Append
    f_SetPermissions_2 $path
}

foreach ($path in $paths_3)
{
    "INF: $(Get-Date -Format hh:mm:ss) -      Starting Permission Set #3 on $path" | Out-File $log -Append
    f_SetPermissions_3 $path
}

foreach ($path in $paths_4)
{
    "INF: $(Get-Date -Format hh:mm:ss) -      Starting Permission Set #4 on $path" | Out-File $log -Append
    f_SetPermissions_4 $path
}


"INF: $(Get-Date -Format hh:mm:ss) -      #############################################################################" | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      ACL processing completed." | Out-File $log -Append
"INF: $(Get-Date -Format hh:mm:ss) -      #############################################################################" | Out-File $log -Append
