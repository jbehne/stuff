Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "TRUNCATE TABLE Version_SQLList"
Invoke-WebRequest -Uri "https://aka.ms/SQLServerbuilds" -OutFile E:\SQLVersion\SQLVersion.xlsx

$results = Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName 2019
$results += Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName 2017
$query = ""
foreach ($result in $results)
{
    if ([string]::IsNullOrEmpty($result.'Notes regarding Lifecycle stage'))
    {
        $note = ""
    }

    else
    {
        $note = $($result.'Notes regarding Lifecycle stage'.Replace("'", ""))
    }

    $query += "INSERT Version_SQLList (BuildNumber, KBNumber, ReleaseDate, ServicePack, CumulativeUpdate_SecurityID, ServicingModel, 
                IncludesLatestFixes, IncludesLatestUpdates, LifeCycleStatus, LifeCycleNotes) VALUES (
                '$($result.'Build number')',
                '$($result.'KB number')',
                '$([datetime]::FromOADate($result.'Release Date'))',
                null,
                '$($result.'Cumulative Update number/Security ID')',
                '$($result.'Modern Servicing Model')',
                '$($result.'Includes latest security fixes?')',
                '$($result.'Includes latest security updates?')',
                '$($result.'Lifecycle stage')',
                '$note');
                "
}


$results = Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName 2016
$results += Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName 2014
foreach ($result in $results)
{
    if ([string]::IsNullOrEmpty($result.'Notes regarding Lifecycle stage'))
    {
        $note = ""
    }

    else
    {
        $note = $($result.'Notes regarding Lifecycle stage'.Replace("'", ""))
    }

    $query += "INSERT Version_SQLList (BuildNumber, KBNumber, ReleaseDate, ServicePack, CumulativeUpdate_SecurityID, ServicingModel, 
                IncludesLatestFixes, IncludesLatestUpdates, LifeCycleStatus, LifeCycleNotes) VALUES (
                '$($result.'Build number')',
                '$($result.'KB number')',
                '$([datetime]::FromOADate($result.'Release Date'))',
                '$($result.'Service Pack/RTM')',
                '$($result.'Cumulative Update number/Security ID')',
                '$($result.'Modern Servicing Model')',
                '$($result.'Includes latest security fixes?')',
                '$($result.'Includes latest security updates?')',
                '$($result.'Lifecycle stage')',
                '$note');
                "
}

$results = Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName 2012
foreach ($result in $results)
{
    if ([string]::IsNullOrEmpty($result.'Notes regarding Lifecycle stage'))
    {
        $note = ""
    }

    else
    {
        $note = $($result.'Notes regarding Lifecycle stage'.Replace("'", ""))
    }

    $query += "INSERT Version_SQLList (BuildNumber, KBNumber, ReleaseDate, ServicePack, CumulativeUpdate_SecurityID, ServicingModel, 
                IncludesLatestFixes, IncludesLatestUpdates, LifeCycleStatus, LifeCycleNotes) VALUES (
                '$($result.'Build number')',
                '$($result.'KB number')',
                '$([datetime]::FromOADate($result.'Release Date'))',
                '$($result.'Service Pack/RTM')',
                '$($result.'Cumulative Update number/Security ID')',
                '$($result.'Modern Servicing Model')',
                '$($result.'Includes latest security fixes?')',
                null,
                '$($result.'Lifecycle stage')',
                '$note');
                "
}

$results = Import-Excel -Path E:\SQLVersion\SQLVersion.xlsx -WorksheetName "2008 R2"
foreach ($result in $results)
{
    if ([string]::IsNullOrEmpty($result.'Notes regarding Lifecycle stage'))
    {
        $note = ""
    }

    else
    {
        $note = $($result.'Notes regarding Lifecycle stage'.Replace("'", ""))
    }

    $query += "INSERT Version_SQLList (BuildNumber, KBNumber, ReleaseDate, ServicePack, CumulativeUpdate_SecurityID, ServicingModel, 
                IncludesLatestFixes, IncludesLatestUpdates, LifeCycleStatus, LifeCycleNotes) VALUES (
                '$($result.'Build number')',
                '$($result.'KB number')',
                '$([datetime]::FromOADate($result.'Release Date'))',
                '$($result.'Service Pack/RTM')',
                '$($result.'Cumulative Update number/Security ID')',
                '$($result.'Modern Servicing Model')',
                '$($result.'Includes latest security fixes')',
                null,
                '$($result.'Lifecycle stage')',
                '$note');
                "
}

Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query
Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "DELETE Version_SQLList WHERE BuildNumber = '';UPDATE Version_SQLList SET BuildNumber = REPLACE(BuildNumber, ' ', '')"