﻿$Global:repository = $args[0]

function f_LoadSchedules ($server)
{
    $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=$Global:repository;Integrated Security=SSPI;Database=SQLMONITOR")
    $repositoryconnection.Open()
        
    $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
    $bc.BatchSize = 100000
    $bc.EnableStreaming = "True"
    $bc.BulkCopyTimeout = 120

    $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($server.ServerName);Database=msdb;Integrated Security=true")
    $sqlconn.Open()
        
    $query = "SELECT $($server.InstanceID), name, dbo.agent_datetime(jh.run_date, jh.run_time), run_duration
            FROM sysjobhistory jh
            INNER JOIN sysjobs sj ON sj.job_id = jh.job_id
            WHERE name LIKE 'Maintenance%'
            AND step_id = 0
            AND dbo.agent_datetime(jh.run_date, jh.run_time) > GETDATE() - 3"
    $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
    $sqlreader = $sqlcmd.ExecuteReader()

    $bc.DestinationTableName = "Maintenance_JobDuration_Stage"
    $bc.WriteToServer($sqlreader)
    $sqlreader.Close()            
}

workflow wf_LoadSchedules ($servers)
{
    foreach -parallel -throttlelimit 4 ($server in $servers) 
    {
        f_LoadSchedules $server
    }
}

Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "TRUNCATE TABLE Maintenance_JobDuration_Stage"
$servers = Invoke-Sqlcmd -ServerInstance $Global:repository -Database SQLMONITOR -Query "SELECT InstanceID, ServerName FROM Perf_MonitoredServers WHERE IsActive = 1"
wf_LoadSchedules $servers
