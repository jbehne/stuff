﻿#\\alliance\dfs\DBA\DBMS\SQL Server

Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQlMONITOR -Query "TRUNCATE TABLE File_Share"

$files = Get-ChildItem -Path "\\alliance\dfs\DBA\DBMS\SQL Server" -Recurse | Where PSIsContainer -ne $true | Select FullName, CreationTime, LastWriteTime

foreach ($file in $files)
{
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQlMONITOR -Query "INSERT File_Share VALUES('$($file.FullName)', '$($file.CreationTime)', '$($file.LastWriteTime)')"
}