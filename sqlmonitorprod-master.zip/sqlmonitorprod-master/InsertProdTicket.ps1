#*************************************************************************************************/ 
# InsertProdTicket.ps1                                                                         */
#*************************************************************************************************/
#    This program inserts the failed login ticket number into FailedLoginTest table.             */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   10/8/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
#Set Server Query
#$TestTicketQuery = "select top 1 ref_num from call_req where description like '%SQLTEST05%' and summary like 'C1DBD536%' and DATEADD(s, open_date, '1970-01-01 00:00:00') > DATEADD(Hour,-1,Getdate())"
#$TestTicket = Invoke-Sqlcmd -ServerInstance C1DBD061 -Database MDB -Query $TestTicketQuery
$ProdTicketQuery = "select top 1 ref_num from call_req where description like '%SQLTEST05%' and summary like 'C1DBD069%' and DATEADD(s, open_date, '1969-12-31 19:00:00') > DATEADD(Hour,-2,Getdate()) and active_flag = 1"
$ProdTicket = Invoke-Sqlcmd -ServerInstance C1DBD061 -Database MDB -Query $ProdTicketQuery
if($ProdTicket -ne $NULL)
{
    $UpdateQuery = "Update FailedLoginTest Set Ticket = '$($ProdTicket.ref_num)' where environment = 'PROD' and ticket is null"
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database DBASUPP -Query $UpdateQuery
}
else
{
    $Emailbody = '-N C1DBD069 -P WindowsServer -A SQLServer -C Guardium Failed Login -I FAILED -S Critical -Q high -M No SDM Ticket Found For Production Guardium Failed Login Test. Please Investigate.'
Send-MailMessage -From '<dbagods@countryfinancial.com>' -To '<EMS_Email@countryfinancial.com>' -Subject 'Production Guardium Failed Login' -Body $EmailBody -SmtpServer 'inesg2.alliance.lan'
}
