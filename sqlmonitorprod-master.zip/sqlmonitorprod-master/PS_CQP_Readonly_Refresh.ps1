
<#
    Script:     PS_CQP_Readonly_Refresh.ps1
    Parameters: <none>
    Usage:      Called from SQL Server Agent on V01DBSWIN008
    Purpose:    This script is used to refresh read-only copies of the CQP CECDBPDP and CEWIPPDP databases for querying from V01DBSWIN008.
                Fresh copy-only backups are taken on both databases, then the existing database copies are dropped and replaced with that data.
                The security groups are regranted.
#>

Invoke-Sqlcmd -QueryTimeout 3600 -serverinstance V01DBSWIN146 -Database Master -Query "backup database CEWIPPDP TO DISK = N'\\v01dbswin008\i$\Data\CEWIPPDP.bak' WITH COPY_ONLY, INIT, NOFORMAT, COMPRESSION, NAME = N'CEWIPPDP.bak', SKIP, REWIND, NOUNLOAD"
Invoke-Sqlcmd -QueryTimeout 3600 -serverinstance V01DBSWIN144 -Database Master -Query "backup database CECDBPDP TO DISK = N'\\v01dbswin008\e$\Data\CECDBPDP.bak' WITH COPY_ONLY, INIT, NOFORMAT, COMPRESSION, NAME = N'CECDBPDP.bak', SKIP, REWIND, NOUNLOAD"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database Master -Query "alter database CEWIPPDP set SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE[CEWIPPDP]"
Invoke-Sqlcmd -QueryTimeout 3600 -serverinstance V01DBSWIN008 -Database Master -Query "RESTORE DATABASE CEWIPPDP FROM DISK = N'I:\Data\CEWIPPDP.bak' WITH RECOVERY, MOVE 'AUUnitWIP_Data' TO 'F:\Data\CEWIPPDP.mdf', MOVE 'AUUnitWIP_Log' TO 'G:\Data\CEWIPPDP_log.ldf'"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database Master -Query "alter database CECDBPDP set SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE[CECDBPDP]"
Invoke-Sqlcmd -QueryTimeout 3600 -serverinstance V01DBSWIN008 -Database Master -Query "RESTORE DATABASE CECDBPDP FROM DISK = N'E:\Data\CECDBPDP.bak' WITH RECOVERY, MOVE 'AUUnitCentral_Data' TO 'H:\Data\CECDBPDP.mdf', MOVE 'AUUnitCentral_Log' TO 'I:\Data\CECDBPDP_log.ldf'"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database CECDBPDP -Query "CREATE USER [ALLIANCE\CECDBPDP_EDW_READ_TABVIEW] FOR LOGIN [ALLIANCE\CECDBPDP_EDW_READ_TABVIEW]"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database CEWIPPDP -Query "CREATE USER [ALLIANCE\CEWIPPDP_EDW_READ_TABVIEW] FOR LOGIN [ALLIANCE\CEWIPPDP_EDW_READ_TABVIEW]"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database CECDBPDP -Query "ALTER ROLE [db_datareader] ADD MEMBER [ALLIANCE\CECDBPDP_EDW_READ_TABVIEW]"
Invoke-Sqlcmd -serverinstance V01DBSWIN008 -Database CEWIPPDP -Query "ALTER ROLE [db_datareader] ADD MEMBER [ALLIANCE\CEWIPPDP_EDW_READ_TABVIEW]"
