﻿$action = $args[0]

$servers = (Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "SELECT ServerName FROM Perf_MonitoredServers WHERE IsActive = 1").ServerName

foreach ($server in $servers)
{
    Invoke-SqlCmd -ServerInstance $server -Database msdb -Query "EXEC msdb.dbo.sp_update_job @job_name='Maintenance - Backup DIFF', @enabled=$action"
    Invoke-SqlCmd -ServerInstance $server -Database msdb -Query "EXEC msdb.dbo.sp_update_job @job_name='Maintenance - Backup FULL', @enabled=$action"
    Invoke-SqlCmd -ServerInstance $server -Database msdb -Query "EXEC msdb.dbo.sp_update_job @job_name='Maintenance - Backup LOG', @enabled=$action"    
}