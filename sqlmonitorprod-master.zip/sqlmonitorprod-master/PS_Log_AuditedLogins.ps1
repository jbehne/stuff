# This is the primary function, it takes an instance object and does all of the querying and updating
function f_Collect ($instance) 
{
    try 
    {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=.;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Integrated Security=true")
        $sqlconn.Open()

        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 240
        
        if ($instance.Version -ge "14")
        {
            $query = "DECLARE @logpath varchar(max);
                        SELECT @logpath = log_file_path + 'AuditLog*' FROM sys.server_file_audits
                        SELECT event_time, $($instance.InstanceID) InstanceID, succeeded, server_principal_name, database_principal_name, client_ip, application_name
                            FROM sys.fn_get_audit_file (@logpath,default,default) WHERE event_time > '$($instance.event_time)'
                            AND (server_principal_name NOT LIKE '%sqlidk'
                                AND (application_name NOT LIKE 'SQLAgent%' OR client_ip NOT IN ('10.16.109.49','10.17.107.138')));"
        }

        else
        {
            $query = "DECLARE @logpath varchar(max);
                        SELECT @logpath = log_file_path + 'AuditLog*' FROM sys.server_file_audits
                        SELECT event_time, $($instance.InstanceID) InstanceID, succeeded, server_principal_name, database_principal_name 
                            FROM sys.fn_get_audit_file (@logpath,default,default) WHERE event_time > '$($instance.event_time)'
                            AND server_principal_name NOT LIKE '%sqlidk';"
        }


        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlcmd.CommandTimeout = 0
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Log_AuditLogins"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch {
        $err = "PS_Log_AuditedLogins.ps1 - " + $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }
}

workflow wf_CollectAll ($instances) {
    foreach -parallel -throttlelimit 4 ($instance in $instances) {
        f_Collect $instance
    }
}

### Program Start

# Set query to get servers
$query = "WITH times 
AS (
SELECT InstanceID, MAX(event_time) event_time FROM Log_AuditLogins WHERE event_time > GETDATE()-3 GROUP BY InstanceID)
SELECT ServerName, pms.InstanceID, Version, COALESCE((event_time), '01-01-2020') event_time 
FROM Perf_MonitoredServers pms 
INNER JOIN Perf_MonitoredServers_Data pmsd ON pms.InstanceID = pmsd.InstanceID
LEFT OUTER JOIN times ON times.InstanceID = pms.InstanceID
WHERE IsActive = 1
AND ServerName NOT LIKE '%icm.lan'"

# Get servers
$instances = @(Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $query -QueryTimeout 600 -ConnectionTimeout 600)

# Call the workflow with the list of servers
wf_CollectAll $instances
