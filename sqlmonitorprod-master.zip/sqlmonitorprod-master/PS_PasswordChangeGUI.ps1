<#
    PS_PasswordChangeGUI.ps1
    This script must be run on C1DBD069.

    PASSWORD CHANGE LIST
    * z_sqlint
        * C1DBD069 - Linked Server to SERVINFO
        * C1DBD069 - Linked Server to XFRMDBP2
        * C1DBD069 - SSRS Data source for SERVINFO
        * V01DBSWIN040 - DBASUPP Webconfig
    * z_sqlidk
        * Production SQL Services
        * V01DBSWIN040 - Web pool
        * C1DBD069 - SSRS Data source for Production Repository
        * C1DBD069 - SSRS Data source for Test Repository
        * C1DBD069 - SSRS Data source for ACSDB Prod
    * zt_sqlidk
        * Test SQL Services
        * V01DBSWIN040 - Web pool
        * C1DBD069 - SQL Server Credential for Agent Proxy
    * z_dba_assetmgt
        * C1DBD069 - Linked server to C1DBD061
#>


$xmlWPF = [System.Xml.XmlDocument]@"
<Window 
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="SQL Password Change" Height="425" Width="550">
    <Grid Margin="0,0,0,0">
        <TabControl HorizontalAlignment="Left" Height="392" Margin="0,0,0,0" VerticalAlignment="Top" Width="540">
            <TabItem Header="Services">
                <Grid Background="#FFE5E5E5">
                    <RadioButton Content="Test" HorizontalAlignment="Left" VerticalAlignment="Top" Name="rdoTest" Margin="10,10,0,0"/>
                    <RadioButton Content="Production" HorizontalAlignment="Left" VerticalAlignment="Top" Margin="100,10,0,0" Name="rdoProd"/>
                    <Button Content="Load" HorizontalAlignment="Left" Margin="240,10,0,0" VerticalAlignment="Top" Width="75" Name="btnLoad"/>
                    <DataGrid HorizontalAlignment="Left" Height="171" Margin="10,35,0,0" VerticalAlignment="Top" Width="515" Name="gridServers"/>
                    <Button Content="Change Services Passwords" HorizontalAlignment="Left" Margin="10,211,0,0" VerticalAlignment="Top" Width="150" Name="btnChangePassword"/>
                    <Button Content="Restart Services" HorizontalAlignment="Left" Margin="165,211,0,0" VerticalAlignment="Top" Width="150" Name="btnRestartService"/>
                    <TextBox TextWrapping="Wrap" Text="" Name="txtServiceStatus" Margin="10,235,10,10" Width="515" Height="120" VerticalAlignment="Top" HorizontalAlignment="Left"/>
                </Grid>
            </TabItem>
            <TabItem Header="Misc">
                <Grid Background="#FFE5E5E5">
                    <TextBox HorizontalAlignment="Left" Height="219" Margin="10,115,0,0" TextWrapping="Wrap" Text="" VerticalAlignment="Top" Width="490" Name="txtMiscStatus"/>
                    <Button Content="Set zt__sqlidk" HorizontalAlignment="Left" Margin="10,10,0,0" VerticalAlignment="Top" Width="150" Name="btnSetTestIDK"/>
                    <Button Content="Set z__sqlidk" HorizontalAlignment="Left" Margin="10,35,0,0" VerticalAlignment="Top" Width="150" Name="btnSetProdIDK"/>
                    <Button Content="Set z__sqlint" HorizontalAlignment="Left" Margin="10,60,0,0" VerticalAlignment="Top" Width="150" Name="btnSetProdINT"/>
                    <Button Content="Set z__dba__assetmgt" HorizontalAlignment="Left" Margin="10,85,0,0" VerticalAlignment="Top" Width="150" Name="btnSetAsstMgmt"/>
                </Grid>
            </TabItem>
        </TabControl>
    </Grid>
</Window>
"@

try 
{
    Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase,system.windows.forms
} 

catch 
{
    Throw "Failed to load Windows Presentation Framework assemblies."
}

$xamGUI = [Windows.Markup.XamlReader]::Load((new-object System.Xml.XmlNodeReader $xmlWPF))
$xmlWPF.SelectNodes("//*[@Name]") | % { Set-Variable -Name ($_.Name) -Value $xamGUI.FindName($_.Name) -Scope Global }

$datatableresults = New-Object System.Data.DataTable
$datatableresults.Columns.Add("ServerName") | Out-Null
$datatableresults.Columns.Add("LastUpdated") | Out-Null
$datatableresults.Columns.Add("LastStarted") | Out-Null
$datatableresults.Columns.Add("Service") | Out-Null
$datatableresults.Columns.Add("Status") | Out-Null


# This function takes parameters for the server name and service name and restarts that service.
function RestartService ($server, $service)
{
    Get-Service -ComputerName $server -Name $service | Restart-Service -Force
}

function fGetServerData ($server)
{
    $server.ServerName | Out-Host
    $services = Get-Service -ComputerName $server.ServerName -Name "*sql*" | Where {$_.Name -ne "SQLBrowser" -and $_.Name -ne "SQLWriter" `
        -and $_.Name -ne "SQLTELEMETRY" -and $_.Name -notlike "*FD*" -and $_.Name -notlike "*SMS*" -and $_.Name -notlike "*ADHelper*" }  | Select Name, Status
    
    foreach ($service in $services)
    {
        $row = $datatableresults.NewRow()
        $row["ServerName"] = $server.ServerName
        $row["LastUpdated"] = $server.LastUpdated
        $row["LastStarted"] = $server.LastStarted
        $row["Service"] = $service.Name
        $row["Status"] = $service.Status

        $datatableresults.Rows.Add($row)
    }
}

# This function takes a parameter for the environment selected and returns the servers from that environment.
function LoadServers
{
    $datatableresults.Clear()

    if ($rdoProd.IsChecked -eq $true)
    {
        $servers = Invoke-SqlCmd -ServerInstance . -Database SQLMONITOR -Query "SELECT ServerName, FORMAT(LastUpdated, 'MM/dd hh:mm tt') LastUpdated, 
            FORMAT(LastStarted, 'MM/dd hh:mm tt') LastStarted FROM Perf_MonitoredServers WHERE IsPushActive = 1 OR IsActive = 1 AND ServerName <> 'C1APP017'"
        
        foreach ($server in $servers)
        {
            fGetServerData $server
        }

        $gridServers.ItemsSource = $datatableresults.DefaultView
    }

    elseif ($rdoTest.IsChecked -eq $true)
    {
        $servers = Invoke-SqlCmd -ServerInstance SQLMONITORNONPROD -Database SQLMONITOR -Query "SELECT ServerName, FORMAT(LastUpdated, 'MM/dd hh:mm tt') LastUpdated, 
        FORMAT(LastStarted, 'MM/dd hh:mm tt') LastStarted FROM Perf_MonitoredServers WHERE IsPushActive = 1 OR IsActive = 1 AND ServerName <> 'C6APP787'"

        foreach ($server in $servers)
        {
            fGetServerData $server
        }

        $gridServers.ItemsSource = $datatableresults.DefaultView
    }
}

function CredentialChangePW ($server, $account, $password)
{
    $query = "ALTER CREDENTIAL Saddles WITH IDENTITY = '$account', SECRET = '$password';"  
    Invoke-Sqlcmd -ServerInstance $server -Query $query
}

# This function takes parameters for the server name, service name, and password and sets the service's password.
function ServiceChangePW ($server, $service, $password)
{
    $service = gwmi win32_service -computer $server -filter "name='$service'"
    $service.change($null,$null,$null,$null,$null,$null,$null,$password)
    $txtServiceStatus.AddText("Changed password for $server $service`r`n")
}

# This function takes parameters for the server that has a linked server, the linked server's name, the account, and password and sets the linked server's user and password.
function LinkedServerChangePW ($server, $linkname, $account, $password)
{
    $txtMiscStatus.AddText("Starting linked server update on $server for $linkname using $account`r`n")
    
    $query = "sp_addlinkedsrvlogin @rmtsrvname ='$linkname', @locallogin = NULL , @useself = N'False', @rmtuser = '$account', @rmtpassword = '$password'"
    Invoke-Sqlcmd -ServerInstance $server -Query $query

    $txtMiscStatus.AddText("Completed linked server update`r`n")
}

# This function takes a parameter for the password and sets the web.config file's z_sqlint password.
function WebConfigChangePW ($password)
{
    $txtMiscStatus.AddText("Starting Web.config update`r`n")
    
    [xml]$web = Get-Content '\\V01DBSWIN040\E$\IISSites\WWWRoot\DBASUPP_Prod\Web.config'
    foreach ($node in $web.configuration.appSettings.add)
    {
        if ($node.key -eq "IntegrationPass")
        {
            $node.value = $password
        }
    }

    $web.Save("\\V01DBSWIN040\E$\IISSites\WWWRoot\DBASUPP_Prod\Web.config")


    [xml]$web = Get-Content '\\V01DBSWIN040\E$\IISSites\WWWRoot\DBASUPP_NonProd\Web.config'
    foreach ($node in $web.configuration.appSettings.add)
    {
        if ($node.key -eq "IntegrationPass")
        {
            $node.value = $password
        }
    }

    $web.Save("\\V01DBSWIN040\E$\IISSites\WWWRoot\DBASUPP_NonProd\Web.config")
   
    $txtMiscStatus.AddText("Completed Web.config update`r`n")
}

# This function takes parameters for the account name and password and sets the web pool's password.
function WebPoolChangePW ($account, $password)
{
    $txtMiscStatus.AddText("Starting Web pool update for $account`r`n")
    Invoke-Command  -ComputerName V01DBSWIN040 { Import-Module WebAdministration; $pool = Get-ChildItem –Path IIS:\AppPools | Where Name -eq $args[0]; $pool; Set-ItemProperty -Path "IIS:\AppPools\$($pool.name)" -Name processModel -Value @{userName="ALLIANCE\$($pool.name)";password=$args[1];identitytype=3}} -ArgumentList $account, $password
    $txtMiscStatus.AddText("Completed Web pool update for $account`r`n")
}

# This function takes parameters for the data source name and password and sets the data source's password.
function SSRSChangePW ($dsname, $password)
{
    $txtMiscStatus.AddText("Starting SSRS data source update for $dsname`r`n")
    $ReportServerUri = "http://localhost/ReportServer/ReportService2010.asmx?wsdl"

    try 
    {
        $proxy = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential -ErrorAction Stop;
        If ($proxy -ne $null) 
        {
            echo $proxy.ToString()
        }

        $datasourcepath = $proxy.ListChildren("/", $true) | Where Name -EQ $dsname
        $datasource = $proxy.GetDataSourceContents($datasourcepath.Path)
        $datasource.Password = $password
        $proxy.SetDataSourceContents($datasourcepath.Path, $datasource)
    
        $txtMiscStatus.AddText("Completed SSRS update for $dsname`r`n")
    }

    catch 
    {
        $txtMiscStatus.AddText("$_.Exception.Message")
    }

}

# This function takes a parameter of an account name and returns the cyberark password.
function GetCyberarkPassword ($account)
{
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if ($account -eq "z_sqlint")
    {
        $CCPCall = Invoke-WebRequest -Uri "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=Wapp_SQLServerAuthAccessApp&Safe=SQLDBAutomation_Svc&Username=$account&Reason=Password update&Address=zos-ssh.countrylan.com" -UseBasicParsing
    }

    else
    {
        $CCPCall = Invoke-WebRequest -Uri "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=Wapp_SQLServerAuthAccessApp&Safe=SQLDBAutomation_Svc&Username=$account&Reason=Password update" -UseBasicParsing
    }

    $password = ($CCPCall.Content | ConvertFrom-JSON).Content
    return $password
}

$btnSetProdIDK.add_Click({
    $password = GetCyberarkPassword "z_sqlidk"
    $txtMiscStatus.AddText("Starting z_sqlidk password change`r`n")

    WebPoolChangePW "z_sqlidk" $password
    SSRSChangePW "Production Repository" $password
    SSRSChangePW "Test Repository" $password
    SSRSChangePW "ACSDB Prod" $password

    $txtMiscStatus.AddText("Completed z_sqlidk password change`r`n")

})

$btnSetTestIDK.add_Click({
    $password = GetCyberarkPassword "zt_sqlidk"
    $txtMiscStatus.AddText("Starting zt_sqlidk password change`r`n")

    WebPoolChangePW "zt_sqlidk" $password
    CredentialChangePW SQLMONITORPROD "ALLIANCE\zt_sqlidk" $password

    $txtMiscStatus.AddText("Completed zt_sqlidk password change`r`n")
})

$btnSetProdINT.add_Click({
    $password = GetCyberarkPassword "z_sqlint"
    $txtMiscStatus.AddText("Starting z_sqlint password change`r`n")

    WebConfigChangePW $password
    LinkedServerChangePW "SQLMONITORPROD" "SERVINFO" "z_sqlint" $password
    LinkedServerChangePW "SQLMONITORPROD" "XFRMDBP2" "z_sqlint" $password
    SSRSChangePW "SERVINFO" $password

    $txtMiscStatus.AddText("Completed z_sqlint password change`r`n")
})

$btnSetAsstMgmt.add_Click({
    $password = GetCyberarkPassword "z_dba_assetmgt"
    $txtMiscStatus.AddText("Starting z_dba_assetmgt password change`r`n")

    LinkedServerChangePW "SQLMONITORPROD" "C1DBD061" "z_dba_assetmgt" $password
 
    $txtMiscStatus.AddText("Completed z_dba_assetmgt password change`r`n")
})

$btnLoad.add_Click({
    LoadServers
})

$btnChangePassword.add_Click({
    # ServiceChangePW ($server, $service, $password)
    if ($rdoTest.IsChecked)
    {
        $password = GetCyberarkPassword "zt_sqlidk"
    }

    else
    {
        $password = GetCyberarkPassword "z_sqlidk"   
    }

    foreach ($service in $gridServers.SelectedCells)
    {
        ServiceChangePW $service.Item.ServerName $service.Item.Service $password
    }
})

$btnRestartService.add_Click({
    foreach ($service in $gridServers.SelectedCells)
    {
        RestartService $service.Item.ServerName $service.Item.Service
        $txtServiceStatus.AddText("Started service for $($service.Item.ServerName) $($service.Item.Service)`r`n")

        if ($service.Item.Status -eq "Stopped")
        {
            RestartService $service.Item.ServerName $service.Item.Service
            $txtServiceStatus.AddText("Started service for $($service.Item.ServerName) $($service.Item.Service)`r`n")
        }
    }
})

<#
    # zt_sqlidk
    $password = GetCyberarkPassword "zt_sqlidk"
    WebPoolChangePW "zt_sqlidk" $password
    CredentialChangePW SQLMONITORPROD "ALLIANCE\zt_sqlidk" $password

    # z_sqlidk
    $password = GetCyberarkPassword "z_sqlidk"
    WebPoolChangePW "z_sqlidk" $password
    SSRSChangePW "Production Repository" $password
    SSRSChangePW "Test Repository" $password
    SSRSChangePW "ACSDB Prod" $password

    # z_sqlint
    $password = GetCyberarkPassword "z_sqlint"
    WebConfigChangePW $password
    LinkedServerChangePW "SQLMONITORPROD", "SERVINFO", "z_sqlint", $password
    SSRSChangePW "SERVINFO" $password

    # z_dba_assetmgt
    $password = GetCyberarkPassword "z_dba_assetmgt"
    LinkedServerChangePW "SQLMONITORPROD", "C1DBD061", "z_dba_assetmgt", $password

#>

$xamGUI.ShowDialog() | Out-Null
