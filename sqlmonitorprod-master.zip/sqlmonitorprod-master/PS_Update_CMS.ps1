﻿<#
    Name:    PS_Update_CMS.ps1
    Date:    2/27/19
    Author:  JB
    Purpose: This script will look at the servers in the CMS and compare to the servers being monitored.
             Missing servers will be added into the CMS and old servers will be removed.

#>

Import-Module SQLSERVER

# Load .net assemblies needed for SQL SMO calls
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.RegisteredServers') | out-null
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.Management.Common') | out-null

# Set the server that will host the CMS (happens to be the production repo)
$CMSInstance = "C1DBD069"

# Set the connections to the CMS store
$connectionString = "Data Source=$CMSINstance;Initial Catalog=master;Integrated Security=SSPI;"
$sqlConnection = new-object System.Data.SqlClient.SqlConnection($connectionString)
$conn = new-object Microsoft.SqlServer.Management.Common.ServerConnection($sqlConnection)
$CMSStore = new-object Microsoft.SqlServer.Management.RegisteredServers.RegisteredServersStore($conn)
$CMSDBStore = $CMSStore.ServerGroups["DatabaseEngineServerGroup"]

# Use SMO function to grab a list of all the existing CMS server names
$AlreadyRegisteredServers = @()
$CMSDBStore.GetDescendantRegisteredServers()|%{$AlreadyRegisteredServers +=$_.Name.Trim()}

# Grab the list of current monitored servers from the repo (I used lastupdated instead of isactive to grab any "push" servers)
$MonitoredServers = (Invoke-Sqlcmd -ServerInstance $CMSInstance -Database SQLMONITOR -Query "SELECT ServerName FROM vw_AllMonitoredServers WHERE LastUpdated > GETDATE() - 1 AND ServerName <> '$CMSInstance'").ServerName

# Create a list of servers that are not in CMS and should be
$MissingInCMS = $MonitoredServers | Where {$AlreadyRegisteredServers -notcontains $_}
# Create a list of servers that are in CMS and should be removed now
$RemoveCMS = $AlreadyRegisteredServers | Where {$MonitoredServers -notcontains $_}

# Loop the missing servers first
foreach ($m in $MissingInCMS) 
{
    # This will look in the repo to figure out the directory structure of the server (Environment\Version)
    $Query = "SELECT Environment, 
	    CASE SUBSTRING(Version, 0, 3) 
		    WHEN 10 THEN '2008R2'
		    WHEN 11 THEN '2012'
		    WHEN 12 THEN '2014'
		    WHEN 13 THEN '2016'
		    WHEN 14 THEN '2017'
		    WHEN 15 THEN '2019'
	    END Version 
    FROM vw_AllMonitoredServers WHERE ServerName = '$m'"

    $Server = Invoke-Sqlcmd -ServerInstance $CMSInstance -Database SQLMONITOR -Query $Query
    
    # Point the database store to the folder location of the server ($m)
    $CMSDBStore = $CMSStore.ServerGroups["DatabaseEngineServerGroup"].ServerGroups[$($Server.Environment)].ServerGroups[$($Server.Version)]
    
    # Create a new server object and set the connection properties and name, then add it to the CMS
    $NewServer = New-Object Microsoft.SqlServer.Management.RegisteredServers.RegisteredServer($CMSDBStore, $m)
    $NewServer.SecureConnectionString = "server=$m;integrated security=true"
    $NewServer.ConnectionString = "server=$m;integrated security=true"
    $NewServer.ServerName = "$m"
    $NewServer.Create()

    # Output what happened to the console. (This can be seen in job history)
    Write-Host "Created \$($Server.Environment)\$($Server.Version)\$m registration."
}

# Now loop through the servers that need to come out of CMS
foreach ($r in $RemoveCMS) 
{
    # Loop through the first set of folders (Production and Test)
    foreach ($env in $CMSStore.DatabaseEngineServerGroup.ServerGroups)
    {
        # Loop through the version folders (2008R2, 2012, etc)
        foreach ($ver in $env.ServerGroups)
        {
            # Check if this server ($r) exists in this directory
            if ($ver.RegisteredServers.ServerName -contains $r)
            {
                # If it does, grab the SMO object from the CMS by providing the FQ path and call the drop function of the SMO object
                $server = $CMSStore.DatabaseEngineServerGroup.ServerGroups[$env.Name].ServerGroups[$ver.Name].RegisteredServers[$r]
                $server.Drop()

                # Output what happened to the console. (This can be seen in job history)
                Write-Host "Dropped \$($env.Name)\$($ver.Name)\$r registration."
            }
        }
    }
}
