﻿$ErrorActionPreference= 'silentlycontinue'
Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "TRUNCATE TABLE Alert_LoggedOnServers"
$servers = (Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "SELECT ServerName FROM Perf_MonitoredServers WHERE IsActive = 1").ServerName

foreach ($s in $servers)
{
    $logons = (query user /server:$($s)) | Select -Skip 1 
    
    foreach ($l in $logons)
    {
        $user = $l.Substring(1, $l.IndexOf(' ', 1))
        $status = $l.Substring(46, $l.IndexOf(' ', 46) - 46)
        $logontime = $l.Substring(65, $l.IndexOf('M', 65) - 64)

        Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "INSERT Alert_LoggedOnServers VALUES (GETDATE(), '$s', 
            '$user', '$status', '$logontime')"
    }
}
