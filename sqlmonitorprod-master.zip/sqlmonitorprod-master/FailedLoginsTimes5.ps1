#*************************************************************************************************/ 
# FailedLoginsTimes5.ps1                                                                         */
#*************************************************************************************************/
#    This program generates a failed login 5 times on the same server to create a ticket.        */
#    Server is generated randomly, one test and one prod server is selected for this.            */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   10/8/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
try
{
    #Set Production Server Query
    $ServerQuery = "select TOP 1 SRVR_NM from openquery(servinfo,'SELECT DISTINCT SRVR_NM FROM CCDB2.MDB_DB_DATA WHERE AUDIT_FLG_INDR = ''Y'' AND DBMS_INSTANCE_NM = ''SQL'' AND DB_STAT = ''PROD''') order by NEWID()"
    $ErrorActionPreference = "SilentlyContinue"
    ##Set Servers
    $Servers = Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query $ServerQuery
    $Query = 'SELECT * FROM SYSDATABASES'
    ##PROD INSERT QUERY
    $InsertQuery = "INSERT INTO FAILEDLOGINTEST(LOGIN,ServerName,DBMS,Date, Environment) VALUES ('SQLTEST05','$($SERVERS.SRVR_NM)','SQL', CURRENT_TIMESTAMP, 'PROD')"
    #Loops through one prod server and generate a failed login ticket
    $EmailBody = "The production server chosen for the guardium failed test is $($SERVERS.SRVR_NM)"
    Send-MailMessage -From '<dbagods@countryfinancial.com>' -To '<DBASUPP@countryfinancial.com>' -Subject 'SQL Guardium Failed Login Test' -Body $EmailBody -SmtpServer 'inesg2.alliance.lan'
}
catch
{
    throw $_
}
Foreach($Server in $Servers){
    
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
    Invoke-Sqlcmd -ServerInstance $Server.SRVR_NM -Database Master -Query $Query -Username SQLTEST05 -Password Robert
    Start-Sleep -Seconds 40
}
try
{
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database DBASUPP -Query $InsertQuery
}
catch
{
    throw $_
}
