<#
    Script:     PS_CollectGDEData.ps1
    Parameters: <none>
    Usage:      Called from SQL Server Agent
    Purpose:    This script is used to collect Vormetric/GDE encryption points
                using the Vormetric REST API.  THe script relies on the z_sqlidk
                account and Cyberark integration to create the credentials and 
                writes all data out to the production SQLMONITOR database.
#>
#try
#{
    $query = "TRUNCATE TABLE GDE_Hosts;
                TRUNCATE TABLE GDE_Domains;
                TRUNCATE TABLE GDE_GuardPoints;"
    Invoke-Sqlcmd -ServerInstance SQLMONITORPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
    Invoke-Sqlcmd -ServerInstance SQLMONITORNONPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $CCPCall = Invoke-WebRequest -Uri "https://credentialprovider.countryfinancial.com/AIMWebService/api/Accounts?AppID=Wapp_SQLServerAuthAccessApp&Safe=SQLDBAutomation_Svc&Username=z_sqlidk&Reason=Vormetric API data ingestion" -UseBasicParsing
    $pair = "z_sqlidk:$(($CCPCall.Content | ConvertFrom-JSON).Content)"
    $encodedCredentials = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
    $headers = @{ Authorization = "Basic $encodedCredentials" }
        
    $content = (Invoke-WebRequest -Uri "https://v01secapl010.countrylan.com/dsm/v1/domains" -Headers $headers -UseBasicParsing).Content 
    $domains = ($content | ConvertFrom-Json).List

    foreach($domain in $domains)
    {
        $query = "
        INSERT GDE_Domains (domainid, name, description, lastupdate) 
        VALUES ('$($domain.id)', '$($domain.name)', '$($domain.description)', GETDATE())"
        Invoke-Sqlcmd -ServerInstance SQLMONITORPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
        Invoke-Sqlcmd -ServerInstance SQLMONITORNONPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop

        $content = (Invoke-WebRequest -Uri "https://v01secapl010.countrylan.com/dsm/v1/domains/$($domain.id)/hosts?limit=10000" -Headers $headers -UseBasicParsing).Content 
        $hosts = ($content | ConvertFrom-Json).List

        foreach ($gdehost in $hosts)
        {
            $query = "
            INSERT GDE_Hosts (domainid, hostid, name, description, os, lastupdate) 
            VALUES ('$($domain.id)', '$($gdehost.id)', '$($gdehost.name)', '$($gdehost.description)', '$($gdehost.os)',GETDATE())"
            Invoke-Sqlcmd -ServerInstance SQLMONITORPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
            Invoke-Sqlcmd -ServerInstance SQLMONITORNONPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
  
            $content = (Invoke-WebRequest -Uri "https://v01secapl010.countrylan.com/dsm/v1/domains/$($domain.id)/hosts/$($gdehost.id)/guardpoints?limit=10000" -Headers $headers -UseBasicParsing).Content 
            $guardpoints = ($content | ConvertFrom-Json).List

            foreach ($gp in $guardpoints)
            {
                $policyname = $gp.policy.name
                $policytype = $gp.policy.policyType
                $learnmode = $gp.policy.learnMode
                $guarded = $gp.guardInfo.GUARDED
                $guardpath = $gp.guardPath
                $guardstatus = $gp.guardStatus
                $gpid = $gp.id

                $query = "
                INSERT GDE_GuardPoints (hostid, gpid, guardpath, guardstatus, guarded, learnmode, policyname, policytype, lastupdate)
                VALUES ('$($gdehost.id)', '$gpid', '$guardpath', '$guardstatus', '$guarded', '$learnmode', '$policyname', '$policytype', GETDATE())"
                Invoke-Sqlcmd -ServerInstance SQLMONITORPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
                Invoke-Sqlcmd -ServerInstance SQLMONITORNONPROD -Database SQLMONITOR -Query $query #-ErrorAction Stop
            }
        }
    }
#}

#catch
#{
#    throw $_
#}
