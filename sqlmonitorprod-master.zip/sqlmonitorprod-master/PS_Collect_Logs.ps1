function f_Collect ($instance)
{
    try {
        $repositoryconnection = New-Object system.data.SqlClient.SQLConnection("Data Source=SQLMONITORPROD;Integrated Security=SSPI;Database=SQLMONITOR")
        $repositoryconnection.Open()

        $bc = New-Object ("System.Data.SqlClient.SqlBulkCopy") $repositoryconnection
        $bc.BatchSize = 100000
        $bc.EnableStreaming = "True"
        $bc.BulkCopyTimeout = 600

        $sqlconn = New-Object System.Data.SqlClient.SQLConnection("Server=$($instance.ServerName);Integrated Security=true")
        $sqlconn.Open()

    <#
        ### SQL Error Log
        $query = "DECLARE @errorlog TABLE (LogDate smalldatetime, ProcessInfo varchar(512), Text varchar(max));

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 0;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 1;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 2;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 3;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 4;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 5;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 6;

                INSERT @errorlog
                EXEC sys.xp_readerrorlog 7;

                SELECT $($instance.InstanceID), * 
                FROM @errorlog
                WHERE Text NOT LIKE 'Log was backed up%'
                AND Text NOT LIKE 'BACKUP DATABASE%successfully%'
                AND Text NOT LIKE 'Database backed up.%'
                AND Text NOT LIKE 'Database differential changes%'
                AND Text NOT LIKE 'Attempting to cycle error log%'  
                AND Text NOT LIKE 'Microsoft SQL Server %'
                AND Text NOT LIKE 'UTC adjustment:%'
                AND Text NOT LIKE '(c) Microsoft Corporation.'
                AND Text NOT LIKE 'All rights reserved.'
                AND Text NOT LIKE 'Server process ID is%'
                AND Text NOT LIKE 'System Manufacturer: %'
                AND Text NOT LIKE 'Authentication mode is%.'
                AND Text NOT LIKE 'Logging SQL Server messages in file%'
                AND Text NOT LIKE 'The service account is %'
                AND Text NOT LIKE 'Default collation: %'
                AND Text NOT LIKE 'The error log has been reinitialized. See the previous log for older entries.'
                AND Text NOT LIKE 'Recovery is writing a checkpoint%'
                AND Text NOT LIKE 'CHECKDB%finished without errors%'
                AND Text NOT LIKE 'This instance of SQL Server%'
                AND Text NOT LIKE 'DBCC CHECKDB%found 0 errors%'
                AND Text NOT LIKE 'SQL Server is terminating because of a system shutdown%'
                AND Text NOT LIKE 'Service Broker manager has shut down.'
                AND Text NOT LIKE 'Error: 17054, Severity: 16, State: 1.'
                AND Text NOT LIKE 'The current event was not reported to the Windows Events log.%'
                AND Text NOT LIKE '.NET Framework runtime has been stopped.'
                AND Text NOT LIKE 'SQL Trace was stopped due to server shutdown%'
                AND Text NOT LIKE 'Registry startup parameters:%'
                AND Text NOT LIKE 'Command Line Startup Parameters:%'
                AND Text NOT LIKE 'SQL Server detected %'
                AND Text NOT LIKE 'SQL Server is starting%'
                AND Text NOT LIKE 'Detected % MB of RAM%'
                AND Text NOT LIKE 'Using conventional memory in the memory manager.'
                AND Text NOT LIKE 'The maximum number of dedicated administrator connections for this instance is%'
                AND Text NOT LIKE 'Node configuration%'
                AND Text NOT LIKE 'Using dynamic lock allocation%'
                AND Text NOT LIKE 'Database Instant File Initialization: enabled%'
                AND Text NOT LIKE 'Starting up database %'
                AND Text NOT LIKE 'CLR version % loaded.'
                AND Text NOT LIKE 'Resource governor reconfiguration succeeded.'
                AND Text NOT LIKE 'Audit: Server Audit: 65536, Initialized and Assigned State: START_FAILED'
                AND Text NOT LIKE 'Audit: Server Audit: 65536, Initialized and Assigned State: STARTED'
                AND Text NOT LIKE 'SQL Trace ID 1 was started by login %.'
                AND Text NOT LIKE 'Server name is %'
                AND Text NOT LIKE 'A self-generated certificate was successfully loaded for encryption.'
                AND Text NOT LIKE 'Server is listening on%'
                AND Text NOT LIKE 'Server local connection provider is ready%'
                AND Text NOT LIKE 'Dedicated admin connection support was established%'
                AND Text NOT LIKE 'SQL Server is now ready for client connections%'
                AND Text NOT LIKE 'SQL Server is attempting to register a Service Principal Name%'
                AND Text NOT LIKE 'Common language runtime (CLR) functionality initialized%'
                AND Text NOT LIKE 'The SQL Server Network Interface library could not register the Service Principal Name%'
                AND Text NOT LIKE '%informational message only%'
                AND Text NOT LIKE 'The tempdb database has %'
                AND Text NOT LIKE 'The Service Broker endpoint is in disabled or stopped state.'
                AND Text NOT LIKE 'The Database Mirroring endpoint is in disabled or stopped state.'
                AND Text NOT LIKE 'Service Broker manager has started.'
                AND Text NOT LIKE 'AppDomain%created.'
                AND Text NOT LIKE 'Software Usage Metrics is disabled.'
                AND Text NOT LIKE 'Clearing tempdb database.'
                AND LogDate > '$($instance.LogDate)'"

        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlcmd.CommandTimeout = 600
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Log_SQLErrorLog"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()
#>

        ### Trace log
        $query = "
            DECLARE @log TABLE (InstanceID smallint, StartTime smalldatetime,  EndTime smalldatetime, 
            EventName varchar(max),  DatabaseName varchar(max),  ObjectName varchar(max),  
            ApplicationName varchar(max),  LoginName varchar(max), TextData varchar(max))

            INSERT @log
            SELECT $($instance.InstanceID), T.StartTime, T.EndTime, TE.name EventName, T.DatabaseName, T.ObjectName, T.ApplicationName, T.LoginName, TextData
            FROM sys.fn_trace_gettable(CONVERT(VARCHAR(150), ( 
            SELECT TOP 1 f.[value] FROM sys.fn_trace_getinfo(NULL) f WHERE   f.property = 2)), DEFAULT) T
	            JOIN sys.trace_events TE ON T.EventClass = TE.trace_event_id
            WHERE DatabaseName <> 'tempdb'
            AND ObjectName NOT LIKE '_WA%'
            AND ObjectName <> 'fn_trace_getinfo'
            AND ApplicationName NOT LIKE 'SQLAGENT%'
            AND TE.name NOT IN ('Audit Login Failed', 'Audit DBCC Event', 
            'Audit Backup/Restore Event', 'Missing Column Statistics', 'Sort Warnings');

            SELECT DISTINCT * FROM @log WHERE StartTime > '$($instance.TraceDate)'"

        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand($query, $sqlconn)
        $sqlcmd.CommandTimeout = 600
        $sqlreader = $sqlcmd.ExecuteReader()

        $bc.DestinationTableName = "Log_DefaultTrace"
        $bc.WriteToServer($sqlreader)
        $sqlreader.Close()

        $sqlconn.Close()
        $repositoryconnection.Close()
    }

    catch {
        $err = "PS_Collect_Logs.ps1 - " + $($_.Exception.Message).Replace("'","")
        Invoke-Sqlcmd -ServerInstance "SQLMONITORPROD" -Database SQLMONITOR -Query "INSERT Perf_ErrorLog VALUES (GETDATE(), $($instance.InstanceID), '$err')"
    }
}

workflow wf_CollectAll ($instances) 
{
    foreach -parallel -throttlelimit 4 ($instance in $instances) 
    {
        f_Collect $instance
    }
}

### Program Start

#Set repository
$repository = "SQLMONITORPROD"

# Set query to get servers
$query = "SELECT ServerName, InstanceID,
	(SELECT COALESCE((SELECT MAX(StartTime) FROM Log_DefaultTrace WHERE InstanceID = pms.InstanceID AND StartTime > GETDATE() - 7), '12/15/1941')) TraceDate,
	(SELECT COALESCE((SELECT MAX(LogDate) FROM Log_SQLErrorLog WHERE InstanceID = pms.InstanceID AND LogDate > GETDATE() - 7), '12/15/1941')) LogDate
FROM Perf_MonitoredServers pms 
WHERE IsActive = 1"

# Get servers
$instances = @(Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query $query -QueryTimeout 600 -ConnectionTimeout 600)

# Start
wf_CollectAll $instances
