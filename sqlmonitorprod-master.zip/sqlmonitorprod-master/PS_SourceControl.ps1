# Output log init
"$(Get-Date) - Starting source control scripting" | Out-File E:\Log\SourceControlLog.txt

# Set remote file store
$path = "\\V01DBSWIN040\SQLServer\Source Control"

 # Load SMO assembly
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | Out-Null

# Set objects to script
$IncludeTypes = @("Tables","StoredProcedures","Views","UserDefinedFunctions", "Triggers")

# Exclude system schemas
$ExcludeSchemas = @("sys","Information_Schema")

# Create the SMO options object and enable indexes to be scripted with tables
$so = New-Object ('Microsoft.SqlServer.Management.Smo.ScriptingOptions')
$so.Indexes = $true
$so.IncludeDatabaseContext = $true
$so.ScriptBatchTerminator = $true
$so.ToFileOnly = $true

# Get the list of server/databases to be scripted from the repo
$databases = Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "SELECT * FROM vw_SourceControl_Databases"
"$(Get-Date) - $($databases.Count) Databases to script objects" | Out-File E:\Log\SourceControlLog.txt -Append

# Get the unique list of servers to script jobs (without calling SQL again)
$servers = $databases | Select ServerName | Get-Unique -AsString
"$(Get-Date) - $($servers.Count) Servers to script agent jobs" | Out-File E:\Log\SourceControlLog.txt -Append

# Loop through the databases
foreach ($database in $databases)
{
    # Try/catch for error output
    try
    {
        # Set server name parm
        $server = $database.ServerName
        
        # Initialize the SMO object to the server
        $smo = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $server

        # Get database context from SMO
        $db =  $smo.Databases["$($database.DatabaseName)"] 

        # Set the parent directory for the database with server name and database name
        $parentdir = $path + "\" + $server + "\" + $db.Name

        # If the directory doesn't exist then create it
        if (!(Test-Path $parentdir))
        {
            New-Item -ItemType Directory -Path $parentdir | Out-Null
        }

        "$(Get-Date) - Scripting objects for $server.$($database.DatabaseName) to $parentdir" | Out-File E:\Log\SourceControlLog.txt -Append


        # Loop through each selected object type and script it
        foreach ($Type in $IncludeTypes)
        {
            # Set the dir for the object type
            $objdir = $parentdir + "\" + $Type

            # If the directory doesn't exist then create it
            if (!(Test-Path $objdir))
            {
                New-Item -ItemType Directory -Path $objdir | Out-Null
            }
        
            # Loop through all objects
            foreach ($objs in $db.$Type)
            {
                # Skip schemas from the filter list
                If ($ExcludeSchemas -notcontains $objs.Schema ) 
                {
                    # Remove brackets from name for filename
                    $objname = "$objs".replace("[","").replace("]","")                  

                    # Set the output filename 
                    $outfile = "$objdir\" + "$objname" + ".txt"

                    # Use SMO Script function to create the file
                    $so.FileName = $outfile
                    $objs.Script($so)
                    "$(Get-Date) - Scripted $Type $objname" | Out-File E:\Log\SourceControlLog.txt -Append
                }
            }        
        }
        
        # Change working directory
        cd $parentdir

        # Tell git to ignore ssl cert
        git config --global http.sslVerify false

        # Initialize GIT repo (works even if it has already been done)
        git init | Out-Null
        
        # Get the repo's remote setting for origin if it exists
        $remote = git remote

        # Set the GIT repo's origin parm if it does not exist
        if ($remote -eq $null)
        {
            git remote add origin "https://gitlab.countrypassport.com/sql-team/databases/$($server)`.$($db.Name)`.git" | Out-Null
        }

        # Add all files to the repo
        git add . | Out-Null

        # Create a commit for changed files (will return red text if no changes)
        git commit -m "update commit" | Out-Null

        # Push the commit (will return a bunch of red text, but it works so who cares)
        git push origin master | Out-Null

        # Change back to local directory
        c: | Out-Null
    }

    catch
    {
        # Output errors
        "$(Get-Date) - Error occurred in $server.$($database.DatabaseName) : $_" | Out-File E:\Log\SourceControlLog.txt -Append
        throw $_
    }
}

# Recreate the SMO options object for agent jobs
$so = New-Object ('Microsoft.SqlServer.Management.Smo.ScriptingOptions')
$so.IncludeDatabaseContext = $true
$so.ScriptBatchTerminator = $true
$so.ToFileOnly = $true

foreach ($server in $servers)
{
    # Try/catch for error output
    try
    {
        # Initialize the SMO object to the server
        $smo = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $server.ServerName

        # Get the jobs
        $jobs = $smo.JobServer.Jobs

        # Set the parent directory for the jobs with server name
        $parentdir = $path + "\" + $server.ServerName + "\AgentJobs"
        "$(Get-Date) - Scripting agent jobs for $($server.ServerName) to $parentdir" | Out-File E:\Log\SourceControlLog.txt -Append

        # If the directory doesn't exist then create it
        if (!(Test-Path $parentdir))
        {
            New-Item -ItemType Directory -Path $parentdir | Out-Null
        }

        # Loop through each job and script it
        foreach ($job in $jobs)
        {
            # Set the output filename 
            $outfile = "$parentdir\" + $job.Name + ".txt"

            # Use SMO Script function to create the file
            $job.Script($so) | Out-File $outfile 
            "$(Get-Date) - Scripted job $($job.Name)" | Out-File E:\Log\SourceControlLog.txt -Append
        }
        
        # Change working directory
        cd $parentdir

        # Initialize GIT repo (works even if it has already been done)
        git init | Out-Null
       
        # Get the repo's remote setting for origin if it exists
        $remote = git remote

        # Set the GIT repo's origin parm if it does not exist
        if ($remote -eq $null)
        {
            git remote add origin "https://gitlab.countrypassport.com/sql-team/agent-jobs/$($server.ServerName)`.git" | Out-Null
        }
        
        # Add all files to the repo
        git add . | Out-Null

        # Create a commit for changed files (will return red text if no changes)
        git commit -m "update commit" | Out-Null

        # Push the commit (will return a bunch of red text, but it works so who cares)
        git push origin master | Out-Null

        # Change back to local directory
        c: | Out-Null
    }

    catch
    {
        # Output errors
        "$(Get-Date) - Error occurred in $server.$($database.DatabaseName) : $_" | Out-File E:\Log\SourceControlLog.txt -Append
        throw $_
    }
}
