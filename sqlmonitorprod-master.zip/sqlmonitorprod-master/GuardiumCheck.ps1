#*************************************************************************************************/ 
# GuardiumCheck.ps1                                                                              */
#*************************************************************************************************/
#    Check to see what servers didn't report on Guardium failed logins report.                   */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   3/25/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
#Set Query to pull servers that wasn't on the failed logins report from guardium
$Query = "select DISTINCT SRVR_NM from [servinfo].[D2P0].CCDB2.MDB_DB_DATA WHERE audit_flg_indr = 'Y' AND DBMS = 'SQL' AND SRVR_NM NOT IN (Select distinct Server_host_Name FROM DBA_RETURNED_SQL_ERRORS_FOR_FAILED_LOGINS Where exception_timestamp = (SELECT CAST(GETDATE() AS Date)))"
$ServersNotInGuardium = Invoke-Sqlcmd -ServerInstance C1DBD069 -Database DBASUPP -Query $Query
if($ServersNotInGuardium -ne $NULL)
{
    $Emailbody = 'These are the servers that are not captured in the Guardium Failed Login Report: '+$($ServersNotInGuardium.SRVR_NM)
    Send-MailMessage -From '<dbagods@countryfinancial.com>' -To '<DBASUPP@countryfinancial.com>' -Subject 'Servers Not Captured In Guardium Failed Login Test' -Body $EmailBody -SmtpServer 'inesg2.alliance.lan'
}
else
{
    $Emailbody = ''
    Send-MailMessage -From '<dbagods@countryfinancial.com>' -To '<DBASUPP@countryfinancial.com>' -Subject 'ALL SERVERS CAPTURED IN GUARDIUM' -Body $EmailBody -SmtpServer 'inesg2.alliance.lan'
}
