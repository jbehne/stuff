#*************************************************************************************************/ 
# ScriptName.ps1                                                                              */
#*************************************************************************************************/
# This program deletes all folders that begin with all of the DBA's first name from              */
# \\C1UTL777\E$\CCAPPLICATIONS\DBA\BIN\ path that was created from the Gitlab Runners.           */
# All changes are tracked in the SQLMONITOR databases on the SQL Test Repository C1DBD536.       */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   04/8/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
##Set Execution time
$Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
##Set Script Name
$ScriptName = '' 
##Set Change Record
$ChangeRecord = ''
#Set Server Query
$ServerQuery = 'SELECT SERVERNAME FROM Perf_MonitoredServers isactive = 1 or ispushactive = 1'
##Set Servers
$Servers = Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $ServerQuery
##Set Before Change Details
$BeforeChangeDetails = ''
##Set After Change Details
$AfterChangeDetails = ''
$InsertQuery = "INSERT INTO CHANGE_TABLE(Time, ScriptName, ServerName, BeforeChangeDetails, AfterChangeDetails) Values ('$Time','$ScriptName','$($Server.ServerName)','$BeforeChangeDetails', '$AfterChangeDetails')"
$Query = 'SELECT * FROM Jeremy'
#Loops through each folder in FolderList and deletes it
Foreach($Server in $Servers){
    
    Invoke-Sqlcmd -ServerInstance $Server.SERVERNAME -Database Master -Query $Query
    IF($error -ne $null)
    {
        $ErrorQuery = "Insert error_log(InstanceID,ErrorTime,ErrorMsg) select instanceID, '$Time','$ScriptName - $ChangeRecord - $($error -replace "'" ,'"')' from perf_monitoredservers where servername = '$ServerName'"
        Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $ErrorQuery
        $error.clear()
    }
    else
    {
        Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $InsertQuery
    }
}
﻿##Set Execution time
$Time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
##Set Script Name
$ScriptName = '' 
##Set Change Record
$ChangeRecord = ''
#Set Server Query
$ServerQuery = 'SELECT SERVERNAME FROM Perf_MonitoredServers isactive = 1 or ispushactive = 1'
##Set Servers
$Servers = Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $ServerQuery
##Set Before Change Details
$BeforeChangeDetails = ''
##Set After Change Details
$AfterChangeDetails = ''
$InsertQuery = "INSERT INTO CHANGE_TABLE(Time, ScriptName, ServerName, BeforeChangeDetails, AfterChangeDetails) Values ('$Time','$ScriptName','$($Server.ServerName)','$BeforeChangeDetails', '$AfterChangeDetails')"
$Query = 'SELECT * FROM Jeremy'
#Loops through each folder in FolderList and deletes it
Foreach($Server in $Servers){
    
    Invoke-Sqlcmd -ServerInstance $Server.SERVERNAME -Database Master -Query $Query
    IF($error -ne $null)
    {
        $ErrorQuery = "Insert error_log(InstanceID,ErrorTime,ErrorMsg) select instanceID, '$Time','$ScriptName - $ChangeRecord - $($error -replace "'" ,'"')' from perf_monitoredservers where servername = '$ServerName'"
        Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $ErrorQuery
        $error.clear()
    }
    else
    {
        Invoke-Sqlcmd -ServerInstance C1DBD536 -Database SQLMONITOR -Query $InsertQuery
    }
}