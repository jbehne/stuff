﻿$query = "SELECT DATEDIFF(MINUTE, start_execution_date, GETDATE()) Duration 
FROM sysjobactivity ja
INNER JOIN sysjobs j ON j.job_id = ja.job_id
WHERE name = 'InsurityRDOdsDmLoad'
AND stop_execution_date IS NULL"

try
{
    $duration = (Invoke-Sqlcmd -ServerInstance V01DBSWIN147 -Database msdb -Query $query).Duration
    if ($duration -ne $null)
    {
        if ($duration -gt 300)
        {
            $notification = "EXEC msdb.dbo.sp_send_dbmail  
                @recipients = 'sqlteam@countryfinancial.com',  
                @body = 'Job: InsurityRDOdsDmLoad has a running duration of $($duration)',  
                @subject = 'InsurityRDOdsDmLoad on V01DBSWIN147 running long' ; "

            Invoke-Sqlcmd -ServerInstance C1DBD069 -Query $notification
        }
    }
}

catch
{
    throw $_
}
