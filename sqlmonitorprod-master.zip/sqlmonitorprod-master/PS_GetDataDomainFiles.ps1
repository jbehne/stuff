try
{

    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "TRUNCATE TABLE Backup_DataDomainFiles_Aurora"
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "TRUNCATE TABLE Backup_DataDomainFiles_Chaska"

    $files = Get-ChildItem \\s01ddaesd001d\01_sqlprodcifs   -Recurse | where { ! $_.PSIsContainer }
    $files += Get-ChildItem \\s01ddaesd001d\01_sqlqacifs    -Recurse | where { ! $_.PSIsContainer }
    $files += Get-ChildItem \\s01ddaesd001d\01_sqltestcifs  -Recurse | where { ! $_.PSIsContainer }

    foreach ($file in $files)
    {
        Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "INSERT Backup_DataDomainFiles_Aurora VALUES ('$($file.FullName)', '$('{0:MM-dd-yyyy hh:mm:ss}' -f $file.CreationTime)', $($file.Length / 1024))"
    }


    $files = Get-ChildItem \\s06ddaesd001d\c1_sqlprodcifs   -Recurse | where { ! $_.PSIsContainer }
    $files += Get-ChildItem \\s06ddaesd001d\c1_sqltestcifs   -Recurse | where { ! $_.PSIsContainer }
    $files += Get-ChildItem \\s06ddaesd001d\c1_sqlqacifs  -Recurse | where { ! $_.PSIsContainer }

    foreach ($file in $files)
    {
        Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "INSERT Backup_DataDomainFiles_Chaska VALUES ('$($file.FullName)', '$('{0:MM-dd-yyyy hh:mm:ss}' -f $file.CreationTime)', $($file.Length / 1024))"
    }
}

catch
{
    throw $_
}
