$repository = $args[0]

try
{
    $files = (Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "SELECT 'Remove-Item `"' + FileName + '`"' DeleteText FROM Backup_DataDomainFiles_Chaska WHERE FileName NOT LIKE '%COLD%' AND FileName NOT LIKE '%ENCRYPTION%' AND FileName NOT LIKE '%AD_HOC_USER%' AND Created < GETDATE() - 42").DeleteText

    foreach ($file in $files)
    {
        Invoke-Expression $file -ErrorAction Stop
    }


    $files = (Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "SELECT 'Remove-Item `"' + FileName + '`"' DeleteText FROM Backup_DataDomainFiles_Aurora WHERE FileName NOT LIKE '%COLD%' AND FileName NOT LIKE '%ENCRYPTION%' AND FileName NOT LIKE '%AD_HOC_USER%' AND Created < GETDATE() - 42").DeleteText

    foreach ($file in $files)
    {
        Invoke-Expression $file -ErrorAction Stop
    }
}

catch
{
    throw $_
}