#Gather list of server names and store that list in $servers only from c1dbd536 and C1DBD069. ALL SERVERS
$repository = $args[0]
$servers = (Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "SELECT ServerName FROM Perf_MonitoredServers WHERE IsActive = 1").ServerName
#gather all the data for the instance level queries
$benchmarks = Invoke-Sqlcmd -ServerInstance V01DBSWIN029 -Database ACSDB0P1 -Query "Select benchmark_id, DBMS_GATHER_QUERY, BENCHMARK_VALUE from control_standard where BENCHMARK_LEVEL = 'INSTANCE' and dbms = 'SQL' and BENCHMARK_ACTIVE_FLG = 'Y' and DBMS_GATHER_QUERY IS NOT NULL and DBMS_QUERYTYPE = 'TSQL'"
$poshbench = Invoke-Sqlcmd -ServerInstance V01DBSWIN029 -Database ACSDB0P1 -Query "Select benchmark_id, DBMS_GATHER_QUERY, BENCHMARK_VALUE from control_standard where BENCHMARK_LEVEL = 'INSTANCE' and dbms = 'SQL' and BENCHMARK_ACTIVE_FLG = 'Y' and DBMS_GATHER_QUERY IS NOT NULL and DBMS_QUERYTYPE = 'POSH'"

#Foreach loop
##define dbbench variable to pull all database level queries
$DBbenches = Invoke-Sqlcmd -ServerInstance V01DBSWIN029 -Database ACSDB0P1 -Query "Select benchmark_id, DBMS_GATHER_QUERY, BENCHMARK_VALUE from control_standard where BENCHMARK_LEVEL = 'DATABASE' and dbms = 'SQL' and BENCHMARK_ACTIVE_FLG = 'Y' and DBMS_GATHER_QUERY IS NOT NULL"

Foreach($server in $servers){
##Server Level TSQL 
    foreach($bench in $benchmarks){
          $result=Invoke-Sqlcmd -ServerInstance $server -Database master -Query $bench.DBMS_gather_query
       Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "Insert INTO CIS_BENCHMARKDATA_CURRENT(CollectionDate, BenchMarkID, ServerName, CurrentValue, GoldValue) VALUES(GETDATE(), '$($bench.benchmark_id)', '$server', '$($result.Column1)', '$($bench.Benchmark_value)')"
       }
##Server Level Posh 
    foreach($posh in $poshbench){
        
       $pquery = $posh.DBMS_gather_query
       $presult =invoke-expression $pquery 
       Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "Insert INTO CIS_BENCHMARKDATA_CURRENT(CollectionDate, BenchMarkID, ServerName, CurrentValue, GoldValue) VALUES(GETDATE(), '$($poshbench.benchmark_id)', '$server', '$presult', '$($poshbench.Benchmark_value)')"
    } 
#select all the non-system databases on each server 
    $databases = Invoke-Sqlcmd -ServerInstance $server -Database master -Query "SELECT name FROM sys.databases WHERE name NOT IN ('tempdb')"
    foreach($database in $databases){
    ##Database Level TSQL
        foreach($DBbench in $DBbenches){
        $result2 = Invoke-Sqlcmd -ServerInstance $server -Database $database.name -Query $DBbench.dbms_gather_query
        Invoke-Sqlcmd -ServerInstance $repository -Database SQLMONITOR -Query "Insert INTO CIS_BENCHMARKDATA_CURRENT(CollectionDate, BenchMarkID, ServerName, DatabaseName, CurrentValue, GoldValue) VALUES(GETDATE(), '$($DBbench.benchmark_id)', '$server', '$($database.name)', '$($result2.Column1)', '$($DBbench.Benchmark_value)')"

        }
    
    }                        
}

