$servers = (Invoke-Sqlcmd -ServerInstance C1DBD069 -Database SQLMONITOR -Query "SELECT ServerName FROM vw_AllMonitoredServers where isactive = 1 order by 1").ServerName 
foreach ($server in $servers) {
 $Running = Get-Service -Name "SQLBrowser" -ComputerName $Server
 $ServiceStartType = "0"
    If( $Running.StartType -eq "Disabled" ) {
    $ServiceStarttype = "1" }
    Write-Host "$server $ServiceStartType" 
}