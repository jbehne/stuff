$Global:Repository=$Args[0]
Invoke-Sqlcmd -serverinstance $Repository -Database SqlMonitor -Query "truncate table dbo.Alert_detached_databases"
$servers = (Invoke-Sqlcmd -ServerInstance $Repository -Database SQLMONITOR -Query "SELECT ServerName FROM perf_monitoredservers where isactive = 1 order by 1").ServerName 
foreach ($server in $servers)
{
    $DeviceId = (Get-WmiObject Win32_LogicalDisk -ComputerName $server -Filter "DriveType=3 and DeviceID<>'C:'").DeviceId | ForEach-Object {$_ -replace ":", "$"}
    foreach ($Drive in $DeviceID)
    {
        $ImageFiles = "\\$server\$Drive\Data\"
       $ValidPath = Test-Path $ImageFiles 
       If ($ValidPath -eq $True)
              {
              $FullFile = Get-ChildItem $ImageFiles -recurse -Filter *.mdf | Select FullName,lastwritetime 
              foreach ($SingleFile in $FullFile)
                 {
                   $splitstring = $SingleFile.FullName.split("\")
                   $newstring = ""
                   for ($x = 3; $x -le $splitstring.Length -1; $x++)
                     {
                          $newstring += $splitstring[$x] + "\"
                     }
                   $newstring = $newstring.Substring(0, $newstring.Length -1) 
                   $newstring = $newstring -replace '\$', ':'
                   $Var = Invoke-Sqlcmd -ServerInstance $server -Database master -Query "Select b.name from sys.databases b join sys.master_files a on a.database_id=b.database_id where physical_name='$newString'"
                   If ($Var -eq $null) {
                     Invoke-Sqlcmd -serverinstance $Repository -Database SqlMonitor -Query "Insert into dbo.Alert_detached_databases values('$server', '$($SingleFile.FullName)', '$($SingleFile.LastWriteTime)')"
                                       }
                 }
              }
                          
    }
}
