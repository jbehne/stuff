$query = "declare @dir nvarchar(4000) 
    exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'SQLArg1', @dir output, 'no_output' 
    if @dir is null 
    begin
        exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLDataRoot', @dir output, 'no_output'
        select @dir = @dir + N'\LOG'
    end
    select @dir "

$servers = Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query "SELECT ServerName, InstanceID FROM Perf_MonitoredServers WHERE IsActive = 1"

foreach ($server in $servers)
{
    try
    {
        if ($server.ServerName -ne "C1APP017")
        {
            $logfolder = (Invoke-Sqlcmd -ServerInstance $server.ServerName -Query $query).Column1
            $logfolder = "\\" + $server.ServerName + "\" + $logfolder.Replace(":", "$")
            Get-ChildItem -Path $logfolder -Recurse | Where LastWriteTime -lt (Get-Date).AddDays(-90) | Remove-Item -ErrorAction Stop
            Invoke-Sqlcmd -ServerInstance $server.ServerName -Database msdb -Query "sp_delete_backuphistory @oldest_date = '$((Get-Date).AddDays(-30).ToString("MM/dd/yyyy"))'" -ErrorAction Stop
        }
    }

    catch 
    {
        $server
        $errorquery = "INSERT Perf_ErrorLog VALUES(GETDATE(), $($server.InstanceID), 'PS_CleanLogDirectory - $_')"
        Invoke-Sqlcmd -ServerInstance . -Database SQLMONITOR -Query $errorquery
        continue;
    }
}
