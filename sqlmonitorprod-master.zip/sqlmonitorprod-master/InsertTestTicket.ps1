#*************************************************************************************************/ 
# InsertTicketNubmer.ps1                                                                         */
#*************************************************************************************************/
#    This program inserts the failed login ticket number into FailedLoginTest table.             */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
# CHANGE LOG:                                                                                    */
#                                                                                                */
#   NAME           DATE   DESCRIPTION OF CHANGES (CHANGE REQUEST#)                               */
#   -----------  -------- -----------------------------------------------------------------      */
#   Montgomery   10/8/2020  New script                                                           */
#                                                                                                */
#*************************************************************************************************/
# INPUT PARAMETERS:                                                                              */
#     PARM             REQUIRED    DESCRIPTION                                                   */
#     ---------------  ----------  --------------------------------------------------------      */
#      None                                                                                      */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#                                                                                                */
#*************************************************************************************************/
#Set Server Query
$TestTicketQuery = "select top 1 ref_num from call_req where description like '%SQLTEST05%' and summary like 'C1DBD536%' and DATEADD(s, open_date, '1969-12-31 19:00:00') > DATEADD(Hour,-2,Getdate()) and active_flag = 1"
$TestTicket = Invoke-Sqlcmd -ServerInstance C1DBD061 -Database MDB -Query $TestTicketQuery
#$ProdTicketQuery = "select top 1 ref_num from call_req where summary like '%C1DBD069%' and description like '%SQLTEST05%' and active_flag = 1 and close_date is NULL"
#$ProdTicket = Invoke-Sqlcmd -ServerInstance C1DBD061 -Database MDB -Query $ProdTicketQuery
if($TestTicket -ne $NULL)
{
    $UpdateQuery = "Update FailedLoginTest Set Ticket = '$($TestTicket.ref_num)' where environment = 'TEST' and ticket is null"
    Invoke-Sqlcmd -ServerInstance C1DBD069 -Database DBASUPP -Query $UpdateQuery
}
else
{
    $Emailbody = '-N C1DBD069 -P WindowsServer -A SQLServer -C Guardium Failed Login -I FAILED -S Critical -Q high -M No SDM Ticket Found For Non-Production Guardium Failed Login Test. Please Investigate.'
Send-MailMessage -From '<dbagods@countryfinancial.com>' -To '<EMS_Email@countryfinancial.com>' -Subject 'Non-Production Guardium Failed Login' -Body $EmailBody -SmtpServer 'inesg2.alliance.lan'
}
